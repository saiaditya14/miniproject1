"""HLS ontology loader — pragmas, patterns, types, decision guides, errors."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# Keywords that map to pattern IDs
_PATTERN_KEYWORDS: dict[str, list[str]] = {
    "dataflow-diamond": ["fork", "join", "diamond", "parallel paths", "fan-out", "fan-in"],
    "autorestart": ["autorestart", "free-running", "continuous", "always running"],
    "merge-split": ["merge", "split", "fan-out", "fan-in", "round-robin", "load-balance"],
    "array-of-streams": ["array of streams", "multiple streams", "parallel streams"],
    "array-partition": ["array partition", "partition", "bank", "memory bank"],
    "bram-dual-port": ["dual port", "bram", "dual-port", "concurrent access"],
    "rom-inference": ["rom", "read-only", "lookup table", "constant array"],
    "struct-alignment": ["struct", "alignment", "packing", "aggregate"],
    "pointer-streaming": ["pointer", "pointer to stream", "pointer streaming"],
    "axis-side-channels": ["side channel", "tlast", "tkeep", "tstrb"],
    "axis-to-maxi": ["axis to maxi", "stream to memory", "axis to ddr"],
    "port-widening": ["port widening", "wide port", "port width", "bandwidth"],
    "port-aliasing": ["port alias", "same memory", "shared memory port"],
    "free-running-pipeline": ["free running", "free-running pipeline"],
    "perfect-loop-restructuring": ["perfect loop", "loop nest", "loop restructuring"],
    "stencil-optimization": [
        "stencil", "sliding window", "line buffer", "window buffer",
        "convolution", "filter", "gaussian", "sobel", "median",
    ],
    "dsp-intrinsics": ["dsp intrinsic", "dsp block", "dsp48", "mac"],
    "fir-usage": ["fir", "finite impulse response"],
    "fft-usage": ["fft", "fast fourier"],
    "function-instantiate": ["function instantiate", "multiple instances"],
    "dataflow-bypass": ["dataflow bypass", "minimal overhead"],
    "rtl-blackbox": ["rtl blackbox", "black box", "rtl block"],
    "memory-bottleneck-fix": ["memory bottleneck", "memory conflict", "access conflict"],
}

# Keywords that map to decision guide IDs
_GUIDE_KEYWORDS: dict[str, list[str]] = {
    "fifo-vs-pipo": ["fifo", "pipo", "ping-pong", "channel type", "fifo vs pipo"],
    "explicit-vs-implicit-streams": ["explicit stream", "implicit stream", "hls::stream vs array"],
    "interface-selection": ["m_axi", "axis", "s_axilite", "interface selection", "port type"],
    "memory-bank-selection": ["memory bank", "ddr bank", "hbm bank", "bank assignment"],
    "array-partition-strategy": ["partition strategy", "how to partition", "array partition"],
    "cache-vs-direct": ["cache", "direct access", "cache vs direct"],
    "pipeline-with-dependencies": ["pipeline dependency", "loop-carried", "dependency"],
    "unroll-vs-pipeline": ["unroll vs pipeline", "unroll or pipeline"],
    "throughput-vs-latency": ["throughput vs latency", "throughput or latency"],
    "resource-efficiency": ["resource efficiency", "lut", "bram", "resource budget"],
}


@dataclass
class OntologyStats:
    num_pragmas: int = 0
    num_patterns: int = 0
    num_types: int = 0
    num_guides: int = 0
    num_errors: int = 0
    num_lessons: int = 0


@dataclass
class Ontology:
    """HLS ontology: pragmas, patterns, types, decision guides, errors."""

    path: Path
    _pragmas: list[dict] = field(default_factory=list, repr=False)
    _patterns: list[dict] = field(default_factory=list, repr=False)
    _types: list[dict] = field(default_factory=list, repr=False)
    _guides: list[dict] = field(default_factory=list, repr=False)
    _errors: list[dict] = field(default_factory=list, repr=False)
    _lessons: list[dict] = field(default_factory=list, repr=False)
    _loaded: bool = field(default=False, repr=False)

    # ── Loading ──

    def load(self) -> None:
        """Load all ontology YAML files."""
        if self._loaded:
            return
        schema = self.path / "schema"
        if not schema.is_dir():
            raise FileNotFoundError(f"Ontology schema not found: {schema}")

        self._pragmas = _load_yaml_list(schema / "pragmas.yaml", "pragmas")
        self._patterns = _load_yaml_list(schema / "patterns.yaml", "patterns")
        self._types = _load_yaml_list(schema / "types.yaml", "types")
        self._guides = _load_yaml_list(schema / "decision-guides.yaml", "guides")
        self._errors = _load_yaml_list(schema / "errors.yaml", "entries")
        self._lessons = _load_yaml_list(schema / "lessons.yaml", "entries")
        self._loaded = True

    def _ensure_loaded(self) -> None:
        if not self._loaded:
            self.load()

    @property
    def examples_dir(self) -> Path | None:
        """Path to Vitis HLS introductory examples, if present."""
        d = self.path / "Vitis-HLS-Introductory-Examples"
        return d if d.is_dir() else None

    @property
    def stats(self) -> OntologyStats:
        self._ensure_loaded()
        return OntologyStats(
            num_pragmas=len(self._pragmas),
            num_patterns=len(self._patterns),
            num_types=len(self._types),
            num_guides=len(self._guides),
            num_errors=len(self._errors),
            num_lessons=len(self._lessons),
        )

    # ── Query by name/id ──

    def get_pragma(self, name: str) -> dict | None:
        self._ensure_loaded()
        name_up = name.upper()
        return next((p for p in self._pragmas if p["name"].upper() == name_up), None)

    def get_pattern(self, pattern_id: str) -> dict | None:
        self._ensure_loaded()
        pid = pattern_id.lower()
        return next((p for p in self._patterns if p["id"].lower() == pid), None)

    def get_type(self, name: str) -> dict | None:
        self._ensure_loaded()
        nl = name.lower()
        return next((t for t in self._types if t["name"].lower() == nl), None)

    def get_guide(self, guide_id: str) -> dict | None:
        self._ensure_loaded()
        gid = guide_id.lower()
        return next((g for g in self._guides if g["id"].lower() == gid), None)

    def get_error(self, error_id: str) -> dict | None:
        self._ensure_loaded()
        eid = error_id.lower()
        return next((e for e in self._errors if e["id"].lower() == eid), None)

    # ── List names/IDs ──

    def list_pragmas(self) -> list[str]:
        self._ensure_loaded()
        return [p["name"] for p in self._pragmas]

    def list_patterns(self) -> list[str]:
        self._ensure_loaded()
        return [p["id"] for p in self._patterns]

    def list_types(self) -> list[str]:
        self._ensure_loaded()
        return [t["name"] for t in self._types]

    def list_guides(self) -> list[str]:
        self._ensure_loaded()
        return [g["id"] for g in self._guides]

    def list_errors(self) -> list[str]:
        self._ensure_loaded()
        return [e["id"] for e in self._errors]

    def list_lessons(self) -> list[str]:
        self._ensure_loaded()
        return [l["id"] for l in self._lessons]

    # ── Search ──

    def search(self, query: str) -> list[dict]:
        """Search across all categories. Returns list of {category, entry} dicts."""
        self._ensure_loaded()
        q = query.lower()
        results = []

        for p in self._pragmas:
            if _matches(p, q, ["name", "description", "category"]):
                results.append({"category": "pragma", "entry": p})

        for p in self._patterns:
            if _matches(p, q, ["id", "question", "description", "category"]):
                results.append({"category": "pattern", "entry": p})

        for t in self._types:
            if _matches(t, q, ["name", "description", "category"]):
                results.append({"category": "type", "entry": t})

        for g in self._guides:
            if _matches(g, q, ["id", "question", "category"]):
                results.append({"category": "guide", "entry": g})

        for e in self._errors:
            if _matches(e, q, ["id", "title", "message", "category"]):
                results.append({"category": "error", "entry": e})

        return results

    # ── Keyword detection ──

    def detect_patterns(self, text: str) -> list[str]:
        """Detect relevant pattern IDs from free text (requirements, etc.)."""
        text_lower = text.lower()
        found = []
        for pattern_id, keywords in _PATTERN_KEYWORDS.items():
            if any(kw in text_lower for kw in keywords):
                found.append(pattern_id)
        return found

    def detect_patterns_ranked(self, text: str) -> list[tuple[str, int]]:
        """Detect pattern IDs ranked by keyword-match count, with word boundaries.

        Returns list of (pattern_id, score) sorted by score descending. Uses \\b
        regex anchors so that 'filter' does not falsely trigger 'fir' — the
        substring matching in detect_patterns is preserved for backward compat
        but produces noisy top-N selections (e.g., gaussian-filter spec hits
        fir-usage purely on substring 'fir' inside 'filter').
        """
        import re
        text_lower = text.lower()
        scored: list[tuple[str, int]] = []
        for pattern_id, keywords in _PATTERN_KEYWORDS.items():
            score = sum(
                1 for kw in keywords
                if re.search(r"\b" + re.escape(kw) + r"\b", text_lower)
            )
            if score > 0:
                scored.append((pattern_id, score))
        scored.sort(key=lambda x: -x[1])
        return scored

    def detect_guides(self, text: str) -> list[str]:
        """Detect relevant decision guide IDs from free text."""
        text_lower = text.lower()
        found = []
        for guide_id, keywords in _GUIDE_KEYWORDS.items():
            if any(kw in text_lower for kw in keywords):
                found.append(guide_id)
        return found

    # ── Context formatting for agents ──

    def get_relevant_context(self, text: str, max_patterns: int = 5) -> str:
        """Analyze text, return formatted ontology context for LLM injection.

        Scans text for keywords, loads matching patterns + decision guides,
        formats as markdown suitable for system/user prompt.
        """
        self._ensure_loaded()

        pattern_ids = self.detect_patterns(text)[:max_patterns]
        guide_ids = self.detect_guides(text)

        sections = []

        if pattern_ids:
            sections.append("## Relevant HLS Patterns\n")
            for pid in pattern_ids:
                p = self.get_pattern(pid)
                if p:
                    sections.append(format_pattern(p, self.examples_dir))

        if guide_ids:
            sections.append("## Decision Guides\n")
            for gid in guide_ids:
                g = self.get_guide(gid)
                if g:
                    sections.append(format_guide(g))

        if not sections:
            return ""

        return "\n".join(sections)

    def catalog_text(self) -> str:
        """Render a compact catalog of all patterns, grouped by category.

        Used to inject the universe of available patterns into the arch system
        prompt so the LLM can declare which IDs informed its design — replacing
        keyword-based detection with agent-routed selection.
        """
        self._ensure_loaded()
        by_category: dict[str, list[dict]] = {}
        for p in self._patterns:
            cat = p.get("category", "uncategorized")
            by_category.setdefault(cat, []).append(p)

        lines = ["## HLS Pattern Catalog", ""]
        for cat in sorted(by_category):
            lines.append(f"### {cat}")
            for p in sorted(by_category[cat], key=lambda x: x.get("id", "")):
                pid = p.get("id", "?")
                question = p.get("question", "").strip()
                if question:
                    lines.append(f"- `{pid}` — {question}")
                else:
                    lines.append(f"- `{pid}`")
            lines.append("")
        return "\n".join(lines)

    def get_pattern_examples_code(self, pattern_id: str) -> dict[str, str]:
        """Load verbatim source for the canonical example files referenced in
        a pattern's YAML `examples` field.

        Each YAML pattern may declare one or more variants (e.g., stencil_1d,
        stencil_2d), each pointing at <examples_dir>/<variant.path>/<key_files>.
        Returns dict mapping `<variant>/<filename>` -> file content. Returns
        empty dict if no examples_dir, no examples field, or no readable files.

        Used by the rich-ontology context builder so codegen sees a complete
        working kernel template (producer/consumer contract intact), not just
        the pattern's abstract docs.
        """
        self._ensure_loaded()
        ex_dir = self.examples_dir
        if ex_dir is None or not ex_dir.is_dir():
            return {}
        p = self.get_pattern(pattern_id)
        if not p:
            return {}
        examples = p.get("examples")
        if not isinstance(examples, dict):
            return {}
        out: dict[str, str] = {}
        for variant_name, variant in examples.items():
            if not isinstance(variant, dict):
                continue
            sub_path = variant.get("path", "")
            key_files = variant.get("key_files", [])
            if not sub_path or not isinstance(key_files, list):
                continue
            for fname in key_files:
                fpath = ex_dir / sub_path / fname
                if fpath.is_file():
                    try:
                        out[f"{variant_name}/{fname}"] = fpath.read_text()
                    except (OSError, UnicodeDecodeError):
                        pass
        return out

    def get_pattern_doc_md(self, pattern_id: str) -> str | None:
        """Load full markdown documentation for a pattern.

        Resolves to <ontology_root>/docs/patterns/<id>.md. Returns None if the
        file does not exist (some pattern IDs may not have rich docs yet).
        """
        md_path = self.path / "docs" / "patterns" / f"{pattern_id}.md"
        if md_path.is_file():
            return md_path.read_text()
        return None

    def get_error_context(self, error_text: str) -> str:
        """Find ontology entries matching an error message."""
        self._ensure_loaded()
        results = []
        error_lower = error_text.lower()

        for e in self._errors:
            # Check message codes
            codes = e.get("message_codes", [])
            if any(code.lower() in error_lower for code in codes):
                results.append(e)
                continue
            # Check keywords in title/message
            title = e.get("title", "").lower()
            if title and title in error_lower:
                results.append(e)

        if not results:
            return ""

        lines = ["## Relevant Error Guidance (UG1448)\n"]
        for e in results[:3]:
            lines.append(f"### {e.get('title', e['id'])}")
            lines.append(f"**Message:** {e.get('message', 'N/A')[:200]}")
            if e.get("explanation"):
                lines.append(f"**Explanation:** {e['explanation'][:300]}")
            if e.get("resolution"):
                lines.append(f"**Resolution:** {e['resolution'][:300]}")
            lines.append("")

        return "\n".join(lines)

    def get_lesson_context(self, error_text: str) -> str:
        """Find lessons matching build error text."""
        self._ensure_loaded()
        if not self._lessons:
            return ""

        results = []
        error_lower = error_text.lower()

        for lesson in self._lessons:
            # Match on error_pattern (substring match)
            pattern = lesson.get("error_pattern", "")
            if pattern and pattern.lower() in error_lower:
                results.append(lesson)
                continue
            # Match on keywords (any keyword present)
            keywords = lesson.get("keywords", [])
            if any(kw.lower() in error_lower for kw in keywords):
                results.append(lesson)

        if not results:
            return ""

        lines = ["## Known Lessons (from previous builds)\n"]
        for lesson in results[:3]:  # Cap at 3
            lines.append(f"### {lesson.get('title', lesson['id'])}")
            lines.append(f"**Problem:** {lesson.get('problem', 'N/A')}")
            lines.append(f"**Solution:** {lesson.get('solution', 'N/A')}")
            if lesson.get("example_after"):
                lines.append(
                    f"**Correct pattern:**\n```cpp\n{lesson['example_after'].strip()}\n```"
                )
            lines.append("")

        return "\n".join(lines)


# ── Formatting helpers ──


def format_pragma(pragma: dict) -> str:
    """Format a pragma entry as readable markdown."""
    lines = [
        f"### {pragma['name']}",
        f"**Syntax:** `{pragma.get('syntax', 'N/A')}`",
        f"**Category:** {pragma.get('category', 'N/A')}",
        f"\n{pragma.get('description', '')}",
    ]
    if pragma.get("when_to_use"):
        lines.append("\n**When to use:**")
        for item in pragma["when_to_use"]:
            lines.append(f"- {item}")
    if pragma.get("when_not_to_use"):
        lines.append("\n**When NOT to use:**")
        for item in pragma["when_not_to_use"]:
            lines.append(f"- {item}")
    if pragma.get("parameters"):
        lines.append("\n**Parameters:**")
        for param in pragma["parameters"]:
            default = f" (default: {param['default']})" if "default" in param else ""
            lines.append(f"- `{param['name']}` ({param.get('type', '?')}): {param.get('description', '')}{default}")
    if pragma.get("notes"):
        lines.append(f"\n**Notes:** {pragma['notes']}")
    if pragma.get("caution"):
        lines.append(f"\n**Caution:** {pragma['caution']}")
    lines.append("")
    return "\n".join(lines)


def format_pattern(pattern: dict, examples_dir: Path | None = None) -> str:
    """Format a pattern entry as readable markdown."""
    lines = [
        f"### Pattern: {pattern['id']}",
        f"**Question:** {pattern.get('question', '')}",
        f"**Category:** {pattern.get('category', '')}",
        f"\n{pattern.get('description', '')}",
    ]
    if pattern.get("architecture"):
        lines.append(f"\n**Architecture:**\n```\n{pattern['architecture'].strip()}\n```")
    if pattern.get("detection"):
        det = pattern["detection"]
        if det.get("indicators"):
            lines.append("\n**Indicators:**")
            for ind in det["indicators"]:
                lines.append(f"- {ind}")
    if pattern.get("variants"):
        lines.append("\n**Variants:**")
        for vname, v in pattern["variants"].items():
            desc = v.get("description", "")
            use_when = v.get("use_when", "")
            example = v.get("example", "")
            lines.append(f"- **{vname}**: {desc}")
            if use_when:
                lines.append(f"  Use when: {use_when}")
            if example and examples_dir:
                lines.append(f"  Example: `{examples_dir / example}`")
            elif example:
                lines.append(f"  Example: `{example}`")
    if pattern.get("key_constraints"):
        lines.append("\n**Key constraints:**")
        for c in pattern["key_constraints"]:
            lines.append(f"- {c}")
    if pattern.get("decision_tree"):
        lines.append(f"\n**Decision tree:**\n```\n{pattern['decision_tree'].strip()}\n```")
    if pattern.get("related_pragmas"):
        lines.append(f"\n**Related pragmas:** {', '.join(pattern['related_pragmas'])}")
    lines.append("")
    return "\n".join(lines)


def format_type(typ: dict) -> str:
    """Format a type entry as readable markdown."""
    lines = [
        f"### {typ['name']}",
        f"**Syntax:** `{typ.get('syntax', 'N/A')}`",
        f"**Header:** `{typ.get('header', 'N/A')}`",
        f"**Category:** {typ.get('category', '')}",
        f"\n{typ.get('description', '')}",
    ]
    if typ.get("methods"):
        lines.append("\n**Methods:**")
        for m in typ["methods"]:
            lines.append(f"- `{m['name']}` → `{m.get('return', '?')}`: {m.get('description', '')}")
    if typ.get("when_to_use"):
        lines.append("\n**When to use:**")
        for item in typ["when_to_use"]:
            lines.append(f"- {item}")
    if typ.get("when_not_to_use"):
        lines.append("\n**When NOT to use:**")
        for item in typ["when_not_to_use"]:
            lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)


def format_guide(guide: dict) -> str:
    """Format a decision guide entry as readable markdown."""
    lines = [
        f"### {guide['id']}",
        f"**Question:** {guide.get('question', '')}",
        f"**Category:** {guide.get('category', '')}",
    ]
    if guide.get("important_defaults"):
        defaults = guide["important_defaults"]
        if defaults.get("note"):
            lines.append(f"\n**Important:** {defaults['note'].strip()}")
    if guide.get("decision_tree"):
        lines.append(f"\n**Decision tree:**\n```\n{guide['decision_tree'].strip()}\n```")
    if guide.get("conditions"):
        cond = guide["conditions"]
        for key, items in cond.items():
            lines.append(f"\n**{key.replace('_', ' ').title()}:**")
            if isinstance(items, list):
                for item in items:
                    lines.append(f"- {item}")
    if guide.get("comparison"):
        lines.append("\n**Comparison:**")
        for key, vals in guide["comparison"].items():
            if isinstance(vals, dict):
                summary = ", ".join(f"{k}: {v}" for k, v in vals.items())
                lines.append(f"- **{key}**: {summary}")
    lines.append("")
    return "\n".join(lines)


def format_error(error: dict) -> str:
    """Format an error entry as readable markdown."""
    lines = [
        f"### {error.get('title', error['id'])}",
        f"**Category:** {error.get('category', '')}",
    ]
    if error.get("message"):
        msg = error["message"][:300]
        lines.append(f"**Message:** {msg}")
    if error.get("message_codes"):
        lines.append(f"**Codes:** {', '.join(error['message_codes'])}")
    if error.get("explanation"):
        lines.append(f"\n**Explanation:** {error['explanation'][:500]}")
    if error.get("resolution"):
        lines.append(f"\n**Resolution:** {error['resolution'][:500]}")
    lines.append("")
    return "\n".join(lines)


# ── Internal helpers ──


def _load_yaml_list(path: Path, key: str) -> list[dict]:
    """Load a YAML file and return the list under the given key."""
    if not path.exists():
        return []
    with open(path) as f:
        data = yaml.safe_load(f) or {}
    result = data.get(key, [])
    return result if isinstance(result, list) else []


def _matches(entry: dict, query: str, fields: list[str]) -> bool:
    """Check if any of the given fields contain the query string."""
    for f in fields:
        val = entry.get(f, "")
        if isinstance(val, str) and query in val.lower():
            return True
    return False


# ── Factory ──


def load_ontology(
    config_path: Path | None = None,
    env_var: str = "HLS_ONTOLOGY_PATH",
    default: str = "~/hls-codegen-ontology",
) -> Ontology:
    """Resolve ontology path and return loaded Ontology.

    Resolution order: config_path > env var > default.
    """
    if config_path:
        p = config_path
    elif os.environ.get(env_var):
        p = Path(os.environ[env_var])
    else:
        p = Path(default).expanduser()

    p = p.expanduser().resolve()
    ont = Ontology(path=p)
    ont.load()
    return ont

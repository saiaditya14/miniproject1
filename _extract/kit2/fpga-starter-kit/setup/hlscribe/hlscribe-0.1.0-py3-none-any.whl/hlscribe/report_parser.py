"""Parse Vitis HLS csynth reports (XML and text) into structured metrics."""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

from hlscribe.project import Design


@dataclass
class SynthesisMetrics:
    sol: str
    latency_min: int | None = None
    latency_max: int | None = None
    latency_avg: int | None = None
    interval_min: int | None = None   # II min
    interval_max: int | None = None   # II max
    bram: int | None = None
    dsp: int | None = None
    ff: int | None = None
    lut: int | None = None
    uram: int | None = None
    clock_target: str | None = None
    clock_achieved: str | None = None
    # New fields
    clock_uncertainty: str | None = None
    pipeline_type: str | None = None        # "no", "dataflow", "pipeline"
    realtime_best: str | None = None        # e.g. "0.762 us"
    realtime_avg: str | None = None         # e.g. "10.330 ms"
    realtime_worst: str | None = None       # e.g. "82.303 ms"
    bram_avail: int | None = None
    dsp_avail: int | None = None
    ff_avail: int | None = None
    lut_avail: int | None = None
    uram_avail: int | None = None
    cosim_cycles: int | None = None         # actual sim total execution time
    cosim_status: str | None = None         # "Pass" / "Fail"


def _int_or_none(text: str | None) -> int | None:
    if text is None:
        return None
    text = text.strip()
    if not text or text == "?":
        return None
    try:
        return int(text)
    except ValueError:
        return None


def _parse_xml(path: Path, sol: str) -> SynthesisMetrics:
    """Parse a *_csynth.xml report."""
    tree = ET.parse(path)
    root = tree.getroot()

    def find_text(xpath: str) -> str | None:
        el = root.find(xpath)
        return el.text if el is not None else None

    # Performance
    perf = ".//PerformanceEstimates/SummaryOfOverallLatency/"
    timing = ".//PerformanceEstimates/SummaryOfTimingAnalysis/"

    # Resources (used)
    res = ".//AreaEstimates/Resources/"
    # Resources (available)
    avail = ".//AreaEstimates/AvailableResources/"

    # DSP: try DSP48E first (Vitis < 2025.1), fall back to DSP (Vitis 2025.1+)
    dsp_val = _int_or_none(find_text(res + "DSP48E"))
    if dsp_val is None:
        dsp_val = _int_or_none(find_text(res + "DSP"))

    dsp_avail_val = _int_or_none(find_text(avail + "DSP48E"))
    if dsp_avail_val is None:
        dsp_avail_val = _int_or_none(find_text(avail + "DSP"))

    # Pipeline type
    pipeline_type = find_text(".//PerformanceEstimates/PipelineType")

    # Clock uncertainty
    clock_uncertainty = find_text(".//UserAssignments/ClockUncertainty")

    return SynthesisMetrics(
        sol=sol,
        latency_min=_int_or_none(find_text(perf + "Best-caseLatency")),
        latency_max=_int_or_none(find_text(perf + "Worst-caseLatency")),
        latency_avg=_int_or_none(find_text(perf + "Average-caseLatency")),
        interval_min=_int_or_none(find_text(perf + "Interval-min")),
        interval_max=_int_or_none(find_text(perf + "Interval-max")),
        bram=_int_or_none(find_text(res + "BRAM_18K")),
        dsp=dsp_val,
        ff=_int_or_none(find_text(res + "FF")),
        lut=_int_or_none(find_text(res + "LUT")),
        uram=_int_or_none(find_text(res + "URAM")),
        clock_target=find_text(timing + "TargetClockPeriod"),
        clock_achieved=find_text(timing + "EstimatedClockPeriod"),
        clock_uncertainty=clock_uncertainty,
        pipeline_type=pipeline_type,
        realtime_best=find_text(perf + "Best-caseRealTimeLatency"),
        realtime_avg=find_text(perf + "Average-caseRealTimeLatency"),
        realtime_worst=find_text(perf + "Worst-caseRealTimeLatency"),
        bram_avail=_int_or_none(find_text(avail + "BRAM_18K")),
        dsp_avail=dsp_avail_val,
        ff_avail=_int_or_none(find_text(avail + "FF")),
        lut_avail=_int_or_none(find_text(avail + "LUT")),
        uram_avail=_int_or_none(find_text(avail + "URAM")),
    )


def _parse_rpt(path: Path, sol: str) -> SynthesisMetrics:
    """Parse a *_csynth.rpt text report (fallback)."""
    text = path.read_text()

    def search_int(pattern: str) -> int | None:
        m = re.search(pattern, text)
        return int(m.group(1)) if m else None

    def search_str(pattern: str) -> str | None:
        m = re.search(pattern, text)
        return m.group(1) if m else None

    return SynthesisMetrics(
        sol=sol,
        latency_min=search_int(r"\|\s*Latency.*?\|\s*(\d+)\s*\|\s*\d+\s*\|"),
        latency_max=search_int(r"\|\s*Latency.*?\|\s*\d+\s*\|\s*(\d+)\s*\|"),
        interval_min=search_int(r"\|\s*Interval.*?\|\s*(\d+)\s*\|"),
        bram=search_int(r"\|\s*BRAM_18K\s*\|\s*(\d+)"),
        dsp=search_int(r"\|\s*DSP(?:48E?)?\s*\|\s*(\d+)"),
        ff=search_int(r"\|\s*FF\s*\|\s*(\d+)"),
        lut=search_int(r"\|\s*LUT\s*\|\s*(\d+)"),
        uram=search_int(r"\|\s*URAM\s*\|\s*(\d+)"),
        clock_target=search_str(r"Target.*?:\s*([\d.]+)\s*ns"),
        clock_achieved=search_str(r"(?:Estimated|Achieved).*?:\s*([\d.]+)\s*ns"),
    )


def _find_csynth_report(design: Design, sol: str) -> Path | None:
    """Find the **top-level** csynth report for a given solution.

    Vitis emits one csynth report per HLS function: `<func>_csynth.xml`
    for each top-level and sub-function, plus `<func>_Pipeline_<loop>_
    csynth.xml` for inner loops. The previous implementation returned
    the alphabetically-first match from a recursive glob, which often
    picked an inner-loop or entry-proc stub (tiny latency, near-zero
    resources) instead of the actual top-level kernel.

    The fix: prefer `<top_function>_csynth.xml` (read top_function from
    the project's hlscribe.yaml). Fall back to a size-based heuristic
    (largest non-sub-module XML) if top_function can't be determined —
    the top-level kernel's report is typically the largest because it
    references all sub-modules.
    """
    workspace = design.workspace_dir / sol
    if not workspace.exists():
        return None

    # Try to read top_function from hlscribe.yaml. If found, prefer
    # <top_function>_csynth.xml exactly.
    top_function: str | None = None
    try:
        import yaml as _yaml
        yaml_path = design.project.root / "hlscribe.yaml"
        if yaml_path.exists():
            data = _yaml.safe_load(yaml_path.read_text()) or {}
            top_function = data.get("top_function")
    except Exception:
        top_function = None

    for ext in (".xml", ".rpt"):
        # Pattern restricted to syn/report first (the canonical location);
        # fall back to any path.
        for pattern in (f"**/syn/report/*_csynth{ext}", f"**/*_csynth{ext}"):
            matches = list(workspace.glob(pattern))
            if not matches:
                continue

            # Preferred: exact match on <top_function>_csynth.<ext>.
            if top_function:
                exact = [m for m in matches if m.name == f"{top_function}_csynth{ext}"]
                if exact:
                    return exact[0]

            # Fallback: filter out sub-module reports, pick the largest.
            def _is_submodule(p: Path) -> bool:
                n = p.name
                return ("_Pipeline_" in n
                        or "_Loop_" in n
                        or n == "entry_proc_csynth" + ext
                        or n == "csynth" + ext)  # aggregate, different layout

            non_submod = [m for m in matches if not _is_submodule(m)]
            candidates = non_submod or matches  # if all are sub-modules, use any
            # Largest file = top-level kernel (most module references).
            candidates.sort(key=lambda p: p.stat().st_size, reverse=True)
            return candidates[0]

    return None


def _find_cosim_report(design: Design, sol: str) -> Path | None:
    """Find cosim report for a given solution."""
    workspace = design.workspace_dir / sol
    if not workspace.exists():
        return None

    for pattern in ("**/sim/report/*_cosim.rpt", "**/reports/hls_cosim.rpt",
                     "**/*_cosim.rpt"):
        matches = list(workspace.glob(pattern))
        if matches:
            return matches[0]

    return None


def _parse_cosim_rpt(path: Path) -> tuple[str | None, int | None]:
    """Parse cosim report, return (status, total_cycles) from Verilog row.

    Cosim report table format (pipes delimit columns):
    |   RTL|  Status|  Latency min|  Latency avg|  Latency max|  ...  |  Total Execution Time|
    |   VHDL|       NA|          NA|          NA|          NA|  ...  |                    NA|
    |   Verilog|  Pass|       51677|       51677|       51677|  ...  |                 51677|
    """
    text = path.read_text()
    status = None
    cycles = None

    # Find the Verilog line in the table
    for line in text.splitlines():
        if re.search(r"\|\s*Verilog\s*\|", line, re.IGNORECASE):
            # Extract status (Pass/Fail)
            m_status = re.search(
                r"\|\s*Verilog\s*\|\s*(\w+)\s*\|", line, re.IGNORECASE
            )
            if m_status:
                status = m_status.group(1)

            # Total Execution Time is the last numeric column before the trailing pipe
            # Split by pipes and take the last non-empty field
            fields = [f.strip() for f in line.split("|") if f.strip()]
            if fields:
                last_field = fields[-1]
                m_cycles = re.match(r"(\d+)", last_field)
                if m_cycles:
                    cycles = int(m_cycles.group(1))
            break

    return status, cycles


def parse_csynth_report(design: Design, sol: str) -> SynthesisMetrics | None:
    """Parse csynth report from workspace/<sol>/."""
    path = _find_csynth_report(design, sol)
    if path is None:
        return None

    if path.suffix == ".xml":
        return _parse_xml(path, sol)
    return _parse_rpt(path, sol)


def collect_all_reports(design: Design) -> list[SynthesisMetrics]:
    """Collect reports for all built solutions."""
    results = []
    configs = design.list_configs()
    # Also check workspace dirs that may not have a .cfg anymore
    if design.workspace_dir.exists():
        ws_sols = [d.name for d in design.workspace_dir.iterdir() if d.is_dir()]
        for s in ws_sols:
            if s not in configs:
                configs.append(s)
    configs.sort()

    for sol in configs:
        m = parse_csynth_report(design, sol)
        if m is not None:
            # Merge cosim data if available
            cosim_path = _find_cosim_report(design, sol)
            if cosim_path:
                status, cycles = _parse_cosim_rpt(cosim_path)
                m.cosim_status = status
                m.cosim_cycles = cycles
            results.append(m)
    return results


def _res_col(used: int | None, avail: int | None) -> str:
    """Format a resource column as 'used/avail' or just 'used'."""
    if used is None:
        return "-"
    if avail is not None and avail > 0:
        return f"{used}/{avail}"
    return str(used)


def _build_table(cols: list[tuple[str, int, object]],
                  metrics: list[SynthesisMetrics]) -> str:
    """Render a list of (header, width, accessor) columns into a text table."""
    header = "  ".join(h.ljust(w) for h, w, _ in cols)
    sep = "  ".join("-" * w for _, w, _ in cols)
    rows = []
    for m in metrics:
        row = "  ".join(str(fn(m)).ljust(w) for _, w, fn in cols)
        rows.append(row)
    return "\n".join([header, sep] + rows)


def _has_extended_data(metrics: list[SynthesisMetrics]) -> bool:
    """Return True if any metric has data that belongs in the extended table."""
    for m in metrics:
        if any([m.uram, m.clock_target, m.clock_uncertainty,
                m.cosim_cycles is not None, m.pipeline_type,
                m.realtime_best, m.realtime_worst]):
            return True
    return False


def format_comparison_table(metrics: list[SynthesisMetrics]) -> str:
    """Format a two-tier comparison table for console display.

    Primary table:  Solution, latency, II, BRAM, DSP, FF, LUT, Clk(ns)
    Extended table:  URAM, Target, Uncertainty, Sim(cyc), Pipe, RT(best/worst)
    The extended table is only shown when data for it exists.
    """
    if not metrics:
        return "No synthesis reports found."

    # Dynamic width for solution column based on longest name
    sol_width = max(len("Solution"), max(len(m.sol) for m in metrics)) + 2

    # Helper: compute max width needed for resource columns with avail
    def res_width(header: str, used_fn, avail_fn, min_w: int = 6) -> int:
        w = len(header)
        for m in metrics:
            cell = _res_col(used_fn(m), avail_fn(m))
            w = max(w, len(cell))
        return max(w + 1, min_w)

    bram_w = res_width("BRAM", lambda m: m.bram, lambda m: m.bram_avail)
    dsp_w = res_width("DSP", lambda m: m.dsp, lambda m: m.dsp_avail)
    ff_w = res_width("FF", lambda m: m.ff, lambda m: m.ff_avail)
    lut_w = res_width("LUT", lambda m: m.lut, lambda m: m.lut_avail)

    # ── Primary table: performance & core resources ──
    primary_cols: list[tuple[str, int, object]] = [
        ("Solution", sol_width, lambda m: m.sol),
        ("Lat(min)", 10, lambda m: str(m.latency_min) if m.latency_min is not None else "-"),
        ("Lat(avg)", 10, lambda m: str(m.latency_avg) if m.latency_avg is not None else "-"),
        ("Lat(max)", 10, lambda m: str(m.latency_max) if m.latency_max is not None else "-"),
        ("II", 8, lambda m: str(m.interval_min) if m.interval_min is not None else "-"),
        ("BRAM", bram_w, lambda m: _res_col(m.bram, m.bram_avail)),
        ("DSP", dsp_w, lambda m: _res_col(m.dsp, m.dsp_avail)),
        ("FF", ff_w, lambda m: _res_col(m.ff, m.ff_avail)),
        ("LUT", lut_w, lambda m: _res_col(m.lut, m.lut_avail)),
        ("Clk(ns)", 8, lambda m: m.clock_achieved or "-"),
    ]

    parts = [_build_table(primary_cols, metrics)]

    # ── Extended table: only if there is data to show ──
    if _has_extended_data(metrics):
        uram_w = res_width("URAM", lambda m: m.uram, lambda m: m.uram_avail)

        ext_cols: list[tuple[str, int, object]] = [
            ("Solution", sol_width, lambda m: m.sol),
            ("URAM", uram_w, lambda m: _res_col(m.uram, m.uram_avail)),
            ("Target", 8, lambda m: m.clock_target or "-"),
            ("Uncert", 8, lambda m: m.clock_uncertainty or "-"),
            ("Sim(cyc)", 10, lambda m: str(m.cosim_cycles) if m.cosim_cycles is not None else "-"),
            ("Pipe", 10, lambda m: m.pipeline_type or "-"),
            ("RT(best)", 12, lambda m: m.realtime_best or "-"),
            ("RT(worst)", 12, lambda m: m.realtime_worst or "-"),
        ]

        parts.append("")
        parts.append(_build_table(ext_cols, metrics))

    return "\n".join(parts)

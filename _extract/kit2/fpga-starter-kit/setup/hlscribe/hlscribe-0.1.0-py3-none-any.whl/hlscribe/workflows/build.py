"""Build orchestration — local builds and Slurm submission."""

from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

from hlscribe.config import SlurmConfig
from hlscribe.project import Design


@dataclass
class BuildResult:
    sol: str
    stage: str
    success: bool
    return_code: int
    log_file: Path | None = None
    duration: float | None = None


def run_build(
    design: Design, stage: str, sol: str = "baseline", *, quiet: bool = False,
) -> BuildResult:
    """Run a local build: make <stage> SOL=<sol>.

    Args:
        quiet: If True, capture output silently (used by fix-loop).
               If False (default), stream output to terminal.
    """
    t0 = time.monotonic()
    result = subprocess.run(
        ["make", stage, f"SOL={sol}"],
        cwd=design.root,
        capture_output=quiet,
        text=True,
    )
    elapsed = time.monotonic() - t0

    log_stem = stage.replace("-", "_")
    log_file = design.logs_dir / f"{sol}_{log_stem}.log"

    return BuildResult(
        sol=sol,
        stage=stage,
        success=result.returncode == 0,
        return_code=result.returncode,
        log_file=log_file if log_file.exists() else None,
        duration=elapsed,
    )


def run_sweep(
    design: Design, stage: str, sols: list[str] | None = None
) -> list[BuildResult]:
    """Run local sweep across all (or specified) configs."""
    if sols is None:
        sols = design.list_configs()
    return [run_build(design, stage, sol) for sol in sols]


def submit_slurm(
    design: Design, stage: str, sols: list[str], cfg: SlurmConfig
) -> int:
    """Submit a Slurm array job via SSH. Returns job ID."""
    # Write solutions list
    design.logs_dir.mkdir(parents=True, exist_ok=True)
    sol_file = design.logs_dir / "slurm_solutions.txt"
    sol_file.write_text("\n".join(sols) + "\n")

    n = len(sols)
    design_path = str(design.root)

    sbatch_script = f"""#!/bin/bash
#SBATCH --job-name=hlscribe-{stage}
#SBATCH --array=1-{n}%{cfg.nodes}
#SBATCH --cpus-per-task={cfg.cpus}
#SBATCH --mem={cfg.mem}
#SBATCH --time={cfg.time}
#SBATCH --partition={cfg.partition}
#SBATCH --output={design_path}/artifacts/logs/slurm_%A_%a.out

SOLUTION=$(sed -n "${{SLURM_ARRAY_TASK_ID}}p" "{design_path}/artifacts/logs/slurm_solutions.txt")
echo "Task ${{SLURM_ARRAY_TASK_ID}}: ${{SOLUTION}}"
cd "{design_path}"
MODE={stage} SOLUTION=${{SOLUTION}} bash scripts/build_hls.sh
"""

    # Submit via SSH
    cmd = ["ssh", cfg.ssh_target, "sbatch", "--parsable"]
    result = subprocess.run(
        cmd, input=sbatch_script, capture_output=True, text=True
    )

    if result.returncode != 0:
        raise RuntimeError(f"sbatch failed: {result.stderr.strip()}")

    job_id = int(result.stdout.strip().split(";")[0])

    # Save metadata
    meta_dir = design.root / ".hlscribe"
    meta_dir.mkdir(parents=True, exist_ok=True)
    meta = {
        "job_id": job_id,
        "mode": stage,
        "num_tasks": n,
        "solutions": sols,
    }
    (meta_dir / "slurm_job.json").write_text(json.dumps(meta, indent=2) + "\n")

    return job_id


def list_configs(design: Design) -> list[str]:
    """List available config names (sans .cfg extension)."""
    return design.list_configs()

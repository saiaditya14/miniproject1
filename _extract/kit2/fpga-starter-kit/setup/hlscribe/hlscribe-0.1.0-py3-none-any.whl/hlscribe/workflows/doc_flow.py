"""Interactive document workflow — requirements gathering and interface specification."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from rich.console import Console
from rich.markdown import Markdown

from hlscribe.config import AppConfig
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology
from hlscribe.project import Project
from hlscribe.workflows.arch_flow import (
    _backup_if_exists,
    _build_ontology_context,
    _build_platform_context,
    _refinement_loop,
    format_hints,
    load_hints,
)


@dataclass
class DocResult:
    """Result from an interactive document workflow."""

    content: str
    doc_type: str  # "requirements" or "interface-spec"
    rounds: int  # refinement rounds
    saved_to: Path | None


# ── Private helpers ──


def _build_system_prompt(
    template_name: str,
    ont: Ontology | None,
    platform,
    context_text: str,
    prompt_variant: str | None = None,
    project_root: Path | None = None,
) -> str:
    """Build the full system prompt with platform and ontology context injected."""
    if prompt_variant:
        variant_path = Path(prompt_variant)
        if variant_path.is_file():
            template = variant_path.read_text()
        else:
            # e.g. ra_minimal_system.md or interface_streaming_system.md
            base = template_name.replace("_system.md", "")
            name = f"{base}_{prompt_variant}_system.md"
            template = load_template(name, project_root)
    else:
        template = load_template(template_name, project_root)

    platform_ctx = _build_platform_context(platform)
    ontology_ctx = _build_ontology_context(ont, context_text)

    return (
        template
        .replace("{platform_context}", platform_ctx)
        .replace("{ontology_context}", ontology_ctx)
    )


def _run_doc_flow(
    project: Project,
    cfg: AppConfig,
    console: Console,
    *,
    doc_type: str,
    prompt_name: str,
    initial_context: str,
    save_fn: Callable[[str], None],
    save_path: Path,
    prompt_label: str,
    prompt_variant: str | None,
    ont: Ontology | None,
) -> DocResult:
    """Interactive document generation with refinement loop.

    Flow: build system prompt → initial generation → display →
          REPL (feedback → refine, "done"/"save" → backup + save) → return DocResult.
    """
    system_prompt = _build_system_prompt(
        prompt_name, ont, cfg.platform, initial_context,
        prompt_variant, project.root,
    )

    console.print(f"\n[bold]{doc_type}[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    if cfg.platform:
        console.print(f"  Platform: [cyan]{cfg.platform.name}[/cyan]")
    console.print()

    history: list[dict] = []

    # Initial generation
    verb = "Refining" if save_path.exists() else "Generating"
    try:
        with console.status(f"[dim]{verb} {doc_type.lower()}...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, initial_context,
                              tag=f"{doc_type.lower()}-generate")
        console.print()
        console.print(Markdown(reply))
        console.print()
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        return DocResult(content="", doc_type=doc_type, rounds=0, saved_to=None)

    # Refinement loop
    result = _refinement_loop(
        cfg, console, system_prompt, history,
        label=prompt_label, doc_type=doc_type,
    )

    saved_to = None
    if result.content and result.should_save:
        _backup_if_exists(save_path, console)
        save_fn(result.content)
        saved_to = save_path
        console.print(f"[green]Saved {doc_type.lower()} to:[/green] {saved_to}")

    return DocResult(
        content=result.content,
        doc_type=doc_type,
        rounds=result.rounds,
        saved_to=saved_to,
    )


# ── Public wrappers ──


def run_ra(
    project: Project,
    cfg: AppConfig,
    console: Console,
    *,
    description: str = "",
    hints: str = "",
    prompt_variant: str | None = None,
    ont: Ontology | None = None,
    auto: bool = False,
) -> DocResult:
    """Gather and refine project requirements interactively."""
    existing = project.read_requirements()

    parts = []
    if description:
        parts.append(f"## Project Description\n\n{description}\n")
    if existing:
        parts.append(f"## Existing Requirements\n\nPlease review and refine these:\n\n{existing}\n")
    if hints:
        parts.append(f"## Additional Hints\n\n{hints}\n")
    if not parts:
        parts.append(
            "I'd like to define requirements for a new hardware accelerator project. "
            "Please ask me questions to understand the computational problem."
        )

    if auto:
        parts.append(
            "## Mode: Auto-generate\n\n"
            "Make your best assumptions for any missing details. "
            "Do NOT ask clarifying questions — instead, state each assumption "
            "explicitly in the document and produce the **complete** requirements "
            "document immediately. The user can refine afterward."
        )

    initial_context = "\n".join(parts)

    return _run_doc_flow(
        project, cfg, console,
        doc_type="Requirements Analysis",
        prompt_name="ra_system.md",
        initial_context=initial_context,
        save_fn=project.write_requirements,
        save_path=project.requirements_file,
        prompt_label="ra",
        prompt_variant=prompt_variant,
        ont=ont,
    )


def run_interface(
    project: Project,
    cfg: AppConfig,
    console: Console,
    *,
    hints: str = "",
    prompt_variant: str | None = None,
    ont: Ontology | None = None,
    auto: bool = False,
) -> DocResult:
    """Define HLS interface specification interactively."""
    requirements = project.read_requirements()
    existing_iface = project.read_interface()

    parts = []
    if requirements:
        parts.append(f"## Project Requirements\n\n{requirements}\n")
    else:
        console.print("[yellow]Warning: No requirements found in specs/.[/yellow]")
        console.print("[dim]Run 'hlscribe ra' first for best results.[/dim]\n")

    if existing_iface:
        parts.append(f"## Existing Interface Specification\n\nPlease review and refine:\n\n{existing_iface}\n")
    if hints:
        parts.append(f"## Additional Hints\n\n{hints}\n")
    if not parts:
        parts.append(
            "Define the HLS interface specification for this project. "
            "Please ask me questions about the data flow and interface requirements."
        )

    if auto:
        parts.append(
            "## Mode: Auto-generate\n\n"
            "Make your best assumptions for any missing details. "
            "Do NOT ask clarifying questions — instead, state each assumption "
            "explicitly in the document and produce the **complete** interface "
            "specification immediately. The user can refine afterward."
        )

    initial_context = "\n".join(parts)

    return _run_doc_flow(
        project, cfg, console,
        doc_type="Interface Specification",
        prompt_name="interface_system.md",
        initial_context=initial_context,
        save_fn=project.write_interface,
        save_path=project.interface_file,
        prompt_label="iface",
        prompt_variant=prompt_variant,
        ont=ont,
    )

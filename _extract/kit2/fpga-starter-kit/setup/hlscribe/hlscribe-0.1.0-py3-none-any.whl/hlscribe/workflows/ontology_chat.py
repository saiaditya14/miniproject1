"""Interactive Q&A with the HLS ontology (LLM-powered)."""

from __future__ import annotations

from rich.console import Console
from rich.markdown import Markdown

from hlscribe.config import AppConfig
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology


def _load_system_template() -> str:
    """Load the ontology system prompt template."""
    return load_template("ontology_system.md")


def _build_system_prompt(ont: Ontology, user_message: str) -> str:
    """Build system prompt with relevant ontology context injected."""
    template = _load_system_template()

    # Get ontology context relevant to the user's question
    context = ont.get_relevant_context(user_message)

    # Also search for direct matches
    search_results = ont.search(user_message)
    if search_results:
        from hlscribe.ontology import (
            format_error,
            format_guide,
            format_pattern,
            format_pragma,
            format_type,
        )
        formatters = {
            "pragma": format_pragma,
            "pattern": lambda e: format_pattern(e, ont.examples_dir),
            "type": format_type,
            "guide": format_guide,
            "error": format_error,
        }
        extra = []
        seen = set()
        for r in search_results[:8]:
            cat = r["category"]
            entry = r["entry"]
            key = (cat, entry.get("name") or entry.get("id", ""))
            if key not in seen:
                seen.add(key)
                formatter = formatters.get(cat)
                if formatter:
                    extra.append(formatter(entry))
        if extra:
            if context:
                context += "\n\n## Search Results\n\n" + "\n".join(extra)
            else:
                context = "## Ontology Search Results\n\n" + "\n".join(extra)

    if not context:
        context = "(No specific ontology entries matched. Answer from general HLS knowledge.)"

    return template.replace("{ontology_context}", context)


def run_ontology_chat(ont: Ontology, cfg: AppConfig, console: Console) -> None:
    """Run interactive ontology Q&A loop."""
    console.print("\n[bold]HLS Ontology Chat[/bold]")
    console.print(f"  Ontology: [dim]{ont.path}[/dim]")
    s = ont.stats
    console.print(
        f"  Loaded: {s.num_pragmas} pragmas, {s.num_patterns} patterns, "
        f"{s.num_types} types, {s.num_guides} guides, {s.num_errors} errors"
    )
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"\n  Type your question. Enter [bold]quit[/bold] or [bold]exit[/bold] to stop.\n")

    history: list[dict] = []

    while True:
        try:
            user_input = console.input("[bold green]you>[/bold green] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            console.print("[dim]Goodbye.[/dim]")
            break
        if user_input.lower() == "reset":
            history.clear()
            console.print("[dim]Conversation cleared.[/dim]\n")
            continue

        # Build context-aware system prompt for this turn
        system_prompt = _build_system_prompt(ont, user_input)

        try:
            with console.status("[dim]Thinking...[/dim]"):
                reply = chat_once(cfg, system_prompt, history, user_input, tag="ontology-chat")
            console.print()
            console.print(Markdown(reply))
            console.print()
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]\n")

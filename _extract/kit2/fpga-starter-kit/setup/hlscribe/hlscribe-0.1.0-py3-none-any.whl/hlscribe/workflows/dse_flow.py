"""DSE workflow — LLM-based intelligent config generation."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

from hlscribe.config import AppConfig
from hlscribe.config_gen import (
    ConfigVariant,
    build_constraint_space,
    detect_top_function,
    format_constraint_space,
    load_base_header,
    write_configs,
)
from hlscribe.extract import extract_cfg_blocks
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology
from hlscribe.project import Design, Project
from hlscribe.workflows.arch_flow import (
    _build_ontology_context,
    _build_platform_context,
)
from hlscribe.workflows.codegen_flow import _load_specs, _report_ontology


@dataclass
class DseGenResult:
    """Result from LLM-based config generation."""

    configs: list[ConfigVariant] = field(default_factory=list)
    num_generated: int = 0
    written_paths: list[Path] = field(default_factory=list)


def run_dse_gen(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    num_configs: int = 10,
    ont: Ontology | None = None,
) -> DseGenResult:
    """Generate DSE configurations using LLM intelligence.

    Flow:
      1. Read kernel → build constraint space
      2. Load project specs
      3. Build system + user prompts
      4. LLM call → extract config blocks
      5. Convert to ConfigVariant → write .cfg files
    """
    result = DseGenResult()

    # Read kernel — prefer DSE kernel when available
    if design.dse_kernel_file.exists():
        kernel_code = design.read_dse_kernel()
        console.print("  [dim]Source: kernel_dse.cpp[/dim]")
    elif design.kernel_file.exists():
        kernel_code = design.read_kernel()
    else:
        console.print("[red]No kernel found in src/.[/red]")
        console.print("[dim]Run 'hlscribe codegen' first to generate kernel code.[/dim]")
        raise SystemExit(1)

    top = detect_top_function(kernel_code)

    # Build constraint space
    space = build_constraint_space(kernel_code, top)
    constraint_text = format_constraint_space(space)

    # Load specs
    specs = _load_specs(project, design)
    context_text = "\n".join(
        specs.get(k, "") for k in ("requirements", "architecture", "interface")
    )

    # Console header
    console.print("\n[bold]DSE Config Generation (LLM)[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Design:  [cyan]{design.name}[/cyan]")
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"  Configs: [cyan]{num_configs}[/cyan]")

    # Ontology context
    ontology_ctx = _report_ontology(ont, context_text, design, console, cfg=cfg)
    console.print()

    # Build system prompt
    platform_ctx = _build_platform_context(cfg.platform)
    system_template = load_template("dse_system.md", project.root)
    system_prompt = (
        system_template
        .replace("{platform_context}", platform_ctx)
        .replace("{ontology_context}", ontology_ctx)
    )

    # Build user message
    user_template = load_template("dse_gen_configs.md", project.root)
    # Load DSE lessons (optional)
    dse_lessons = ""
    try:
        dse_lessons = load_template("lessons_dse.md", project.root)
    except FileNotFoundError:
        pass
    user_message = (
        user_template
        .replace("{num_configs}", str(num_configs))
        .replace("{project_name}", project.name)
        .replace("{top_function}", top)
        .replace("{kernel_code}", kernel_code)
        .replace("{constraint_space}", constraint_text)
        .replace("{requirements_context}", specs.get("requirements") or "_No requirements available._")
        .replace("{architecture_context}", specs.get("architecture") or "_No architecture available._")
        .replace("{interface_context}", specs.get("interface") or "_No interface spec available._")
        .replace("{dse_lessons}", dse_lessons or "_No DSE lessons available._")
    )

    # LLM call
    history: list[dict] = []
    try:
        with console.status("[dim]Generating configurations...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_message, tag="dse-gen-configs")
    except Exception as e:
        console.print(f"[red]LLM error: {e}[/red]")
        return result

    # Extract configs from response
    extracted = extract_cfg_blocks(reply)
    if not extracted:
        console.print("[yellow]No config blocks found in LLM response.[/yellow]")
        console.print("[dim]Raw response saved to artifacts/dse_gen_response.md[/dim]")
        artifacts_dir = design.root / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        (artifacts_dir / "dse_gen_response.md").write_text(reply)
        return result

    # Convert to ConfigVariant
    configs: list[ConfigVariant] = []
    for ec in extracted:
        desc = ec.rationale or ec.strategy or ec.name
        configs.append(ConfigVariant(
            name=ec.name,
            directives=ec.directives,
            description=desc,
        ))

    # Write .cfg files
    base_header = load_base_header(design.root, top, prefer_dse=design.dse_kernel_file.exists())
    paths = write_configs(configs, design.configs_dir, base_header=base_header)

    result.configs = configs
    result.num_generated = len(configs)
    result.written_paths = paths

    # Save raw response for debugging
    artifacts_dir = design.root / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    (artifacts_dir / "dse_gen_response.md").write_text(reply)

    # Print summary
    console.print(f"\n[bold]Generated {len(configs)} configuration(s)[/bold]\n")
    for i, (cv, path) in enumerate(zip(configs, paths)):
        strategy_color = {
            "conservative": "green",
            "moderate": "yellow",
            "aggressive": "red",
        }.get(extracted[i].strategy, "white")
        strategy_label = f" [{strategy_color}]({extracted[i].strategy})[/{strategy_color}]" if extracted[i].strategy else ""
        console.print(f"  [cyan]{path.name:<30}[/cyan]{strategy_label}")
        if cv.description:
            console.print(f"    [dim]{cv.description}[/dim]")

    console.print(f"\n  Written to: {design.configs_dir}")
    console.print(f"  [dim]LLM response: {artifacts_dir / 'dse_gen_response.md'}[/dim]")

    return result

"""Import pre-built kernel source files into a design for multi-file composition."""

from __future__ import annotations

import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import yaml

from hlscribe.project import Design

RESERVED_NAMES = {"kernel.cpp", "host.cpp", "kernel_tb.cpp"}

_FUNC_SIG_RE = re.compile(
    r"^\s*(?:void|int|unsigned|float|double|bool|ap_\w+|hls::\w+[<>:\w]*)"
    r"\s+(\w+)\s*\([^)]*\)\s*[;{]",
    re.MULTILINE,
)


@dataclass
class ImportRecord:
    """One import operation — a group of files imported together."""

    files: list[str]
    source: str
    spec: str = ""
    spec_file: str | None = None
    imported_at: str = ""


def import_files(
    design: Design,
    sources: list[Path],
    spec: str | None = None,
    spec_file: Path | None = None,
) -> ImportRecord:
    """Copy source files into design/src/ and record in imports.yaml.

    Raises ValueError for reserved filenames.
    Returns the ImportRecord written to the manifest.
    """
    # Validate no reserved names
    for src in sources:
        if src.name in RESERVED_NAMES:
            raise ValueError(
                f"Cannot import reserved filename '{src.name}'. "
                f"Reserved: {', '.join(sorted(RESERVED_NAMES))}"
            )

    design.src_dir.mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    source_dir = ""

    for src in sources:
        dest = design.src_dir / src.name
        shutil.copy2(src, dest)
        copied.append(src.name)
        source_dir = str(src.parent.resolve())

    # Copy spec file if provided
    spec_file_name: str | None = None
    if spec_file is not None:
        dest = design.src_dir / spec_file.name
        shutil.copy2(spec_file, dest)
        spec_file_name = spec_file.name

    record = ImportRecord(
        files=sorted(copied),
        source=source_dir,
        spec=spec or "",
        spec_file=spec_file_name,
        imported_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )

    # Append to manifest
    manifest = design.imports_manifest
    existing = _read_manifest(manifest)
    existing.append(_record_to_dict(record))
    manifest.write_text(yaml.dump(existing, default_flow_style=False, sort_keys=False))

    return record


def load_imports(design: Design) -> list[ImportRecord]:
    """Load all import records from the design's imports.yaml."""
    raw = _read_manifest(design.imports_manifest)
    records = []
    for entry in raw:
        records.append(
            ImportRecord(
                files=entry.get("files", []),
                source=entry.get("source", ""),
                spec=entry.get("spec", ""),
                spec_file=entry.get("spec_file"),
                imported_at=entry.get("imported_at", ""),
            )
        )
    return records


def build_imports_context(design: Design) -> str:
    """Build a markdown block describing imported components for prompt injection.

    Returns "" if no imports exist.
    """
    records = load_imports(design)
    if not records:
        return ""

    lines = [
        "## Imported Components\n",
        "Pre-built, tested source files in `src/`. "
        "`#include` the header and call the functions.",
        "Do NOT rewrite their internals.\n",
    ]

    for rec in records:
        headers = [f for f in rec.files if f.endswith((".h", ".hpp"))]
        cpps = [f for f in rec.files if f.endswith(".cpp")]

        for hdr in headers:
            hdr_path = design.src_dir / hdr
            if hdr_path.exists():
                content = hdr_path.read_text()
                lines.append(f"### {hdr}")
                lines.append(f"```cpp\n{content.strip()}\n```")
            else:
                lines.append(f"### {hdr} *(file missing)*")

        # If no headers, extract signatures from .cpp files
        if not headers:
            for cpp in cpps:
                cpp_path = design.src_dir / cpp
                if cpp_path.exists():
                    sigs = _extract_signatures(cpp_path.read_text())
                    if sigs:
                        lines.append(f"### {cpp} (signatures)")
                        lines.append(f"```cpp\n{chr(10).join(sigs)}\n```")

        if rec.spec:
            lines.append(f"Spec: {rec.spec}")

        if rec.spec_file:
            sf_path = design.src_dir / rec.spec_file
            if sf_path.exists():
                lines.append(f"\n#### Detailed Spec ({rec.spec_file})\n")
                lines.append(sf_path.read_text().strip())

        lines.append("")

    return "\n".join(lines)


# ── Internal helpers ──


def _read_manifest(path: Path) -> list[dict]:
    if not path.exists():
        return []
    data = yaml.safe_load(path.read_text())
    if isinstance(data, list):
        return data
    return []


def _record_to_dict(rec: ImportRecord) -> dict:
    d: dict = {
        "files": rec.files,
        "source": rec.source,
    }
    if rec.spec:
        d["spec"] = rec.spec
    if rec.spec_file:
        d["spec_file"] = rec.spec_file
    d["imported_at"] = rec.imported_at
    return d


def _extract_signatures(code: str) -> list[str]:
    """Extract function signatures from C++ source via regex."""
    return [m.group(0).rstrip("{").strip().rstrip() + ";" for m in _FUNC_SIG_RE.finditer(code)]

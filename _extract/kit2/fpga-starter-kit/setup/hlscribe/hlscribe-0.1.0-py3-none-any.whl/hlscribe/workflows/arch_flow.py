"""Architecture design workflow — interactive refinement or multi-proposal generation."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import shutil
from datetime import datetime

import yaml
from rich.console import Console
from rich.markdown import Markdown

from hlscribe.config import AppConfig
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology
from hlscribe.platforms import Platform
from hlscribe.project import Project

# Default focus areas when no hints specify optimization_focus
_DEFAULT_FOCUSES = [
    "Minimum latency — optimize for lowest possible latency per input",
    "Maximum throughput — optimize for highest sustained throughput (items/sec)",
    "Minimum resources — optimize for smallest FPGA footprint",
    "Power efficiency — balance throughput with minimal resource usage",
    "Balanced — moderate latency, throughput, and resource usage",
]


@dataclass
class ArchResult:
    """Result from an architecture generation run."""

    content: str
    mode: str  # "single" or "multi"
    num_proposals: int
    rounds: int  # interactive refinement rounds (0 for multi)
    saved_to: Path | None
    proposal_files: list[Path] = field(default_factory=list)


# ── Hints loading ──


def load_hints(hints_path: Path) -> dict:
    """Load architectural hints from a YAML or markdown file.

    YAML/YML files are parsed as structured data.
    Markdown/text files are returned as {"text": content}.
    """
    suffix = hints_path.suffix.lower()
    content = hints_path.read_text()

    if suffix in (".yaml", ".yml"):
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            return {"text": str(data)}
        return data

    return {"text": content}


def format_hints(hints: dict) -> str:
    """Format hints dict into a string for prompt injection."""
    if "text" in hints and len(hints) == 1:
        return hints["text"]

    sections = []
    for key, value in hints.items():
        if isinstance(value, list):
            items = "\n".join(f"- {v}" for v in value)
            sections.append(f"**{key}**:\n{items}")
        elif isinstance(value, dict):
            items = "\n".join(f"- {k}: {v}" for k, v in value.items())
            sections.append(f"**{key}**:\n{items}")
        else:
            sections.append(f"**{key}**: {value}")

    return "\n\n".join(sections)


# ── Prompt building ──


def _build_platform_context(platform: Platform | None) -> str:
    """Build platform context string for prompt injection."""
    if platform is None:
        return ""

    return (
        f"## Target Platform\n\n"
        f"- **Device**: {platform.name} ({platform.device})\n"
        f"- **Family**: {platform.family}\n"
        f"- **Resources**: LUT={platform.lut:,} FF={platform.ff:,} "
        f"BRAM={platform.bram} URAM={platform.uram} DSP={platform.dsp}\n"
        f"- **Memory**: {platform.memory}\n"
        f"- **Clock**: {platform.clock}\n"
    )


def _formulate_rag_query(
    cfg: AppConfig,
    spec_text: str,
    detected_patterns: list[str],
) -> str:
    """Use a lightweight LLM call to formulate a focused RAG search query.

    Takes the raw spec text and any ontology-detected pattern names,
    returns a concise HLS-specific search query for semantic retrieval.
    """
    prompt = load_template("rag_query.md")

    user_msg = spec_text
    if detected_patterns:
        user_msg += f"\n\nDetected HLS patterns: {', '.join(detected_patterns)}"

    # Use a short max_tokens — we just need 2-3 sentences
    reply = chat_once(cfg, prompt, [], user_msg, max_tokens=256, tag="arch-rag-query")
    return reply.strip()


def parse_ontology_deps(architecture_md: str) -> list[str]:
    """Extract pattern IDs from the '## Ontology Dependencies' section of an
    architecture.md produced by the arch agent.

    Returns deduped list (insertion order preserved). Empty list if the section
    is missing — calling code should fall back to a baseline detector.
    """
    import re
    section_re = re.compile(
        r"(?im)^##\s+Ontology Dependencies\s*$(.*?)(?=^##\s|\Z)",
        re.DOTALL | re.MULTILINE,
    )
    m = section_re.search(architecture_md)
    if not m:
        return []
    item_re = re.compile(r"^[-*]\s*`?([a-z0-9][a-z0-9-]*)`?\s*$")
    seen: set[str] = set()
    result: list[str] = []
    for line in m.group(1).splitlines():
        m2 = item_re.match(line.strip())
        if m2:
            pid = m2.group(1)
            if pid not in seen:
                seen.add(pid)
                result.append(pid)
    return result


def _build_ontology_context(
    ont: Ontology | None,
    text: str,
    cfg: AppConfig | None = None,
    arch_md: str | None = None,
) -> str:
    """Build ontology context from requirements text.

    Layers up to three sources:
      1a. Keyword-based ontology search (default; free, instant), OR
      1b. Rich-MD path (cfg.rich_ontology): full per-pattern docs for the union
          of (arch-agent-declared deps from arch_md, keyword-top-3 baseline).
      2.  RAG semantic search over HLS docs (optional, requires index).

    arch_md is the architecture.md content; used to parse the agent-declared
    '## Ontology Dependencies' list when rich_ontology is enabled.
    """
    sections: list[str] = []

    detected_patterns: list[str] = []
    if ont is not None and not (cfg and getattr(cfg, "no_ontology", False)):
        rich = bool(cfg and getattr(cfg, "rich_ontology", False))
        if rich:
            # Rich-MD path: agent-declared deps + keyword baseline, full docs.
            declared_ids = parse_ontology_deps(arch_md) if arch_md else []
            baseline_ids = [pid for pid, _ in ont.detect_patterns_ranked(text)[:3]]
            all_ids: list[str] = []
            for pid in declared_ids + baseline_ids:
                if pid not in all_ids:
                    all_ids.append(pid)
            if all_ids:
                rich_parts = ["## Relevant HLS Patterns (rich docs)", ""]
                if declared_ids:
                    rich_parts.append(
                        f"_Agent-declared dependencies: {', '.join(declared_ids)}_"
                    )
                if baseline_ids:
                    rich_parts.append(
                        f"_Keyword-baseline top-3: {', '.join(baseline_ids)}_"
                    )
                rich_parts.append("")
                for pid in all_ids:
                    md = ont.get_pattern_doc_md(pid)
                    if md:
                        rich_parts.append(f"### Pattern: `{pid}`\n\n{md}")
                    # Append canonical example code (Vitis HLS examples) so the
                    # codegen sees a complete working kernel, not just abstract
                    # pattern docs. This is the producer/consumer-contract layer
                    # that pattern MDs alone do not carry.
                    examples = ont.get_pattern_examples_code(pid)
                    if examples:
                        rich_parts.append(
                            f"#### Canonical examples for `{pid}`\n"
                        )
                        for ex_name, ex_code in examples.items():
                            # Detect language for fence
                            lang = "cpp"
                            if ex_name.endswith((".h", ".hpp")):
                                lang = "cpp"
                            elif ex_name.endswith(".cfg"):
                                lang = "ini"
                            elif ex_name.endswith(".tcl"):
                                lang = "tcl"
                            elif ex_name.endswith(".py"):
                                lang = "python"
                            elif ex_name.endswith(".md"):
                                lang = ""
                            rich_parts.append(
                                f"##### `{ex_name}`\n\n```{lang}\n{ex_code}\n```"
                            )
                    p = ont.get_pattern(pid)
                    if p:
                        detected_patterns.append(p.get("name", pid))
                if any(p.startswith("### Pattern:") for p in rich_parts):
                    sections.append("\n\n".join(rich_parts))
        else:
            # 1a. Existing keyword path (default)
            kw_context = ont.get_relevant_context(text, max_patterns=5)
            if kw_context:
                sections.append(kw_context)
            for pid in ont.detect_patterns(text):
                p = ont.get_pattern(pid)
                if p:
                    detected_patterns.append(p.get("name", pid))
        # Decision-guides detection runs in both paths (feeds RAG query)
        for gid in ont.detect_guides(text):
            g = ont.get_guide(gid)
            if g:
                detected_patterns.append(g.get("name", gid))

    # 2. RAG search (optional, requires index; skipped when --no-rag)
    if not (cfg and getattr(cfg, "no_rag", False)):
        try:
            from hlscribe.rag import HLSRag
            rag = HLSRag()
            if rag.is_indexed:
                # Formulate a focused query via LLM if config is available
                if cfg is not None:
                    try:
                        query = _formulate_rag_query(cfg, text, detected_patterns)
                    except Exception:
                        query = text  # fall back to raw spec
                else:
                    query = text

                rag_context = rag.get_context(query, max_tokens=3000)
                if rag_context:
                    sections.append(f"## Reference Documentation\n\n{rag_context}")
        except (ImportError, Exception):
            pass  # graceful degradation — RAG not installed or not indexed

    if not sections:
        return ""

    return "## HLS Ontology Context\n\n" + "\n\n".join(sections)


def _build_system_prompt(
    ont: Ontology | None,
    platform: Platform | None,
    context_text: str,
    prompt_variant: str | None = None,
    project_root: Path | None = None,
    cfg: AppConfig | None = None,
) -> str:
    """Build the full system prompt with ontology and platform context injected."""
    if prompt_variant:
        # Check if variant looks like a file path (absolute or contains separator)
        variant_path = Path(prompt_variant)
        if variant_path.is_file():
            template = variant_path.read_text()
        else:
            template_name = f"arch_{prompt_variant}_system.md"
            template = load_template(template_name, project_root)
    else:
        template = load_template("arch_system.md", project_root)

    platform_ctx = _build_platform_context(platform)
    ontology_ctx = _build_ontology_context(ont, context_text, cfg=cfg)
    pattern_catalog = ont.catalog_text() if ont is not None else ""
    lessons_ctx = ""
    if "{lessons_context}" in template:
        try:
            lessons_ctx = load_template("lessons.md", project_root)
        except FileNotFoundError:
            lessons_ctx = ""

    return (
        template
        .replace("{platform_context}", platform_ctx)
        .replace("{ontology_context}", ontology_ctx)
        .replace("{pattern_catalog}", pattern_catalog)
        .replace("{lessons_context}", lessons_ctx)
    )


def _determine_focuses(hints: dict | None, num_proposals: int) -> str:
    """Determine proposal focus areas from hints or defaults."""
    if hints and "optimization_focus" in hints:
        focuses = hints["optimization_focus"]
        if isinstance(focuses, list):
            # Use provided focuses, cycling if fewer than num_proposals
            result = []
            for i in range(num_proposals):
                result.append(f"{i + 1}. {focuses[i % len(focuses)]}")
            return "\n".join(result)
        # Single focus string — use it as first, fill rest from defaults
        result = [f"1. {focuses}"]
        for i in range(1, num_proposals):
            idx = (i - 1) % len(_DEFAULT_FOCUSES)
            result.append(f"{i + 1}. {_DEFAULT_FOCUSES[idx]}")
        return "\n".join(result)

    # Use defaults (up to num_proposals)
    result = []
    for i in range(num_proposals):
        idx = i % len(_DEFAULT_FOCUSES)
        result.append(f"{i + 1}. {_DEFAULT_FOCUSES[idx]}")
    return "\n".join(result)


# ── LLM interaction ──


def _split_proposals(text: str) -> tuple[list[str], str]:
    """Split a multi-proposal response into individual proposals and comparison meta.

    Splits on ``## Proposal N:`` or ``### Proposal N:`` headings.
    Returns (proposals, meta) where *meta* is the trailing comparison /
    recommendation section (empty string if absent).

    Graceful fallback: if no proposal headings are found, returns
    ``([text], "")`` — the entire response is treated as one proposal.
    """
    # Find all proposal heading positions
    heading_pattern = re.compile(
        r"^(#{2,3})\s+Proposal\s+\d+\s*:", re.MULTILINE
    )
    matches = list(heading_pattern.finditer(text))

    if not matches:
        return ([text], "")

    # Find trailing meta section (Comparison / Recommendation after last proposal)
    meta_pattern = re.compile(
        r"^##\s+(?:Comparison|Recommendation)\b", re.MULTILINE
    )
    last_proposal_start = matches[-1].start()
    meta_match = meta_pattern.search(text, last_proposal_start)

    # End boundary for proposals content (start of meta, or end of text)
    proposals_end = meta_match.start() if meta_match else len(text)
    meta = text[proposals_end:].strip() if meta_match else ""

    # Split proposals
    proposals: list[str] = []
    for i, m in enumerate(matches):
        start = m.start()
        if i + 1 < len(matches):
            end = matches[i + 1].start()
        else:
            end = proposals_end
        proposals.append(text[start:end].strip())

    return (proposals, meta)


def _backup_if_exists(arch_file: Path, console: Console) -> None:
    """Back up an existing architecture file with a timestamp suffix."""
    if not arch_file.exists():
        return
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = arch_file.with_suffix(f".{ts}.md")
    shutil.copy2(arch_file, backup)
    console.print(f"[dim]Backed up existing architecture to:[/dim] {backup}")


# ── Shared REPL input helper ──


def _read_input(
    console: Console,
    label: str,
    hint: str = 'done | quit | """ for multiline',
) -> str | None:
    """Read single- or multi-line input from the user.

    Returns the input string, or ``None`` on EOF / Ctrl-C.
    """
    try:
        line = console.input(
            f"[bold green]{label}>[/bold green] [dim]({hint})[/dim] "
        ).strip()
    except (EOFError, KeyboardInterrupt):
        return None

    if line != '"""':
        return line

    # Multiline mode: accumulate until closing """
    console.print('[dim]  Multiline mode \u2014 type """ on its own line to submit[/dim]')
    lines: list[str] = []
    while True:
        try:
            ml = console.input("[dim]...[/dim] ")
        except (EOFError, KeyboardInterrupt):
            return None
        if ml.strip() == '"""':
            break
        lines.append(ml)
    return "\n".join(lines)


# ── Shared refinement REPL ──


@dataclass
class ReplResult:
    """Outcome of a refinement REPL session."""

    content: str  # last assistant message (may be empty if discarded)
    rounds: int
    should_save: bool


def _refinement_loop(
    cfg: AppConfig,
    console: Console,
    system_prompt: str,
    history: list[dict],
    label: str,
    doc_type: str,
) -> ReplResult:
    """Accumulating-feedback refinement REPL.

    Commands (entered on their own line):
        done      — send accumulated feedback to the LLM, display revised document,
                    then continue the loop for more feedback.
        save      — save the current document as-is (no LLM call) and exit.
        finalize  — ask the LLM to fill any gaps and produce the final version,
                    then save and exit.
        quit / q  — discard and exit.

    Any other input line is accumulated as feedback.  Blank lines are kept
    (allows paragraph breaks in feedback).
    """
    console.print(
        f"  Type feedback, then [bold]done[/bold] to send to LLM.\n"
        f"  [bold]save[/bold] to keep as-is, "
        f"[bold]finalize[/bold] to let LLM fill gaps, "
        f"[bold]quit[/bold]/[bold]q[/bold] to discard.\n"
    )

    rounds = 0
    should_save = True
    feedback_lines: list[str] = []

    while True:
        try:
            line = console.input(
                f"[bold green]{label}>[/bold green] "
            )
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Discarded.[/dim]")
            return ReplResult(content="", rounds=rounds, should_save=False)

        stripped = line.strip().lower()

        if stripped in ("quit", "exit", "q"):
            console.print("[dim]Discarded.[/dim]")
            return ReplResult(content="", rounds=rounds, should_save=False)

        if stripped == "save":
            # Save current document as-is
            content = ""
            for msg in reversed(history):
                if msg["role"] == "assistant":
                    content = msg["content"]
                    break
            return ReplResult(content=content, rounds=rounds, should_save=True)

        if stripped == "finalize":
            # Ask LLM to fill gaps, then save
            finalize_msg = (
                "Please review the document above. Fill in any gaps, resolve any "
                "open questions with reasonable assumptions (stated explicitly), "
                "and produce the complete, final version of the document."
            )
            if feedback_lines:
                # Include any pending feedback too
                pending = "\n".join(feedback_lines).strip()
                finalize_msg = f"{pending}\n\nThen {finalize_msg.lower()}"
                feedback_lines.clear()
            rounds += 1
            try:
                with console.status(f"[dim]Finalizing {doc_type.lower()}...[/dim]"):
                    reply = chat_once(cfg, system_prompt, history, finalize_msg,
                                      tag=f"{doc_type.lower()}-finalize")
                console.print()
                console.print(Markdown(reply))
                console.print()
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]\n")
            content = ""
            for msg in reversed(history):
                if msg["role"] == "assistant":
                    content = msg["content"]
                    break
            return ReplResult(content=content, rounds=rounds, should_save=True)

        if stripped == "done":
            # Send accumulated feedback to LLM
            feedback = "\n".join(feedback_lines).strip()
            if not feedback:
                console.print("[dim]No feedback to send. Type feedback first, then done.[/dim]")
                continue
            feedback_lines.clear()
            rounds += 1
            try:
                with console.status(f"[dim]Refining {doc_type.lower()}...[/dim]"):
                    reply = chat_once(cfg, system_prompt, history, feedback,
                                      tag=f"{doc_type.lower()}-feedback")
                console.print()
                console.print(Markdown(reply))
                console.print()
            except Exception as e:
                console.print(f"\n[red]Error: {e}[/red]\n")
            continue

        # Accumulate feedback
        feedback_lines.append(line)


# ── Interactive flow ──


def run_arch_interactive(
    project: Project,
    cfg: AppConfig,
    console: Console,
    ont: Ontology | None = None,
    hints: dict | None = None,
    prompt_variant: str | None = None,
    save_target=None,
    fresh: bool = False,
    use_dsl: bool = False,
    non_interactive: bool = False,
) -> ArchResult:
    """Generate architecture interactively with refinement rounds.

    Flow: load specs → build prompt → LLM generate → user feedback loop → save.

    When ``use_dsl=True`` the agent reads ``specs/spec.dsl`` as the sole
    specification, *in place of* ``requirements.md`` + ``interface-spec.md``.
    The prose specs are not consulted in DSL mode.

    When ``non_interactive=True``, skip the refinement REPL and auto-save
    the initial generation. Used by headless experiment runs that want
    the lean single-arch path without the multi-proposal scaffold of
    ``--nproposals 1``.
    """
    # Load project specs (DSL stand-alone OR prose; not both)
    if use_dsl:
        dsl_spec = project.read_spec_dsl()
        requirements = ""
        interface_spec = ""
        if not dsl_spec:
            console.print("[yellow]Warning: --use-dsl set but specs/spec.dsl not found or empty.[/yellow]")
    else:
        dsl_spec = ""
        requirements = project.read_requirements()
        interface_spec = ""
        if project.interface_file.exists():
            interface_spec = project.interface_file.read_text()
        if not requirements and not interface_spec:
            console.print("[yellow]Warning: No requirements or interface spec found in specs/.[/yellow]")
            console.print("[dim]Run 'hlscribe ra' and 'hlscribe interface-spec' first for best results.[/dim]\n")

    # Build system prompt
    context_text = dsl_spec if use_dsl else f"{requirements}\n{interface_spec}"
    system_prompt = _build_system_prompt(ont, cfg.platform, context_text, prompt_variant, project.root, cfg=cfg)

    # Load existing architecture (from design dir if applicable, else project).
    # When fresh=True, skip — generate independent sample with no refinement chain.
    target = save_target or project
    existing_arch = "" if fresh else target.read_architecture()

    # Build initial user message
    parts = ["Design a macro-level HLS architecture for this project.\n"]

    if use_dsl and dsl_spec:
        parts.append(f"## Specification (DSL)\n\n{dsl_spec}\n")
    else:
        if requirements:
            parts.append(f"## Requirements\n\n{requirements}\n")
        if interface_spec:
            parts.append(f"## Interface Specification\n\n{interface_spec}\n")
    if existing_arch:
        parts.append(f"## Existing Architecture\n\nPlease review and refine this:\n\n{existing_arch}\n")
    if hints:
        parts.append(f"## Architectural Hints\n\n{format_hints(hints)}\n")

    # Inject imported component context if in a design directory
    if save_target is not None:
        from hlscribe.workflows.import_kernel import build_imports_context
        imports_ctx = build_imports_context(save_target)
        if imports_ctx:
            parts.append(imports_ctx)

    user_message = "\n".join(parts)

    verb = "Refining" if existing_arch else "Generating"
    console.print("\n[bold]Architecture Design[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    if cfg.platform:
        console.print(f"  Platform: [cyan]{cfg.platform.name}[/cyan]")
    console.print()

    history: list[dict] = []

    # Initial generation
    try:
        with console.status(f"[dim]{verb} architecture...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_message, tag="arch-generate")
        console.print()
        console.print(Markdown(reply))
        console.print()
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        return ArchResult(content="", mode="single", num_proposals=1, rounds=0, saved_to=None)

    # Refinement loop — skipped in non-interactive mode (headless experiment)
    if non_interactive:
        content = ""
        for msg in reversed(history):
            if msg["role"] == "assistant":
                content = msg["content"]
                break
        result = ReplResult(content=content, rounds=0, should_save=True)
    else:
        result = _refinement_loop(
            cfg, console, system_prompt, history,
            label="arch", doc_type="Architecture",
        )

    saved_to = None
    if result.content and result.should_save:
        target = save_target or project
        _backup_if_exists(target.architecture_file, console)
        target.write_architecture(result.content)
        saved_to = target.architecture_file
        console.print(f"[green]Saved architecture to:[/green] {saved_to}")

    return ArchResult(
        content=result.content,
        mode="single",
        num_proposals=1,
        rounds=result.rounds,
        saved_to=saved_to,
    )


# ── Multi-proposal flow ──


def run_arch_proposals(
    project: Project,
    cfg: AppConfig,
    console: Console,
    num_proposals: int = 3,
    ont: Ontology | None = None,
    hints: dict | None = None,
    prompt_variant: str | None = None,
    save_target=None,
    fresh: bool = False,
    use_dsl: bool = False,
) -> ArchResult:
    """Generate N diverse architecture proposals in a single LLM call.

    Flow: load specs → fill template → single LLM call → display → save.

    When ``use_dsl=True`` the agent reads ``specs/spec.dsl`` as the sole
    specification, *in place of* ``requirements.md`` + ``interface-spec.md``.
    """
    # Load project specs (DSL stand-alone OR prose; not both)
    if use_dsl:
        dsl_spec = project.read_spec_dsl()
        requirements = ""
        interface_spec = ""
        if not dsl_spec:
            console.print("[yellow]Warning: --use-dsl set but specs/spec.dsl not found or empty.[/yellow]")
    else:
        dsl_spec = ""
        requirements = project.read_requirements()
        interface_spec = ""
        if project.interface_file.exists():
            interface_spec = project.interface_file.read_text()
        if not requirements and not interface_spec:
            console.print("[yellow]Warning: No requirements or interface spec found in specs/.[/yellow]")
            console.print("[dim]Run 'hlscribe ra' and 'hlscribe interface-spec' first for best results.[/dim]\n")

    # Build system prompt
    context_text = dsl_spec if use_dsl else f"{requirements}\n{interface_spec}"
    system_prompt = _build_system_prompt(ont, cfg.platform, context_text, prompt_variant, project.root, cfg=cfg)

    # Build user message from proposals template
    template = load_template("arch_proposals.md", project.root)
    hints_context = ""
    if hints:
        hints_context = f"### Architectural Hints\n{format_hints(hints)}"

    focuses = _determine_focuses(hints, num_proposals)

    # Inject imported component context if in a design directory
    imports_context = ""
    if save_target is not None:
        from hlscribe.workflows.import_kernel import build_imports_context
        imports_context = build_imports_context(save_target)

    # In DSL mode the spec.dsl content replaces both prose specs; we land it
    # in the {requirements} slot (the template renders that slot first) and
    # leave a back-reference in the {interface_spec} slot.
    if use_dsl:
        requirements_slot = f"_(Specification provided in DSL form.)_\n\n{dsl_spec}"
        interface_slot = "_(Included in the DSL specification above.)_"
    else:
        requirements_slot = requirements or "(none provided)"
        interface_slot = interface_spec or "(none provided)"

    user_message = (
        template
        .replace("{project_name}", project.name)
        .replace("{num_proposals}", str(num_proposals))
        .replace("{requirements}", requirements_slot)
        .replace("{interface_spec}", interface_slot)
        .replace("{hints_context}", hints_context)
        .replace("{proposal_focuses}", focuses)
        .replace("{imports_context}", imports_context)
    )

    console.print("\n[bold]Architecture Proposals[/bold]")
    console.print(f"  Project:   [cyan]{project.name}[/cyan]")
    console.print(f"  Proposals: [cyan]{num_proposals}[/cyan]")
    console.print(f"  Model:     [cyan]{cfg.llm.model}[/cyan]")
    if cfg.platform:
        console.print(f"  Platform:  [cyan]{cfg.platform.name}[/cyan]")
    console.print()

    history: list[dict] = []

    try:
        with console.status("[dim]Generating proposals...[/dim]"):
            reply = chat_once(
                cfg, system_prompt, history, user_message, max_tokens=16384,
                tag="arch-proposals",
            )
        console.print(Markdown(reply))
        console.print()
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        return ArchResult(
            content="", mode="multi", num_proposals=num_proposals,
            rounds=0, saved_to=None,
        )

    # Save combined + individual proposals
    target = save_target or project
    specs_dir = target.architecture_file.parent

    # Back up any existing architecture*.md files
    for existing in sorted(specs_dir.glob("architecture*.md")):
        _backup_if_exists(existing, console)

    # 1. Combined file (reference)
    target.write_architecture(reply)
    saved_to = target.architecture_file
    console.print(f"[green]Saved combined proposals to:[/green] {saved_to}")

    # 2. Split into individual files
    proposals, meta = _split_proposals(reply)
    proposal_files: list[Path] = []
    for i, proposal_text in enumerate(proposals, 1):
        pfile = specs_dir / f"architecture-{i}.md"
        pfile.write_text(proposal_text + "\n")
        proposal_files.append(pfile)
        console.print(f"[green]  Proposal {i}:[/green] {pfile}")

    # 3. Comparison / recommendation meta file
    if meta:
        compare_file = specs_dir / "architecture-compare.md"
        compare_file.write_text(meta + "\n")
        console.print(f"[green]  Comparison:[/green] {compare_file}")

    return ArchResult(
        content=reply,
        mode="multi",
        num_proposals=num_proposals,
        rounds=0,
        saved_to=saved_to,
        proposal_files=proposal_files,
    )

"""Create a new HLS project and design variants from template."""

from __future__ import annotations

from pathlib import Path

from hlscribe.platforms import Platform
from hlscribe.project import Design, Project


def init_project(
    parent: Path,
    name: str,
    description: str = "",
    platform: Platform | None = None,
    clock: str = "3.3ns",
    top_function: str = "kernel_top",
) -> Project:
    """Create an HLS project root with config and specs directory.

    Args:
        parent: Parent directory where project folder will be created.
        name: Project name (becomes directory name).
        description: One-line project description.
        platform: FPGA platform (default: Alveo U50).
        clock: Clock period string (default: "3.3ns").
        top_function: HLS top function name.

    Returns:
        The created Project.
    """
    project = Project.create(parent, name, description)

    # Resolve platform defaults
    if platform is None:
        from hlscribe.platforms import get_platform
        platform = get_platform("u50")

    # Write hlscribe.yaml (hand-written for comments)
    config_text = f"""name: {name}
description: {description}

# FPGA target
platform: {platform.key}
clock: {clock}
top_function: {top_function}

# LLM provider: anthropic (default), openrouter, openai
# provider: anthropic
# model: claude-sonnet-4-20250514

# OpenRouter example:
# provider: openrouter
# model: anthropic/claude-sonnet-4

# OpenAI example:
# provider: openai
# model: gpt-4o
"""
    project.config_file.write_text(config_text)

    # .gitignore at root level
    gitignore = _render_gitignore()
    (project.root / ".gitignore").write_text(gitignore)

    return project


def init_design(
    project: Project,
    name: str,
    platform: Platform | None = None,
    clock: str = "3.3ns",
    top_function: str = "kernel_top",
) -> Design:
    """Create a design variant inside a project with build templates.

    Args:
        project: Parent project.
        name: Design name (becomes subdirectory name).
        platform: FPGA platform (default: Alveo U50).
        clock: Clock period string (default: "3.3ns").
        top_function: HLS top function name.

    Returns:
        The created Design.
    """
    design = Design.create(project, name)

    # Resolve platform defaults
    if platform is None:
        from hlscribe.platforms import get_platform
        platform = get_platform("u50")

    # Copy build templates into design
    _copy_templates(design, platform, clock, top_function)

    return design


# ── Template renderers ──


def _copy_templates(
    design: Design,
    platform: Platform,
    clock: str,
    top_function: str,
) -> None:
    """Copy and customize HLS template files into a design variant."""
    # Makefile
    makefile = _render_makefile(platform, top_function)
    (design.root / "Makefile").write_text(makefile)

    # HLS config (baseline — no hls_ prefix)
    cfg = _render_hls_config(platform, clock, top_function)
    (design.configs_dir / "baseline.cfg").write_text(cfg)

    # Build script
    build_sh = _render_build_script()
    build_path = design.scripts_dir / "build_hls.sh"
    build_path.write_text(build_sh)
    build_path.chmod(0o755)

    # Slurm sweep script
    slurm_sh = _render_slurm_sweep()
    slurm_path = design.scripts_dir / "slurm_sweep.sh"
    slurm_path.write_text(slurm_sh)
    slurm_path.chmod(0o755)

    # Env setup
    env_sh = _render_env_setup(platform, top_function)
    env_path = design.scripts_dir / "env_setup.sh"
    env_path.write_text(env_sh)
    env_path.chmod(0o755)


def _render_makefile(platform: Platform, top_function: str) -> str:
    # Use raw string fragments with explicit \t for make rules.
    # SOL= supports: literal name, comma-separated list, numeric range (1-5).
    return """# hlscribe HLS project Makefile
SOL ?= baseline

# ── SOL expansion ──
# Resolve SOL into a space-separated SOLUTIONS list.
#   SOL=baseline          → baseline
#   SOL=baseline,init-opt → baseline init-opt
#   SOL=1-5               → solution1 solution2 solution3 solution4 solution5
_comma := ,
_has_comma  = $(findstring $(_comma),$(SOL))
_has_range  = $(findstring -,$(SOL))
_range_from = $(word 1,$(subst -, ,$(SOL)))
_range_to   = $(word 2,$(subst -, ,$(SOL)))

ifdef _has_comma
  SOLUTIONS := $(subst $(_comma), ,$(SOL))
else ifdef _has_range
  ifneq ($(_range_from),$(SOL))
    SOLUTIONS := $(shell seq -f 'solution%.0f' $(_range_from) $(_range_to))
  else
    SOLUTIONS := $(SOL)
  endif
else
  SOLUTIONS := $(SOL)
endif

# Auto-discover all configs (used by sweep when SOL not overridden)
ALL_CONFIGS := $(sort $(patsubst configs/%.cfg,%,$(wildcard configs/*.cfg)))

# ── Build targets ──
TARGET ?= hw_emu

.PHONY: csim csynth cosim host emconfig hw_emu hw run-hw-emu run-hw clean sweep sweep-slurm reports table

csim:
\t@for sol in $(SOLUTIONS); do MODE=csim SOLUTION=$$sol bash scripts/build_hls.sh; done

csynth:
\t@for sol in $(SOLUTIONS); do MODE=csynth SOLUTION=$$sol bash scripts/build_hls.sh; done

cosim:
\t@for sol in $(SOLUTIONS); do MODE=cosim SOLUTION=$$sol bash scripts/build_hls.sh; done

host:
\t@MODE=host bash scripts/build_hls.sh

emconfig:
\t@MODE=emconfig bash scripts/build_hls.sh

hw_emu: host
\t@for sol in $(SOLUTIONS); do MODE=hw_emu SOLUTION=$$sol bash scripts/build_hls.sh; done

hw: host
\t@for sol in $(SOLUTIONS); do MODE=hw SOLUTION=$$sol bash scripts/build_hls.sh; done

run-hw-emu: hw_emu emconfig
\t@for sol in $(SOLUTIONS); do MODE=run_hw_emu SOLUTION=$$sol bash scripts/build_hls.sh; done

run-hw: hw
\t@for sol in $(SOLUTIONS); do MODE=run_hw SOLUTION=$$sol bash scripts/build_hls.sh; done

clean:
\t@echo "Cleaning build artifacts..."
\trm -rf workspace artifacts/logs artifacts/xo artifacts/xclbin artifacts/emu_runs artifacts/hw_runs artifacts/host_app artifacts/emconfig.json

# ── Sweep targets ──
SWEEP_MODE ?= csynth

sweep:
\t@echo "=== Local sweep ($(SWEEP_MODE)) ==="
\t@for cfg in $(ALL_CONFIGS); do \\
\t\techo "--- $$cfg ---"; \\
\t\tMODE=$(SWEEP_MODE) SOLUTION=$$cfg bash scripts/build_hls.sh; \\
\tdone

sweep-slurm:
\t@echo "=== Slurm sweep ($(SWEEP_MODE)) ==="
\t@mkdir -p artifacts/logs
\t@echo $(ALL_CONFIGS) | tr ' ' '\\n' > artifacts/logs/slurm_solutions.txt
\t@N=$$(wc -l < artifacts/logs/slurm_solutions.txt); \\
\techo "Submitting $$N jobs..."; \\
\tMODE=$(SWEEP_MODE) bash scripts/slurm_sweep.sh

# ── Report targets ──
reports:
\t@echo "=== Synthesis Reports ==="
\t@for sol in $(ALL_CONFIGS); do \\
\t\trpt=$$(find workspace/$$sol -name '*_csynth.rpt' 2>/dev/null | head -1); \\
\t\tif [ -n "$$rpt" ]; then echo "--- $$sol ---"; cat "$$rpt"; fi; \\
\tdone

table:
\t@hlscribe results
"""


def _render_gitignore() -> str:
    return """# Build artifacts
workspace/
artifacts/
*.xo
*.xclbin
*.log
*.wdb
*.wcfg
emconfig.json
host_app

# hlscribe tool state
.hlscribe/

# Python
__pycache__/
*.py[cod]
"""


def _render_hls_config(platform: Platform, clock: str, top_function: str) -> str:
    return f"""# HLS configuration — baseline (no optimization directives).

part={platform.device}

[hls]
flow_target=vitis
syn.top={top_function}
syn.file=../src/kernel.cpp
syn.cflags=-I../src
tb.file=../test/kernel_tb.cpp
tb.cflags=-I../src

clock={clock}
clock_uncertainty=15%

# Add optimization directives below this line.
"""



def _render_build_script() -> str:
    return r"""#!/usr/bin/env bash
set -eo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/env_setup.sh"

MODE="${MODE:-csim}"
SOLUTION="${SOLUTION:-baseline}"
# KERNEL (compute-unit / -k name for v++) defaults to the design's top
# function, which env_setup.sh exports as TOP_FUNCTION. Fall back to
# kernel_top only if neither is set.
KERNEL="${KERNEL:-${TOP_FUNCTION:-kernel_top}}"

# No hls_ prefix — config names match filenames directly
CFG="${SCRIPT_DIR}/../configs/${SOLUTION}.cfg"
WORK_DIR="${SCRIPT_DIR}/../workspace/${SOLUTION}"

if [ ! -f "${CFG}" ]; then
  echo "ERROR: Config not found: ${CFG}"
  exit 1
fi

mkdir -p "${WORK_DIR}" "${SCRIPT_DIR}/../artifacts/logs"
logfile="${SCRIPT_DIR}/../artifacts/logs/${SOLUTION}_${MODE}.log"
> "${logfile}"

# Auto-discover imported source files and patch config
PATCHED_CFG="${WORK_DIR}/patched_${SOLUTION}.cfg"
cp "${CFG}" "${PATCHED_CFG}"
# Ensure file ends with newline before appending (configs may lack trailing newline)
sed -i -e '$a\' "${PATCHED_CFG}"
HAS_IMPORTS=false
for f in "${SCRIPT_DIR}"/../src/*.cpp; do
  [ -e "$f" ] || continue
  base=$(basename "$f")
  # Skip primary sources (handled by cfg), DSE kernel, and timestamped backups
  if [ "$base" != "kernel.cpp" ] && [ "$base" != "kernel_dse.cpp" ] && [ "$base" != "host.cpp" ] && ! [[ "$base" =~ \.[0-9]{8}-[0-9]{6}\.cpp$ ]]; then
    echo "syn.file=../src/${base}" >> "${PATCHED_CFG}"
    HAS_IMPORTS=true
  fi
done
# Ensure -I../src is present so testbench can find imported headers
if $HAS_IMPORTS; then
  if ! grep -q 'tb.cflags.*-I\.\./src' "${PATCHED_CFG}"; then
    echo "tb.cflags=-I../src" >> "${PATCHED_CFG}"
  fi
  if ! grep -q 'syn.cflags.*-I\.\./src' "${PATCHED_CFG}"; then
    echo "syn.cflags=-I../src" >> "${PATCHED_CFG}"
  fi
fi
CFG="${PATCHED_CFG}"

run_csim() {
  echo "--- HLS csim (solution=${SOLUTION}) ---" | tee -a "${logfile}"
  if ! vitis-run --mode hls --csim --config "${CFG}" --work_dir "${WORK_DIR}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: C simulation failed for ${SOLUTION}" | tee -a "${logfile}"
    return 1
  fi
}

run_csynth() {
  echo "--- HLS csynth (solution=${SOLUTION}) ---" | tee -a "${logfile}"
  if ! v++ -c --mode hls --config "${CFG}" --work_dir "${WORK_DIR}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: HLS synthesis failed for ${SOLUTION}" | tee -a "${logfile}"
    return 1
  fi
}

run_cosim() {
  echo "--- HLS cosim (solution=${SOLUTION}) ---" | tee -a "${logfile}"
  if ! vitis-run --mode hls --cosim --config "${CFG}" --work_dir "${WORK_DIR}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: Co-simulation failed for ${SOLUTION}" | tee -a "${logfile}"
    return 1
  fi
}

# ── v++ / XRT stages ──

XO_DIR="${SCRIPT_DIR}/../artifacts/xo"
XCLBIN_DIR="${SCRIPT_DIR}/../artifacts/xclbin"

run_xo() {
  local tgt="${1:-${TARGET}}"
  local xo_file="${XO_DIR}/${KERNEL}_${tgt}.xo"
  mkdir -p "${XO_DIR}"
  echo "--- v++ compile → XO (target=${tgt}, solution=${SOLUTION}) ---" | tee -a "${logfile}"
  SRC_FILES=$(find "${SCRIPT_DIR}/../src/" -name '*.cpp' ! -name 'host.cpp' | tr '\n' ' ')
  if ! v++ -c -t "${tgt}" --platform "${PLATFORM}" \
    -k "${KERNEL}" \
    -o "${xo_file}" ${SRC_FILES} 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: v++ compile failed for ${SOLUTION} (target=${tgt})" | tee -a "${logfile}"
    return 1
  fi
  echo "XO: ${xo_file}" | tee -a "${logfile}"
}

run_xclbin() {
  local tgt="${1:-${TARGET}}"
  local xo_file="${XO_DIR}/${KERNEL}_${tgt}.xo"
  local xclbin_file="${XCLBIN_DIR}/${KERNEL}_${tgt}.xclbin"
  mkdir -p "${XCLBIN_DIR}"

  # Auto-build XO if missing
  if [ ! -f "${xo_file}" ]; then
    echo "XO not found, building first..." | tee -a "${logfile}"
    run_xo "${tgt}" || return 1
  fi

  # Reuse an existing XCLBIN — the v++ link is a ~1h place-and-route, and the
  # run-* stages depend on the (phony) hw target, so without this guard every
  # `run-hw` would needlessly re-link (and fail if the build platform isn't in
  # the run shell's env). Set FORCE_LINK=1 to rebuild. Mirrors the XO guard above.
  if [ -f "${xclbin_file}" ] && [ -z "${FORCE_LINK:-}" ]; then
    echo "XCLBIN exists, skipping link (set FORCE_LINK=1 to rebuild): ${xclbin_file}" | tee -a "${logfile}"
    return 0
  fi

  echo "--- v++ link → XCLBIN (target=${tgt}, solution=${SOLUTION}) ---" | tee -a "${logfile}"
  if ! v++ -l -t "${tgt}" --platform "${PLATFORM}" \
    "${xo_file}" -o "${xclbin_file}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: v++ link failed for ${SOLUTION} (target=${tgt})" | tee -a "${logfile}"
    return 1
  fi
  echo "XCLBIN: ${xclbin_file}" | tee -a "${logfile}"
}

run_host() {
  local host_bin="${SCRIPT_DIR}/../artifacts/host_app"
  echo "--- Compiling host application ---" | tee -a "${logfile}"
  if [ -z "${XRT_INC:-}" ] || [ -z "${XRT_LIB:-}" ]; then
    echo "ERROR: XRT not found. Set XRT_SETUP or XILINX_XRT." | tee -a "${logfile}"
    return 1
  fi
  if ! g++ -std=c++17 -o "${host_bin}" src/host.cpp \
    -I"${XRT_INC}" -L"${XRT_LIB}" -lxrt_coreutil -lpthread 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: Host compilation failed" | tee -a "${logfile}"
    return 1
  fi
  echo "Host binary: ${host_bin}" | tee -a "${logfile}"
}

run_emconfig() {
  local artifacts_dir="${SCRIPT_DIR}/../artifacts"
  echo "--- Generating emconfig.json ---" | tee -a "${logfile}"
  if ! emconfigutil --platform "${PLATFORM}" --nd 1 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: emconfigutil failed" | tee -a "${logfile}"
    return 1
  fi
  mv -f emconfig.json "${artifacts_dir}/emconfig.json" 2>/dev/null || true
  echo "emconfig: ${artifacts_dir}/emconfig.json" | tee -a "${logfile}"
}

run_hw_emu_exec() {
  local xclbin="${XCLBIN_DIR}/${KERNEL}_hw_emu.xclbin"
  local host_bin="${SCRIPT_DIR}/../artifacts/host_app"
  local emcfg="${SCRIPT_DIR}/../artifacts/emconfig.json"
  local run_dir="${SCRIPT_DIR}/../artifacts/emu_runs/hw_emu_${SOLUTION}_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "${run_dir}"

  if [ ! -f "${host_bin}" ]; then
    echo "ERROR: Host binary not found. Run MODE=host first." | tee -a "${logfile}"
    return 1
  fi
  if [ ! -f "${xclbin}" ]; then
    echo "ERROR: hw_emu XCLBIN not found. Run MODE=hw_emu first." | tee -a "${logfile}"
    return 1
  fi
  if [ ! -f "${emcfg}" ]; then
    echo "Generating emconfig.json..." | tee -a "${logfile}"
    run_emconfig || return 1
  fi

  cp "${emcfg}" "${run_dir}/emconfig.json"

  echo "--- Running hw_emu (solution=${SOLUTION}) ---" | tee -a "${logfile}"
  cd "${run_dir}"
  export XCL_EMULATION_MODE=hw_emu
  if ! "${host_bin}" "${xclbin}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: hw_emu execution failed for ${SOLUTION}" | tee -a "${logfile}"
    return 1
  fi
  echo "Run output: ${run_dir}" | tee -a "${logfile}"
}

run_hw_exec() {
  local xclbin="${XCLBIN_DIR}/${KERNEL}_hw.xclbin"
  local host_bin="${SCRIPT_DIR}/../artifacts/host_app"
  local run_dir="${SCRIPT_DIR}/../artifacts/hw_runs/hw_${SOLUTION}_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "${run_dir}"

  if [ ! -f "${host_bin}" ]; then
    echo "ERROR: Host binary not found. Run MODE=host first." | tee -a "${logfile}"
    return 1
  fi
  if [ ! -f "${xclbin}" ]; then
    echo "ERROR: hw XCLBIN not found. Run MODE=hw first." | tee -a "${logfile}"
    return 1
  fi

  echo "--- Running on hardware (solution=${SOLUTION}) ---" | tee -a "${logfile}"
  cd "${run_dir}"
  if ! "${host_bin}" "${xclbin}" 2>&1 | tee -a "${logfile}"; then
    echo "ERROR: hw execution failed for ${SOLUTION}" | tee -a "${logfile}"
    return 1
  fi
  echo "Run output: ${run_dir}" | tee -a "${logfile}"
}

case "${MODE}" in
  csim)       run_csim ;;
  csynth)     run_csynth ;;
  cosim)      run_cosim ;;
  both)       run_csim && run_csynth ;;
  host)       run_host ;;
  emconfig)   run_emconfig ;;
  hw_emu)     run_xclbin hw_emu ;;
  hw)         run_xclbin hw ;;
  run_hw_emu) run_hw_emu_exec ;;
  run_hw)     run_hw_exec ;;
  *)          echo "ERROR: Unknown MODE=${MODE}"; exit 1 ;;
esac
"""


def _render_slurm_sweep() -> str:
    return r"""#!/usr/bin/env bash
# Slurm array sweep — submit via: MODE=csynth bash scripts/slurm_sweep.sh
set -eo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESIGN_DIR="${SCRIPT_DIR}/.."
SOL_FILE="${DESIGN_DIR}/artifacts/logs/slurm_solutions.txt"

if [ ! -f "${SOL_FILE}" ]; then
  echo "ERROR: No solutions list at ${SOL_FILE}"
  echo "  Run 'make sweep-slurm' or create the file manually."
  exit 1
fi

N=$(wc -l < "${SOL_FILE}")
if [ "${N}" -eq 0 ]; then
  echo "ERROR: Solutions file is empty."
  exit 1
fi

MODE="${MODE:-csynth}"

# Submit as a Slurm array job
JOB_ID=$(sbatch --parsable \
  --array=1-${N} \
  --job-name="hlscribe-${MODE}" \
  --output="${DESIGN_DIR}/artifacts/logs/slurm_%A_%a.out" \
  --wrap="
    SOLUTION=\$(sed -n \"\${SLURM_ARRAY_TASK_ID}p\" \"${SOL_FILE}\")
    echo \"Task \${SLURM_ARRAY_TASK_ID}: \${SOLUTION}\"
    cd \"${DESIGN_DIR}\"
    MODE=${MODE} SOLUTION=\${SOLUTION} bash scripts/build_hls.sh
  ")

echo "Submitted Slurm array job: ${JOB_ID} (${N} tasks, mode=${MODE})"

# Save job metadata for hlscribe jobs tracking
mkdir -p "${DESIGN_DIR}/.hlscribe"
cat > "${DESIGN_DIR}/.hlscribe/slurm_job.json" <<ENDJSON
{
  "job_id": ${JOB_ID},
  "mode": "${MODE}",
  "num_tasks": ${N},
  "solutions_file": "${SOL_FILE}"
}
ENDJSON
"""


def _render_env_setup(platform: Platform, top_function: str = "kernel_top") -> str:
    return f"""#!/usr/bin/env bash
set -e

# License server
export LM_LICENSE_FILE="${{LM_LICENSE_FILE:-2100@rce.iiit.ac.in}}"

# Platform repository. Search /opt first, then the shared IIIT-H NFS copy
# (/home/Xilinx/...), where the U50/VCK5000 .xpfm platforms actually live —
# so hw builds resolve the platform on rce and every node without a per-node
# /opt symlink. Colon-separated; a pre-set PLATFORM_REPO_PATHS still wins.
export PLATFORM_REPO_PATHS="${{PLATFORM_REPO_PATHS:-/opt/xilinx/platforms:/home/Xilinx/opt/xilinx/platforms}}"

# Vitis HLS
VITIS_INSTALL_DIR="${{VITIS_INSTALL_DIR:-/home/Xilinx/2025.1}}"
if [ -z "$XILINX_VITIS" ]; then
  if [ -f "${{VITIS_INSTALL_DIR}}/Vitis/settings64.sh" ]; then
    source "${{VITIS_INSTALL_DIR}}/Vitis/settings64.sh"
  else
    echo "WARNING: Vitis settings64.sh not found at ${{VITIS_INSTALL_DIR}}/Vitis/settings64.sh"
  fi
fi

## XRT (Xilinx Runtime) — needed for host compilation and hw_emu
XRT_SETUP="${{XRT_SETUP:-/opt/xilinx/xrt/setup.sh}}"
if [ -z "$XILINX_XRT" ] && [ -f "${{XRT_SETUP}}" ]; then
  source "${{XRT_SETUP}}"
fi
if [ -n "$XILINX_XRT" ]; then
  export XRT_INC="${{XRT_INC:-$XILINX_XRT/include}}"
  export XRT_LIB="${{XRT_LIB:-$XILINX_XRT/lib}}"
fi

export PLATFORM="${{PLATFORM:-{platform.platform_id}}}"
export PART="${{PART:-{platform.device}}}"
export TOP_FUNCTION="${{TOP_FUNCTION:-{top_function}}}"
export CLOCK_PERIOD_NS="${{CLOCK_PERIOD_NS:-3.3}}"
export SOLUTION="${{SOLUTION:-baseline}}"
export MODE="${{MODE:-csim}}"
export TARGET="${{TARGET:-hw_emu}}"
"""

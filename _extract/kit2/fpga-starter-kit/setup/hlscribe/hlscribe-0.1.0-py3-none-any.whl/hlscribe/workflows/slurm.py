"""Slurm job tracking — query status, cancel jobs."""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path

from hlscribe.config import SlurmConfig
from hlscribe.project import Design


@dataclass
class JobTask:
    task_id: int
    sol: str
    state: str      # RUNNING, PENDING, COMPLETED, FAILED, CANCELLED
    elapsed: str
    node: str


def load_job_metadata(design: Design) -> dict | None:
    """Load .hlscribe/slurm_job.json if it exists."""
    meta_path = design.root / ".hlscribe" / "slurm_job.json"
    if not meta_path.exists():
        return None
    with open(meta_path) as f:
        return json.load(f)


def query_jobs(design: Design, cfg: SlurmConfig) -> list[JobTask]:
    """Query Slurm for job status via SSH."""
    meta = load_job_metadata(design)
    if meta is None:
        return []

    job_id = meta["job_id"]
    solutions = meta.get("solutions", [])

    # Query sacct for array job
    cmd = [
        "ssh", cfg.ssh_target,
        "sacct", "-j", str(job_id),
        "--format=JobID,State,Elapsed,NodeList",
        "--noheader", "--parsable2",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return []

    tasks: list[JobTask] = []
    for line in result.stdout.strip().splitlines():
        parts = line.split("|")
        if len(parts) < 4:
            continue
        job_str = parts[0]
        state = parts[1]
        elapsed = parts[2]
        node = parts[3]

        # Parse array task ID from "12345_1" format
        if "_" not in job_str:
            continue
        try:
            tid = int(job_str.split("_")[1])
        except (ValueError, IndexError):
            continue

        sol = solutions[tid - 1] if 0 < tid <= len(solutions) else f"task-{tid}"

        tasks.append(JobTask(
            task_id=tid,
            sol=sol,
            state=state,
            elapsed=elapsed,
            node=node,
        ))

    return tasks


def cancel_job(design: Design, cfg: SlurmConfig, job_id: int | None = None) -> bool:
    """Cancel a Slurm job. If job_id is None, uses the last submitted job."""
    if job_id is None:
        meta = load_job_metadata(design)
        if meta is None:
            return False
        job_id = meta["job_id"]

    cmd = ["ssh", cfg.ssh_target, "scancel", str(job_id)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0

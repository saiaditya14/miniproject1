"""Interactive help Q&A — answers questions about hlscribe using live docs."""

from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.markdown import Markdown

from hlscribe.config import AppConfig
from hlscribe.llm import chat_once, load_template
from hlscribe.utils.html_strip import strip_html
from hlscribe.workflows.arch_flow import _read_input

_DOCS_DIR = Path(__file__).parent.parent.parent / "docs"
_PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


def _load_docs_context() -> str:
    """Load and strip design.html + manual.html, list prompt files."""
    sections: list[str] = []

    for name in ("design.html", "manual.html"):
        path = _DOCS_DIR / name
        if path.exists():
            text = strip_html(path.read_text())
            sections.append(f"### {name}\n\n{text}")

    # List available prompt templates
    prompt_files = sorted(p.name for p in _PROMPTS_DIR.glob("*.md"))
    if prompt_files:
        listing = "\n".join(f"- {f}" for f in prompt_files)
        sections.append(f"### Available prompt templates\n\n{listing}")

    return "\n\n".join(sections)


def _build_system_prompt() -> str:
    """Load help_system.md template, inject docs context."""
    template = load_template("help_system.md")
    docs = _load_docs_context()
    return template.replace("{docs_context}", docs)


def run_help_chat(cfg: AppConfig, console: Console) -> None:
    """Run interactive help Q&A loop."""
    console.print("\n[bold]hlscribe Help[/bold]")
    console.print(f"  Model: [cyan]{cfg.llm.model}[/cyan]")
    console.print(
        "\n  Ask anything about hlscribe commands, workflows, or features."
    )
    console.print(
        "  Type [bold]quit[/bold], [bold]exit[/bold], or [bold]q[/bold] to stop. "
        '[bold]reset[/bold] to clear history. [bold]"""[/bold] for multiline.\n'
    )

    system_prompt = _build_system_prompt()
    history: list[dict] = []

    while True:
        user_input = _read_input(console, "you", hint='quit | """ for multiline')
        if user_input is None:
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "q"):
            console.print("[dim]Goodbye.[/dim]")
            break
        if user_input.lower() == "reset":
            history.clear()
            console.print("[dim]Conversation cleared.[/dim]\n")
            continue

        try:
            with console.status("[dim]Thinking...[/dim]"):
                reply = chat_once(cfg, system_prompt, history, user_input, tag="help-chat")
            console.print()
            console.print(Markdown(reply))
            console.print()
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]\n")

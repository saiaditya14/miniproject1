"""Code generation workflow — generate kernel/testbench code and single-round error fix."""

from __future__ import annotations

import difflib
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.markdown import Markdown
from rich.syntax import Syntax

from hlscribe.config import AppConfig
from hlscribe.errors import format_errors, parse_log_file
from hlscribe.extract import extract_first_code_block
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology
from hlscribe.project import Design, Project
from hlscribe.workflows.arch_flow import (
    _build_ontology_context,
    _build_platform_context,
)


@dataclass
class CodegenResult:
    """Result from a code generation run."""

    step: str  # "kernel", "testbench", "host", "all"
    kernel_code: str = ""
    testbench_code: str = ""
    host_code: str = ""
    kernel_saved: Path | None = None
    testbench_saved: Path | None = None
    host_saved: Path | None = None


# ── Private helpers ──


def _backup_if_exists(path: Path, console: Console) -> None:
    """Back up an existing file with a timestamp suffix."""
    if not path.exists():
        return
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = path.with_suffix(f".{ts}{path.suffix}")
    shutil.copy2(path, backup)
    console.print(f"[dim]Backed up existing file to:[/dim] {backup}")


def _load_specs(project: Project, design: Design | None = None, use_dsl: bool = False) -> dict[str, str]:
    """Read specification documents from project/design specs dirs.

    When ``use_dsl=True`` the spec.dsl content fills the ``requirements``
    slot (with a one-line header noting the DSL form) and ``interface``
    is left empty — the DSL is a stand-alone replacement, not an addition.
    Prose requirements/interface files are NOT read in DSL mode.
    """
    specs: dict[str, str] = {}

    # Spec: prose (default) OR DSL stand-alone
    if use_dsl:
        dsl_spec = project.read_spec_dsl()
        if dsl_spec:
            specs["requirements"] = f"_(Specification provided in DSL form.)_\n\n{dsl_spec}"
        else:
            specs["requirements"] = ""
        specs["interface"] = "_(Included in the DSL specification above.)_" if dsl_spec else ""
    else:
        specs["requirements"] = project.read_requirements() or ""
        specs["interface"] = project.read_interface() or ""

    # Architecture: prefer design-level, fall back to project-level
    if design:
        arch = design.read_architecture()
        if not arch:
            arch = project.read_architecture()
    else:
        arch = project.read_architecture()
    specs["architecture"] = arch or ""

    # Test plan (if exists at project level)
    tp_file = project.specs_dir / "testplan.md"
    specs["testplan"] = tp_file.read_text() if tp_file.exists() else ""

    # Imported components
    if design is not None:
        from hlscribe.workflows.import_kernel import build_imports_context
        specs["imports"] = build_imports_context(design)
    else:
        specs["imports"] = ""

    return specs


def _report_ontology(
    ont: Ontology | None,
    context_text: str,
    design: Design,
    console: Console,
    cfg: AppConfig | None = None,
    arch_md: str | None = None,
) -> str:
    """Build ontology context, display summary on console, save to artifacts.

    Returns the ontology context string for prompt injection.
    """
    ontology_ctx = _build_ontology_context(ont, context_text, cfg=cfg, arch_md=arch_md)

    artifacts_dir = design.root / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    ont_file = artifacts_dir / "ontology_context.md"

    if not ontology_ctx:
        console.print("  Ontology: [dim]no patterns detected[/dim]")
        ont_file.write_text("# Ontology Context\n\nNo patterns detected.\n")
        return ontology_ctx

    # Extract detected pattern/guide names for summary
    detected = []
    if ont is not None:
        ont._ensure_loaded()  # noqa: SLF001
        patterns = ont.detect_patterns(context_text)
        guides = ont.detect_guides(context_text)
        for pid in patterns:
            p = ont.get_pattern(pid)
            if p:
                detected.append(p.get("name", pid))
        for gid in guides:
            g = ont.get_guide(gid)
            if g:
                detected.append(g.get("name", gid))

    if detected:
        names = ", ".join(detected)
        console.print(f"  Ontology: [green]{names}[/green]")
    else:
        console.print("  Ontology: [dim]context injected[/dim]")

    ont_file.write_text(f"# Ontology Context\n\n{ontology_ctx}\n")
    console.print(f"  [dim]Saved: {ont_file}[/dim]")

    return ontology_ctx


def _build_system_prompt(
    cfg: AppConfig,
    ont: Ontology | None,
    project_root: Path | None = None,
    prompt_variant: str | None = None,
    context_text: str = "",
    ontology_ctx: str | None = None,
    dse: bool = False,
    arch_md: str | None = None,
) -> str:
    """Load codegen_system.md, substitute placeholders."""
    if prompt_variant:
        variant_path = Path(prompt_variant)
        if variant_path.is_file():
            template = variant_path.read_text()
        else:
            name = f"codegen_{prompt_variant}_system.md"
            template = load_template(name, project_root)
    else:
        template = load_template("codegen_system.md", project_root)

    if dse:
        mode_context = (
            "## Mode: DSE (Design Space Exploration)\n\n"
            "Generate kernel code that follows the macro architecture but leaves "
            "micro-optimization knobs for external .cfg files.\n\n"
            "**INCLUDE in kernel_dse.cpp (macro architecture — structural):**\n"
            "- `extern \"C\"` wrapper\n"
            "- ALL HLS INTERFACE pragmas (m_axi, s_axilite)\n"
            "- `#pragma HLS DATAFLOW` (macro architectural choice from arch spec)\n"
            "- `#pragma HLS STREAM variable=... depth=N` (structural, enables DATAFLOW)\n"
            "- `#pragma HLS DEPENDENCE` (data dependency hints)\n"
            "- `#pragma HLS LOOP_TRIPCOUNT` on ALL loops\n"
            "- **Named labels on ALL loops** (e.g., `load_data:`, `compute_outer:`, `store_result:`)\n"
            "- Comments: `// cfg: syn.directive.pipeline=<func>/<label> II=1`\n\n"
            "**EXCLUDE from kernel_dse.cpp (micro knobs — swept via .cfg):**\n"
            "- `#pragma HLS PIPELINE` (II is a tuning knob)\n"
            "- `#pragma HLS UNROLL` (factor is a tuning knob)\n"
            "- `#pragma HLS ARRAY_PARTITION` (type/factor are tuning knobs)\n"
            "- `#pragma HLS INLINE` (inlining is a tuning choice)\n\n"
            "The macro architecture (DATAFLOW, tiling, buffer org, function decomposition) "
            "is fixed by the architecture spec. DSE only explores micro-level "
            "optimization knobs via external .cfg directives.\n"
        )
    else:
        mode_context = (
            "## Mode: Standard\n\n"
            "Generate fully optimized kernel code with appropriate HLS pragmas "
            "based on the architecture design and optimization hints."
        )

    platform_ctx = _build_platform_context(cfg.platform)
    if ontology_ctx is None:
        ontology_ctx = _build_ontology_context(ont, context_text, cfg=cfg, arch_md=arch_md)

    # Load lessons.md if template has the placeholder
    lessons_ctx = ""
    if "{lessons_context}" in template:
        try:
            lessons_ctx = load_template("lessons.md", project_root)
        except FileNotFoundError:
            lessons_ctx = ""

    return (
        template.replace("{mode_context}", mode_context)
        .replace("{lessons_context}", lessons_ctx)
        .replace("{platform_context}", platform_ctx)
        .replace("{ontology_context}", ontology_ctx)
    )


def _build_user_message(
    project: Project,
    design: Design | None,
    step: str,
    specs: dict[str, str],
    kernel_code: str = "",
    project_root: Path | None = None,
    top_function: str = "kernel_top",
    prompt_variant: str | None = None,
    dse: bool = False,
) -> str:
    """Load step template and substitute spec placeholders."""
    # Choose template
    if step == "kernel" and dse:
        template_name = "codegen_dse_kernel.md"
    elif step == "testbench":
        template_name = "codegen_testbench.md"
    elif step == "host":
        template_name = "codegen_host.md"
    else:
        template_name = "codegen_kernel.md"

    # Try variant-specific template first, fall back to default
    if prompt_variant:
        base, ext = template_name.rsplit(".", 1)
        variant_name = f"{base.replace('codegen_', f'codegen_{prompt_variant}_')}.{ext}"
        try:
            template = load_template(variant_name, project_root)
        except FileNotFoundError:
            template = load_template(template_name, project_root)
    else:
        template = load_template(template_name, project_root)

    return (
        template.replace("{project_name}", project.name)
        .replace("{top_function}", top_function)
        .replace("{interface_context}", specs.get("interface") or "_No interface spec available._")
        .replace("{requirements_context}", specs.get("requirements") or "_No requirements available._")
        .replace("{architecture_context}", specs.get("architecture") or "_No architecture available._")
        .replace("{kernel_context}", kernel_code or "_Kernel code not yet generated._")
        .replace("{testplan_context}", specs.get("testplan") or "_No test plan available._")
        .replace("{imports_context}", specs.get("imports") or "")
    )


def _extract_analysis(response: str) -> str:
    """Extract LLM analysis text before the first code fence."""
    if not response:
        return ""
    idx = response.find("```")
    if idx > 0:
        text = response[:idx].strip()
    elif idx == -1:
        text = response.strip()
    else:
        text = ""
    text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
    return text


def _show_diff(old: str, new: str, name: str, console: Console) -> tuple[int, int, int]:
    """Display a colored unified diff and return (added, removed, hunks)."""
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    diff_lines = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"{name} (current)",
        tofile=f"{name} (proposed)",
    ))

    added = sum(1 for l in diff_lines if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff_lines if l.startswith("-") and not l.startswith("---"))
    hunks = sum(1 for l in diff_lines if l.startswith("@@"))

    if not diff_lines:
        console.print("[dim]No changes.[/dim]")
        return 0, 0, 0

    console.print(f"\n[bold]Diff:[/bold] +{added} -{removed} ({hunks} hunk{'s' if hunks != 1 else ''})\n")

    # Colorize diff output
    for line in diff_lines:
        line_stripped = line.rstrip("\n")
        if line.startswith("+++") or line.startswith("---"):
            console.print(f"[bold]{line_stripped}[/bold]")
        elif line.startswith("+"):
            console.print(f"[green]{line_stripped}[/green]")
        elif line.startswith("-"):
            console.print(f"[red]{line_stripped}[/red]")
        elif line.startswith("@@"):
            console.print(f"[cyan]{line_stripped}[/cyan]")
        else:
            console.print(line_stripped)

    console.print()
    return added, removed, hunks


def _prompt_accept(console: Console) -> str:
    """Prompt user to accept, reject, view, or give feedback.

    Returns 'a' (accept), 'r' (reject), 'v' (view full code), or 'f' (feedback).
    """
    while True:
        choice = click.prompt(
            "Accept fix? [a]ccept / [r]eject / [v]iew full code / [f]eedback",
            default="a",
        ).strip().lower()
        if choice in ("a", "r", "v", "f", "accept", "reject", "view", "feedback"):
            return choice[0]
        console.print("[yellow]Invalid choice. Enter a, r, v, or f.[/yellow]")


# ── Depth consistency validation ──


_DEPTH_RE = re.compile(
    r"#pragma\s+HLS\s+INTERFACE\s+m_axi\b.*?\bdepth\s*=\s*(\d+)", re.IGNORECASE
)
_CONST_INT_RE = re.compile(r"const\s+int\s+(\w+)\s*=\s*(\d+)")
_ARRAY_ALLOC_RE = re.compile(
    r"(?:uint8_t|int|float|double|char|unsigned\s+char)\s*\*?\s+\w+\s*\[\s*(\w+)\s*\]"
)


def _validate_depth_consistency(
    design: Design,
    console: Console,
) -> None:
    """Warn if m_axi depth in kernel doesn't match testbench buffer allocation."""
    if not design.kernel_file.exists() or not design.testbench_file.exists():
        return

    kernel_code = design.read_kernel()
    tb_code = design.testbench_file.read_text()

    # Extract depth values from kernel pragmas
    depths = [int(m.group(1)) for m in _DEPTH_RE.finditer(kernel_code)]
    if not depths:
        return

    max_depth = max(depths)

    # Try to find buffer sizes in testbench
    # Look for const int NAME = <value> patterns
    constants = {m.group(1): int(m.group(2)) for m in _CONST_INT_RE.finditer(tb_code)}

    tb_sizes: list[int] = []

    # Pattern: malloc(<expr> * sizeof(...)) — try to evaluate expr using constants
    for m in re.finditer(r"malloc\s*\(\s*([^)]+)\s*\)", tb_code):
        expr = m.group(1).split("*")[0].strip()
        if expr in constants:
            tb_sizes.append(constants[expr])
        elif expr.isdigit():
            tb_sizes.append(int(expr))

    # Also check direct array sizes: type name[N]
    for m in _ARRAY_ALLOC_RE.finditer(tb_code):
        size_str = m.group(1)
        if size_str in constants:
            tb_sizes.append(constants[size_str])
        elif size_str.isdigit():
            tb_sizes.append(int(size_str))

    if not tb_sizes:
        return  # Can't determine TB size — skip silently

    max_tb = max(tb_sizes)

    if max_depth != max_tb:
        console.print(
            f"\n[bold yellow]Warning: m_axi depth mismatch[/bold yellow]"
        )
        console.print(
            f"  Kernel depth={max_depth}, testbench buffer={max_tb}"
        )
        if max_depth > max_tb:
            console.print(
                f"  [red]Cosim will SIGSEGV![/red] "
                f"depth ({max_depth}) > testbench allocation ({max_tb})."
            )
        else:
            console.print(
                f"  [yellow]depth ({max_depth}) < testbench allocation ({max_tb}). "
                f"Cosim may miss data.[/yellow]"
            )
        console.print(
            f"  [dim]Fix: set depth={max_tb} in kernel m_axi pragmas.[/dim]"
        )


# ── Public entry points ──


_VERDICT_RE = re.compile(r"(ALIGNED|MINOR DRIFT|SIGNIFICANT DRIFT)", re.IGNORECASE)
_VERDICT_STYLE = {
    "ALIGNED": "bold green",
    "MINOR DRIFT": "bold yellow",
    "SIGNIFICANT DRIFT": "bold red",
}


def run_arch_check(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    ont: Ontology | None = None,
) -> None:
    """Run automatic architecture alignment check after codegen/fix.

    Compares generated kernel code against the architecture spec using an LLM.
    Skips silently if no architecture spec or no kernel file exists.
    Failures are warnings only — never blocks the workflow.
    """
    specs = _load_specs(project, design)
    arch_text = specs.get("architecture", "")
    if not arch_text.strip():
        return  # no arch spec — nothing to check

    if not design.kernel_file.exists():
        return  # no kernel — nothing to check

    kernel_code = design.read_kernel()
    if not kernel_code.strip():
        return

    try:
        template = load_template("arch_check.md", project.root)
        user_msg = (
            template.replace("{architecture_context}", arch_text)
            .replace("{kernel_code}", kernel_code)
        )
        sys_prompt = _build_system_prompt(cfg, ont, project_root=project.root)

        history: list[dict] = []
        with console.status("[dim]Checking architecture alignment...[/dim]"):
            reply = chat_once(cfg, sys_prompt, history, user_msg, tag="arch-check")

        # Extract verdict
        match = _VERDICT_RE.search(reply)
        verdict = match.group(1).upper() if match else "UNKNOWN"
        style = _VERDICT_STYLE.get(verdict, "bold")

        console.print(f"\n[{style}]Architecture check: {verdict}[/{style}]")

        # Save full report
        out_path = design.artifacts_dir / "arch_check.md"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(reply)
        console.print(f"[dim]Full report: {out_path}[/dim]")
    except Exception as exc:  # noqa: BLE001
        console.print(f"[yellow]Architecture check skipped: {exc}[/yellow]")


def _write_baseline_dse_cfg(
    design: Design,
    console: Console,
    directives: list[str] | None = None,
) -> None:
    """Create baseline_dse.cfg from baseline.cfg + optional optimization directives."""
    baseline = design.configs_dir / "baseline.cfg"
    dse_cfg = design.configs_dir / "baseline_dse.cfg"
    if not baseline.exists():
        return
    content = baseline.read_text()
    content = content.replace("syn.file=../src/kernel.cpp", "syn.file=../src/kernel_dse.cpp")
    if directives:
        content = content.rstrip() + "\n\n# Original optimization directives (stripped from kernel)\n"
        for d in directives:
            content += d + "\n"
    dse_cfg.write_text(content)
    console.print(f"  [green]Saved:[/green] {dse_cfg}")


def run_strip_dse(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    skip_review: bool = False,
) -> None:
    """Strip micro-knob pragmas from kernel.cpp -> kernel_dse.cpp + baseline_dse.cfg.

    Hybrid approach: regex strip + optional LLM review.
    Use skip_review=True (--nollm) for pure regex, no API call.
    """
    from hlscribe.config_gen import strip_pragmas_to_dse

    if not design.kernel_file.exists():
        console.print("[red]kernel.cpp not found.[/red]")
        console.print("[dim]Run 'hlscribe codegen' first to generate the kernel.[/dim]")
        raise SystemExit(1)

    console.print("\n[bold]DSE Pragma Stripping[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Design:  [cyan]{design.name}[/cyan]")
    console.print(f"  Source:  [dim]{design.kernel_file}[/dim]")

    # Step 1: Regex stripping
    kernel_code = design.kernel_file.read_text()
    dse_code, directives = strip_pragmas_to_dse(kernel_code, cfg.top_function)

    _backup_if_exists(design.dse_kernel_file, console)
    design.write_dse_kernel(dse_code)
    console.print(f"  [green]Saved:[/green] {design.dse_kernel_file}")
    console.print(f"  Stripped {len(directives)} micro-knob pragma(s)")

    _write_baseline_dse_cfg(design, console, directives=directives)

    # Step 2: LLM review (unless --nollm)
    if skip_review:
        console.print("  [dim]LLM review skipped (--nollm)[/dim]")
        return

    console.print("  Reviewing with LLM...")
    review_prompt = load_template("codegen_dse_review.md", project.root)
    dse_cfg_content = (design.configs_dir / "baseline_dse.cfg").read_text()
    user_msg = (
        f"## kernel_dse.cpp\n```cpp\n{dse_code}\n```\n\n"
        f"## baseline_dse.cfg\n```\n{dse_cfg_content}\n```"
    )
    history: list[dict] = []
    try:
        with console.status("[dim]LLM reviewing stripped kernel...[/dim]"):
            review = chat_once(cfg, review_prompt, history, user_msg, tag="codegen-dse-review")
    except Exception as e:
        console.print(f"  [yellow]LLM review failed: {e}[/yellow]")
        return

    if review.strip().startswith("PASS"):
        console.print("  [green]LLM review: PASS[/green]")
    else:
        console.print(f"  [yellow]LLM review:[/yellow] {review.strip()}")


def run_codegen(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    step: str = "all",
    ont: Ontology | None = None,
    prompt_variant: str | None = None,
    dse: bool = False,
    use_dsl: bool = False,
    arch_check: bool = False,
) -> CodegenResult:
    """Generate kernel and/or testbench code.

    For step="all": kernel first, then testbench (kernel code injected as context).
    Backs up existing files before overwriting.
    When dse=True, generates kernel_dse.cpp (pragma-free for DSE config sweeps).
    When ``use_dsl=True`` the agent reads ``specs/spec.dsl`` as the sole
    specification (in place of ``requirements.md`` + ``interface-spec.md``).
    """
    specs = _load_specs(project, design, use_dsl=use_dsl)
    context_text = "\n".join(
        specs.get(k, "") for k in ("requirements", "architecture", "interface")
    )

    result = CodegenResult(step=step)

    console.print("\n[bold]Code Generation[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Design:  [cyan]{design.name}[/cyan]")
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    dse_label = " [magenta](DSE)[/magenta]" if dse else ""
    console.print(f"  Step:    [cyan]{step}[/cyan]{dse_label}")

    ontology_ctx = _report_ontology(
        ont, context_text, design, console, cfg=cfg,
        arch_md=specs.get("architecture"),
    )
    console.print()

    system_prompt = _build_system_prompt(
        cfg, ont, project.root, prompt_variant,
        context_text=context_text, ontology_ctx=ontology_ctx,
        dse=dse, arch_md=specs.get("architecture"),
    )

    steps = ["kernel", "testbench", "host"] if step == "all" else [step]

    for current_step in steps:
        user_msg = _build_user_message(
            project, design, current_step, specs,
            kernel_code=result.kernel_code,
            project_root=project.root,
            top_function=cfg.top_function,
            prompt_variant=prompt_variant,
            dse=dse,
        )

        step_label = f"{current_step} (DSE)" if (dse and current_step == "kernel") else current_step
        console.print(f"  Generating {step_label}...")
        try:
            history: list[dict] = []
            with console.status(f"[dim]Generating {step_label}...[/dim]"):
                reply = chat_once(cfg, system_prompt, history, user_msg,
                                  tag=f"codegen-{current_step}")
        except Exception as e:
            console.print(f"  [red]Error generating {step_label}: {e}[/red]")
            continue

        code = extract_first_code_block(reply)
        if not code:
            console.print(f"  [yellow]Warning: No code block found in {step_label} response.[/yellow]")
            # Store raw reply so user can inspect
            code = reply

        if current_step == "kernel" and dse:
            result.kernel_code = code
            _backup_if_exists(design.dse_kernel_file, console)
            design.write_dse_kernel(code)
            result.kernel_saved = design.dse_kernel_file
            console.print(f"  [green]Saved:[/green] {design.dse_kernel_file}")
            # Generate baseline_dse.cfg for quick testing
            _write_baseline_dse_cfg(design, console)
        elif current_step == "kernel":
            result.kernel_code = code
            _backup_if_exists(design.kernel_file, console)
            design.write_kernel(code)
            result.kernel_saved = design.kernel_file
            console.print(f"  [green]Saved:[/green] {design.kernel_file}")
        elif current_step == "testbench":
            result.testbench_code = code
            _backup_if_exists(design.testbench_file, console)
            design.write_testbench(code)
            result.testbench_saved = design.testbench_file
            console.print(f"  [green]Saved:[/green] {design.testbench_file}")
        elif current_step == "host":
            result.host_code = code
            _backup_if_exists(design.host_file, console)
            design.write_host(code)
            result.host_saved = design.host_file
            console.print(f"  [green]Saved:[/green] {design.host_file}")

    console.print()
    if arch_check:
        run_arch_check(project, design, cfg, console, ont=ont)
    _validate_depth_consistency(design, console)
    return result


def run_refine(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    file_name: str = "kernel.cpp",
    log_path: Path | None = None,
    build_stage: str | None = None,
    ont: Ontology | None = None,
    use_dsl: bool = False,
    arch_check: bool = False,
) -> CodegenResult:
    """Single-round interactive fix from build error log.

    Auto-detects whether errors are in config or code and routes accordingly.
    When ``use_dsl=True`` reads ``specs/spec.dsl`` instead of prose specs.
    Flow: parse errors → classify → LLM fix → show diff → accept/reject → write.
    """
    # Find log file: --log > --build-stage specific > most recent
    if log_path is None:
        logs_dir = design.logs_dir
        if logs_dir.exists():
            if build_stage is not None:
                # Stage explicitly specified — look for that log
                stage_logs = sorted(
                    logs_dir.glob(f"*_{build_stage}.log"),
                    key=lambda p: p.stat().st_mtime, reverse=True,
                )
                if stage_logs:
                    log_path = stage_logs[0]
            if log_path is None:
                # No stage specified or stage log not found — use most recent
                candidates = sorted(
                    logs_dir.glob("*.log"),
                    key=lambda p: p.stat().st_mtime, reverse=True,
                )
                if candidates:
                    log_path = candidates[0]

    if log_path is None or not log_path.exists():
        console.print("[red]No build log found.[/red]")
        console.print("[dim]Run 'hlscribe build csim' first, or specify --log <path>.[/dim]")
        raise SystemExit(1)

    console.print(f"  Log: [dim]{log_path.name}[/dim]")

    # Parse errors
    errors = parse_log_file(log_path)
    if not errors:
        console.print("[green]No errors found in log.[/green]")
        return CodegenResult(step="refine")

    error_report = format_errors(errors)

    specs = _load_specs(project, design, use_dsl=use_dsl)
    context_text = "\n".join(
        specs.get(k, "") for k in ("requirements", "architecture", "interface")
    )
    ontology_ctx = _report_ontology(
        ont, context_text, design, console, cfg=cfg,
        arch_md=specs.get("architecture"),
    )

    # Classify: config errors vs code errors
    config_errors = [e for e in errors if e.kind == "config"]

    if config_errors:
        return _refine_config(
            project, design, cfg, console, errors, error_report,
            config_errors, log_path, ont, ontology_ctx, specs,
        )

    result = _refine_code(
        project, design, cfg, console, file_name, errors, error_report,
        log_path, ont, ontology_ctx, specs,
    )
    if arch_check:
        run_arch_check(project, design, cfg, console, ont=ont)
    _validate_depth_consistency(design, console)
    return result


def _refine_code(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    file_name: str,
    errors: list,
    error_report: str,
    log_path: Path,
    ont,
    ontology_ctx: str,
    specs: dict[str, str],
) -> CodegenResult:
    """Single-round code fix (kernel, testbench, or host)."""
    if file_name == "kernel_dse.cpp":
        code_path = design.dse_kernel_file
    elif file_name == "kernel_tb.cpp":
        code_path = design.testbench_file
    elif file_name == "host.cpp":
        code_path = design.host_file
    else:
        code_path = design.kernel_file

    if not code_path.exists():
        console.print(f"[red]File not found: {code_path}[/red]")
        console.print("[dim]Run 'hlscribe codegen' first to generate code.[/dim]")
        raise SystemExit(1)

    existing_code = code_path.read_text()

    console.print(f"\n[bold]Code Refinement[/bold]")
    console.print(f"  File:   [cyan]{file_name}[/cyan]")
    console.print(f"  Log:    [cyan]{log_path}[/cyan]")
    console.print(f"  Errors: [yellow]{len(errors)}[/yellow]")
    console.print()

    # Build fix prompt
    fix_template = load_template("codegen_fix.md", project.root)
    arch_ctx = specs.get("architecture") or "_No architecture spec available._"
    user_msg = (
        fix_template.replace("{file_name}", file_name)
        .replace("{architecture_context}", arch_ctx)
        .replace("{existing_code}", existing_code)
        .replace("{error_report}", error_report)
    )

    system_prompt = _build_system_prompt(
        cfg, ont, project_root=project.root,
        context_text="\n".join(specs.get(k, "") for k in ("requirements", "architecture", "interface")),
        ontology_ctx=ontology_ctx,
    )

    history: list[dict] = []

    try:
        with console.status("[dim]Generating fix...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_msg, tag="refine-code")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return CodegenResult(step="refine")

    code = extract_first_code_block(reply)
    if not code:
        console.print("[yellow]Warning: No code block found in response.[/yellow]")
        return CodegenResult(step="refine")

    # Show LLM analysis (text before the code block)
    analysis = _extract_analysis(reply)
    if analysis:
        console.print("[bold]Fix Analysis:[/bold]")
        console.print(Markdown(analysis))

    # Show diff
    added, removed, hunks = _show_diff(existing_code, code, file_name, console)

    if added == 0 and removed == 0:
        console.print("[yellow]LLM returned identical code. Nothing to apply.[/yellow]")
        return CodegenResult(step="refine")

    # Accept/reject/feedback loop
    refinement_log = design.artifacts_dir / "refinement_log.md"
    result = CodegenResult(step="refine")

    while True:
        choice = _prompt_accept(console)

        if choice == "v":
            console.print(f"\n[bold]Proposed {file_name}:[/bold]\n")
            console.print(Syntax(code, "cpp", line_numbers=True))
            console.print()
            continue

        if choice == "r":
            console.print("[yellow]Fix rejected.[/yellow]")
            _log_refine_decision(
                refinement_log, file_name, cfg.llm.model,
                error_report, analysis, existing_code, code,
                added, removed, hunks, "REJECTED",
            )
            return result

        if choice == "f":
            feedback = click.prompt("Feedback")
            if not feedback.strip():
                continue
            try:
                with console.status("[dim]Applying feedback...[/dim]"):
                    reply = chat_once(cfg, system_prompt, history, feedback,
                                      tag="refine-code-feedback")
            except Exception as e:
                console.print(f"[red]LLM error: {e}[/red]")
                continue
            new_code = extract_first_code_block(reply)
            if not new_code:
                console.print("[yellow]No code block in response. Try again.[/yellow]")
                continue
            code = new_code
            analysis = _extract_analysis(reply)
            if analysis:
                console.print("[bold]Updated Analysis:[/bold]")
                console.print(Markdown(analysis))
            added, removed, hunks = _show_diff(existing_code, code, file_name, console)
            if added == 0 and removed == 0:
                console.print("[yellow]LLM returned identical code.[/yellow]")
            continue

        # choice == "a"
        break

    # Write accepted fix
    _backup_if_exists(code_path, console)

    if file_name == "kernel_dse.cpp":
        design.write_dse_kernel(code)
        result.kernel_code = code
        result.kernel_saved = code_path
    elif file_name == "kernel_tb.cpp":
        design.write_testbench(code)
        result.testbench_code = code
        result.testbench_saved = code_path
    elif file_name == "host.cpp":
        design.write_host(code)
        result.host_code = code
        result.host_saved = code_path
    else:
        design.write_kernel(code)
        result.kernel_code = code
        result.kernel_saved = code_path

    console.print(f"[green]Saved fixed code to:[/green] {code_path}")

    _log_refine_decision(
        refinement_log, file_name, cfg.llm.model,
        error_report, analysis, existing_code, code,
        added, removed, hunks, "ACCEPTED",
    )

    return result


def _refine_config(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    errors: list,
    error_report: str,
    config_errors: list,
    log_path: Path,
    ont,
    ontology_ctx: str,
    specs: dict[str, str],
) -> CodegenResult:
    """Single-round config fix."""
    # Determine config file from error
    config_file = config_errors[0].file
    if config_file and config_file != "unknown":
        config_path = design.root / config_file
    else:
        # Try to infer from log name (e.g., opt1_csim.log → opt1.cfg)
        sol = log_path.stem.rsplit("_", 1)[0] if "_" in log_path.stem else "baseline"
        config_path = design.configs_dir / f"{sol}.cfg"

    if not config_path.exists():
        console.print(f"[red]Config file not found: {config_path}[/red]")
        return CodegenResult(step="refine")

    config_content = config_path.read_text()

    console.print(f"\n[bold]Config Refinement[/bold]")
    console.print(f"  Config: [cyan]{config_path.name}[/cyan]")
    console.print(f"  Log:    [cyan]{log_path}[/cyan]")
    console.print(f"  Errors: [yellow]{len(config_errors)}[/yellow]")
    console.print()

    # Build config fix prompt
    fix_template = load_template("codegen_fix_config.md", project.root)
    kernel_code = design.read_kernel() if design.kernel_file.exists() else ""
    top_function = cfg.top_function or "kernel_top"

    user_msg = (
        fix_template.replace("{config_file}", config_path.name)
        .replace("{config_content}", config_content)
        .replace("{error_report}", error_report)
        .replace("{kernel_code}", kernel_code or "_Kernel not available._")
        .replace("{top_function}", top_function)
    )

    system_prompt = _build_system_prompt(
        cfg, ont, project_root=project.root,
        context_text="\n".join(specs.get(k, "") for k in ("requirements", "architecture", "interface")),
        ontology_ctx=ontology_ctx,
    )

    history: list[dict] = []

    try:
        with console.status(f"[dim]Generating fix for {config_path.name}...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_msg, tag="refine-config")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        return CodegenResult(step="refine")

    code = extract_first_code_block(reply)
    if not code:
        console.print("[yellow]Warning: No code block found in response.[/yellow]")
        return CodegenResult(step="refine")

    analysis = _extract_analysis(reply)
    if analysis:
        console.print("[bold]Fix Analysis:[/bold]")
        console.print(Markdown(analysis))

    added, removed, hunks = _show_diff(config_content, code, config_path.name, console)

    if added == 0 and removed == 0:
        console.print("[yellow]LLM returned identical config. Nothing to apply.[/yellow]")
        return CodegenResult(step="refine")

    refinement_log = design.artifacts_dir / "refinement_log.md"
    result = CodegenResult(step="refine")

    while True:
        choice = _prompt_accept(console)

        if choice == "v":
            console.print(f"\n[bold]Proposed {config_path.name}:[/bold]\n")
            console.print(Syntax(code, "ini", line_numbers=True))
            console.print()
            continue

        if choice == "r":
            console.print("[yellow]Fix rejected.[/yellow]")
            _log_refine_decision(
                refinement_log, config_path.name, cfg.llm.model,
                error_report, analysis, config_content, code,
                added, removed, hunks, "REJECTED",
            )
            return result

        if choice == "f":
            feedback = click.prompt("Feedback")
            if not feedback.strip():
                continue
            try:
                with console.status("[dim]Applying feedback...[/dim]"):
                    reply = chat_once(cfg, system_prompt, history, feedback,
                                      tag="refine-config-feedback")
            except Exception as e:
                console.print(f"[red]LLM error: {e}[/red]")
                continue
            new_code = extract_first_code_block(reply)
            if not new_code:
                console.print("[yellow]No code block in response. Try again.[/yellow]")
                continue
            code = new_code
            analysis = _extract_analysis(reply)
            if analysis:
                console.print("[bold]Updated Analysis:[/bold]")
                console.print(Markdown(analysis))
            added, removed, hunks = _show_diff(config_content, code, config_path.name, console)
            if added == 0 and removed == 0:
                console.print("[yellow]LLM returned identical config.[/yellow]")
            continue

        # choice == "a"
        break

    # Write accepted fix
    _backup_if_exists(config_path, console)
    config_path.write_text(code)
    console.print(f"[green]Saved fixed config to:[/green] {config_path}")

    _log_refine_decision(
        refinement_log, config_path.name, cfg.llm.model,
        error_report, analysis, config_content, code,
        added, removed, hunks, "ACCEPTED",
    )

    return result


def _log_refine_decision(
    log_path: Path,
    file_name: str,
    model: str,
    error_report: str,
    analysis: str,
    old_code: str,
    new_code: str,
    added: int,
    removed: int,
    hunks: int,
    decision: str,
) -> None:
    """Append a refinement decision entry to the log."""
    is_new = not log_path.exists()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    diff_text = "".join(difflib.unified_diff(
        old_code.splitlines(keepends=True),
        new_code.splitlines(keepends=True),
        fromfile=f"{file_name} (before)",
        tofile=f"{file_name} (after)",
    ))

    with open(log_path, "a") as f:
        if is_new:
            f.write("# Refinement Log\n\n")

        f.write(f"---\n## Single-round refine — {decision} ({ts})\n\n")
        f.write(f"**File:** {file_name} | **Model:** {model}\n\n")

        if error_report:
            f.write("### Errors\n")
            f.write(error_report)
            f.write("\n\n")

        if analysis:
            f.write("### Agent Analysis\n")
            f.write(analysis)
            f.write("\n\n")

        if diff_text:
            f.write(f"### Changes\n")
            f.write(f"+{added} -{removed} ({hunks} hunk{'s' if hunks != 1 else ''})\n\n")
            f.write("```diff\n")
            f.write(diff_text)
            if not diff_text.endswith("\n"):
                f.write("\n")
            f.write("```\n\n")

        f.write(f"### Decision: **{decision}**\n\n")

"""Fix loop workflow — multi-round build → parse → fix → rebuild cycle."""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.syntax import Syntax

from hlscribe.config import AppConfig
from hlscribe.errors import BuildError, format_errors, parse_log_file
from hlscribe.extract import extract_first_code_block
from hlscribe.lessons_log import append_lesson
from hlscribe.llm import chat_once, load_template
from hlscribe.ontology import Ontology
from hlscribe.project import Design, Project
from hlscribe.workflows.build import BuildResult, run_build
from hlscribe.workflows.codegen_flow import (
    _build_system_prompt,
    _load_specs,
    _prompt_accept,
    _report_ontology,
    _show_diff,
    run_arch_check,
)


# ── Result dataclass ──


@dataclass
class FixLoopResult:
    """Result from a fix-loop run."""

    success: bool
    rounds_completed: int
    file_fixed: str  # "kernel.cpp" or "kernel_tb.cpp" or config name
    log_path: Path | None = None  # refinement log


# ── Refinement log helpers ──


def _extract_analysis(response: str) -> str:
    """Extract LLM analysis text before the first code fence."""
    if not response:
        return ""
    idx = response.find("```")
    if idx > 0:
        text = response[:idx].strip()
    elif idx == -1:
        text = response.strip()
    else:
        text = ""
    # Strip heading markers
    text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
    return text


def _diff_stats(old: str, new: str) -> tuple[int, int, int]:
    """Calculate (added, removed, hunks) between old and new text."""
    diff = list(
        difflib.unified_diff(
            old.splitlines(keepends=True), new.splitlines(keepends=True)
        )
    )
    added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
    hunks = sum(1 for l in diff if l.startswith("@@"))
    return added, removed, hunks


def _diff_text(old: str, new: str, name: str) -> str:
    """Generate unified diff text."""
    return "".join(
        difflib.unified_diff(
            old.splitlines(keepends=True),
            new.splitlines(keepends=True),
            fromfile=f"{name} (before)",
            tofile=f"{name} (after)",
        )
    )


def _append_log(
    log_path: Path,
    round_num: int,
    fix_type: str,
    target_file: str,
    model: str,
    errors_before: str,
    analysis: str,
    diff: str,
    stats: tuple[int, int, int],
    build_result: str,
    remaining_errors: str = "",
) -> None:
    """Append a markdown entry to the refinement log."""
    is_new = not log_path.exists()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    added, removed, hunks = stats

    with open(log_path, "a") as f:
        if is_new:
            f.write("# Refinement Log\n\n")

        f.write(f"---\n## Round {round_num} — {fix_type} fix ({ts})\n\n")
        f.write(f"**File:** {target_file} | **Model:** {model}\n\n")

        if errors_before:
            f.write("### Errors Before Fix\n")
            f.write(errors_before)
            f.write("\n\n")

        if analysis:
            f.write("### Agent Analysis\n")
            f.write(analysis)
            f.write("\n\n")

        if diff:
            f.write(f"### Changes ({target_file})\n")
            f.write(
                f"+{added} -{removed} ({hunks} hunk{'s' if hunks != 1 else ''})\n\n"
            )
            f.write("```diff\n")
            f.write(diff)
            if not diff.endswith("\n"):
                f.write("\n")
            f.write("```\n\n")

        f.write("### Build Result\n")
        f.write(f"{build_result}\n")
        if remaining_errors:
            f.write(f"\n{remaining_errors}\n")
        f.write("\n")


def _find_log_file(design: Design, stage: str | None = None, sol: str = "baseline") -> Path | None:
    """Find build log: stage-specific if given, otherwise most recent."""
    if not design.logs_dir.exists():
        return None
    # If stage explicitly set, look for that specific log
    if stage is not None:
        log_file = design.logs_dir / f"{sol}_{stage}.log"
        if log_file.exists():
            return log_file
    # Fall back to most recent log
    candidates = sorted(
        design.logs_dir.glob("*.log"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def _has_config_errors(errors: list[BuildError]) -> list[BuildError]:
    """Return config-kind errors from the list."""
    return [e for e in errors if e.kind == "config"]


_KNOWN_CODE_FILES = ("kernel.cpp", "kernel_tb.cpp", "kernel_dse.cpp", "host.cpp")


def _resolve_code_path(design: Design, file_name: str) -> Path:
    """Resolve the on-disk path for one of the known fixable code files."""
    if file_name == "kernel_dse.cpp":
        return design.dse_kernel_file
    if file_name == "kernel_tb.cpp":
        return design.testbench_file
    if file_name == "host.cpp":
        return design.root / "src" / "host.cpp"
    return design.kernel_file


def _count_code_errors_by_file(errors: list[BuildError]) -> dict[str, int]:
    """Count non-config errors by short filename (kernel.cpp, kernel_tb.cpp, etc.).

    BuildError.file may carry a relative or absolute path; we normalize by
    matching the suffix against the known fixable filenames so different log
    formats (e.g., '../../../../../test/kernel_tb.cpp:121') still group correctly.
    """
    counts: dict[str, int] = {}
    for e in errors:
        if e.kind == "config" or not e.file:
            continue
        f = e.file
        for tail in _KNOWN_CODE_FILES:
            if f.endswith(tail):
                counts[tail] = counts.get(tail, 0) + 1
                break
    return counts


def _write_fixed_code(design: Design, file_name: str, fixed: str) -> None:
    """Write fixed code back to its file (centralized so all code paths agree)."""
    if file_name == "kernel_dse.cpp":
        design.write_dse_kernel(fixed)
    elif file_name == "kernel_tb.cpp":
        design.write_testbench(fixed)
    elif file_name == "host.cpp":
        host_path = design.root / "src" / "host.cpp"
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text(fixed)
    else:
        design.write_kernel(fixed)


def _fix_code(
    design: Design,
    project: Project,
    cfg: AppConfig,
    file_name: str,
    current_code: str,
    error_report: str,
    ont: Ontology | None,
    console: Console,
    ontology_ctx: str = "",
    arch_context: str = "",
    lesson_context: str = "",
    tag: str = "fix-loop",
) -> tuple[str | None, str]:
    """LLM-based code fix. Returns (fixed_code, raw_response) or (None, response)."""
    fix_template = load_template("codegen_fix.md", project.root)
    arch_ctx = arch_context or "_No architecture spec available._"
    user_msg = (
        fix_template.replace("{file_name}", file_name)
        .replace("{architecture_context}", arch_ctx)
        .replace("{existing_code}", current_code)
        .replace("{error_report}", error_report)
        .replace("{lesson_context}", lesson_context or "_No matching lessons._")
    )
    system_prompt = _build_system_prompt(
        cfg, ont, project_root=project.root,
        ontology_ctx=ontology_ctx,
    )

    try:
        history: list[dict] = []
        with console.status(f"[dim]Generating fix for {file_name}...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_msg, tag=tag)
    except Exception as e:
        console.print(f"[red]LLM error: {e}[/red]")
        return None, str(e)

    code = extract_first_code_block(reply)
    return code, reply


def _fix_config(
    design: Design,
    project: Project,
    cfg: AppConfig,
    config_path: Path,
    config_content: str,
    error_report: str,
    ont: Ontology | None,
    console: Console,
    ontology_ctx: str = "",
    lesson_context: str = "",
    tag: str = "fix-loop",
) -> tuple[str | None, str]:
    """LLM-based config fix. Returns (fixed_config, raw_response) or (None, response)."""
    fix_template = load_template("codegen_fix_config.md", project.root)

    # Read kernel for reference
    kernel_code = ""
    if design.kernel_file.exists():
        kernel_code = design.read_kernel()

    # Detect top function
    top_function = cfg.top_function or "kernel_top"

    user_msg = (
        fix_template.replace("{config_file}", config_path.name)
        .replace("{config_content}", config_content)
        .replace("{error_report}", error_report)
        .replace("{kernel_code}", kernel_code or "_Kernel not available._")
        .replace("{top_function}", top_function)
        .replace("{lesson_context}", lesson_context or "_No matching lessons._")
    )
    system_prompt = _build_system_prompt(
        cfg, ont, project_root=project.root,
        ontology_ctx=ontology_ctx,
    )

    try:
        history: list[dict] = []
        with console.status(f"[dim]Generating fix for {config_path.name}...[/dim]"):
            reply = chat_once(cfg, system_prompt, history, user_msg, tag=tag)
    except Exception as e:
        console.print(f"[red]LLM error: {e}[/red]")
        return None, str(e)

    code = extract_first_code_block(reply)
    return code, reply


# ── Public entry point ──


def run_fix_loop(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    *,
    file_name: str = "kernel.cpp",
    build_stage: str | None = None,
    sol: str = "baseline",
    log_path: Path | None = None,
    max_rounds: int | None = None,
    ont: Ontology | None = None,
    interactive: bool = False,
    use_dsl: bool = False,
    arch_check: bool = False,
) -> FixLoopResult:
    """Multi-round fix loop: build → parse errors → LLM fix → write → rebuild.

    Args:
        project: Parent project.
        design: Design variant to fix.
        cfg: App config (LLM, platform, etc.).
        console: Rich console for output.
        file_name: Target file to fix ("kernel.cpp" or "kernel_tb.cpp").
        build_stage: Build stage for verification ("csim", "csynth", "cosim").
        sol: Solution/config name for builds.
        max_rounds: Maximum fix rounds (defaults to cfg.max_fix_rounds).
        use_dsl: If True, read specs/spec.dsl as the sole specification in
            place of requirements.md + interface-spec.md.
        ont: Optional ontology context.
        interactive: If True, show diff and accept/reject prompt each round.

    Returns:
        FixLoopResult with success status and round count.
    """
    if max_rounds is None:
        max_rounds = cfg.max_fix_rounds

    # Determine target file (initial; may auto-route per-round below)
    code_path = _resolve_code_path(design, file_name)

    if not code_path.exists():
        console.print(f"[red]File not found: {code_path}[/red]")
        console.print("[dim]Run 'hlscribe codegen' first to generate code.[/dim]")
        raise SystemExit(1)

    refinement_log = design.artifacts_dir / "refinement_log.md"

    # Compute ontology context once for all rounds
    specs = _load_specs(project, design, use_dsl=use_dsl)
    context_text = "\n".join(
        specs.get(k, "") for k in ("requirements", "architecture", "interface")
    )

    console.print(f"\n[bold]Fix Loop[/bold]")
    console.print(f"  File:     [cyan]{file_name}[/cyan]")
    console.print(f"  Stage:    [cyan]{build_stage or 'auto-detect'}[/cyan]")
    console.print(f"  Solution: [cyan]{sol}[/cyan]")
    console.print(f"  Model:    [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"  Max:      [cyan]{max_rounds} rounds[/cyan]")

    ontology_ctx = _report_ontology(ont, context_text, design, console, cfg=cfg)

    console.print(f"  Log:      [dim]{refinement_log}[/dim]\n")

    # Step 0: Find log — explicit path > stage-specific > most recent
    if log_path is not None:
        log_file = log_path
    else:
        log_file = _find_log_file(design, build_stage, sol)
    errors = parse_log_file(log_file) if log_file else []

    # Infer build_stage from log filename if not explicitly set
    if build_stage is None and log_file is not None:
        # e.g. "baseline_cosim.log" → "cosim"
        stem = log_file.stem
        parts = stem.split("_", 1)
        if len(parts) == 2 and parts[1] in ("csim", "csynth", "cosim"):
            build_stage = parts[1]
    # Default to csim if still unknown
    if build_stage is None:
        build_stage = "csim"

    if errors:
        console.print(f"  Using existing log: [dim]{log_file.name}[/dim]")
    else:
        console.print("[dim]No errors in existing log, running build...[/dim]")
        build_result = run_build(design, build_stage, sol, quiet=True)

        if build_result.success:
            log_file = _find_log_file(design, build_stage, sol)
            errors = parse_log_file(log_file) if log_file else []
            if not errors:
                console.print("[green]Build passed with no errors. Nothing to fix.[/green]")
                return FixLoopResult(success=True, rounds_completed=0, file_fixed=file_name)
            console.print(
                f"[yellow]Build returned 0 but {len(errors)} error(s) found in logs.[/yellow]"
            )
        else:
            log_file = build_result.log_file or _find_log_file(design, build_stage, sol)
            errors = parse_log_file(log_file) if log_file else []
            if not errors:
                console.print("[red]Build failed but no parseable errors found.[/red]")
                return FixLoopResult(
                    success=False,
                    rounds_completed=0,
                    file_fixed=file_name,
                    log_path=refinement_log if refinement_log.exists() else None,
                )

    console.print(f"  [yellow]{len(errors)} error(s) detected[/yellow]\n")

    current_code = code_path.read_text()

    for round_num in range(1, max_rounds + 1):
        console.print(f"[bold cyan]--- Round {round_num}/{max_rounds} ---[/bold cyan]")

        error_report = format_errors(errors)
        errors_before_text = error_report

        # Auto-route fix to the file containing the most errors. Without this,
        # a missing #include in kernel_tb.cpp would be 'fixed' by editing
        # kernel.cpp — fix-loop spins for max_rounds rounds and never converges
        # because the error file is never touched. Observed on 2026-05-06 in
        # the model-sweep on sonnet-4.6 (trial 2). The user-supplied --file
        # flag is treated as the *initial* default; per-round we re-evaluate
        # based on actual error distribution.
        code_errors_by_file = _count_code_errors_by_file(errors)
        if code_errors_by_file:
            best_file = max(code_errors_by_file.items(), key=lambda kv: kv[1])[0]
            if best_file != file_name and code_errors_by_file[best_file] > code_errors_by_file.get(file_name, 0):
                new_path = _resolve_code_path(design, best_file)
                if new_path.exists():
                    console.print(
                        f"  [dim]Auto-routing fix: {best_file} has "
                        f"{code_errors_by_file[best_file]} error(s); "
                        f"{file_name} has {code_errors_by_file.get(file_name, 0)}. "
                        f"Switching target.[/dim]"
                    )
                    file_name = best_file
                    code_path = new_path
                    current_code = code_path.read_text()

        # Look up matching lessons from ontology
        lesson_ctx = ""
        if ont and errors:
            lesson_ctx = ont.get_lesson_context(error_report)
            if lesson_ctx:
                n_lessons = lesson_ctx.count("###")
                console.print(f"  [dim]Matched {n_lessons} lesson(s) from ontology[/dim]")

        # Classify: config errors vs code errors
        config_errors = _has_config_errors(errors)

        if config_errors:
            # Config fix path
            config_file = config_errors[0].file
            if config_file and config_file != "unknown":
                config_path = design.root / config_file
            else:
                config_path = design.configs_dir / f"{sol}.cfg"

            if not config_path.exists():
                console.print(
                    f"[yellow]Config file not found: {config_path}. "
                    f"Falling back to code fix.[/yellow]"
                )
                config_errors = []

        if config_errors and config_path.exists():
            # --- CONFIG FIX ---
            console.print(f"  Config errors → fixing [cyan]{config_path.name}[/cyan]")
            config_content = config_path.read_text()

            fixed, reply = _fix_config(
                design, project, cfg, config_path, config_content,
                error_report, ont, console, ontology_ctx=ontology_ctx,
                lesson_context=lesson_ctx,
                tag=f"fix-loop-r{round_num}",
            )

            if not fixed:
                console.print(f"  [yellow]Fix failed (no code block in response)[/yellow]")
                _append_log(
                    refinement_log, round_num, "config", config_path.name,
                    cfg.llm.model, errors_before_text,
                    _extract_analysis(reply), "", (0, 0, 0),
                    "SKIPPED (fix extraction failed)",
                )
                continue

            # Show analysis and diff
            fix_analysis = _extract_analysis(reply)
            if interactive and fix_analysis:
                console.print(f"\n  [bold]Fix Analysis:[/bold]")
                console.print(f"  {fix_analysis}")

            stats = _diff_stats(config_content, fixed)
            diff = _diff_text(config_content, fixed, config_path.name)

            if interactive:
                _show_diff(config_content, fixed, config_path.name, console)
                accepted = False
                while True:
                    choice = _prompt_accept(console)
                    if choice == "v":
                        console.print(Syntax(fixed, "ini", line_numbers=True))
                        continue
                    if choice == "r":
                        console.print("  [yellow]Fix rejected. Stopping.[/yellow]")
                        _append_log(
                            refinement_log, round_num, "config", config_path.name,
                            cfg.llm.model, errors_before_text, fix_analysis,
                            diff, stats, "REJECTED",
                        )
                        return FixLoopResult(
                            success=False, rounds_completed=round_num,
                            file_fixed=config_path.name, log_path=refinement_log,
                        )
                    if choice == "f":
                        feedback = click.prompt("Feedback")
                        if not feedback.strip():
                            continue
                        # Re-fix with feedback appended to error report
                        augmented_report = error_report + f"\n\nUser feedback: {feedback}"
                        fixed2, reply2 = _fix_config(
                            design, project, cfg, config_path, config_content,
                            augmented_report, ont, console, ontology_ctx=ontology_ctx,
                            lesson_context=lesson_ctx,
                            tag=f"fix-loop-r{round_num}-feedback",
                        )
                        if not fixed2:
                            console.print("  [yellow]No code block in response. Try again.[/yellow]")
                            continue
                        fixed = fixed2
                        fix_analysis = _extract_analysis(reply2)
                        if fix_analysis:
                            console.print(f"\n  [bold]Updated Analysis:[/bold]")
                            console.print(f"  {fix_analysis}")
                        stats = _diff_stats(config_content, fixed)
                        diff = _diff_text(config_content, fixed, config_path.name)
                        _show_diff(config_content, fixed, config_path.name, console)
                        continue
                    # choice == "a"
                    accepted = True
                    break

            # Write fixed config
            config_path.write_text(fixed)
            console.print(f"  [green]Saved:[/green] {config_path.name} (+{stats[0]} -{stats[1]})")
            fix_type = "config"
            fix_target = config_path.name
            fix_diff = diff
            fix_stats = stats
        else:
            # --- CODE FIX ---
            console.print(f"  Code errors → fixing [cyan]{file_name}[/cyan]")

            fixed, reply = _fix_code(
                design, project, cfg, file_name, current_code,
                error_report, ont, console, ontology_ctx=ontology_ctx,
                arch_context=specs.get("architecture", ""),
                lesson_context=lesson_ctx,
                tag=f"fix-loop-r{round_num}",
            )

            if not fixed:
                console.print(f"  [yellow]Fix failed (no code block in response)[/yellow]")
                _append_log(
                    refinement_log, round_num, "code", file_name,
                    cfg.llm.model, errors_before_text,
                    _extract_analysis(reply), "", (0, 0, 0),
                    "SKIPPED (fix extraction failed)",
                )
                continue

            # Show analysis and diff
            fix_analysis = _extract_analysis(reply)
            if interactive and fix_analysis:
                console.print(f"\n  [bold]Fix Analysis:[/bold]")
                console.print(f"  {fix_analysis}")

            stats = _diff_stats(current_code, fixed)
            diff = _diff_text(current_code, fixed, file_name)

            if interactive:
                _show_diff(current_code, fixed, file_name, console)
                while True:
                    choice = _prompt_accept(console)
                    if choice == "v":
                        console.print(Syntax(fixed, "cpp", line_numbers=True))
                        continue
                    if choice == "r":
                        console.print("  [yellow]Fix rejected. Stopping.[/yellow]")
                        _append_log(
                            refinement_log, round_num, "code", file_name,
                            cfg.llm.model, errors_before_text, fix_analysis,
                            diff, stats, "REJECTED",
                        )
                        return FixLoopResult(
                            success=False, rounds_completed=round_num,
                            file_fixed=file_name, log_path=refinement_log,
                        )
                    if choice == "f":
                        feedback = click.prompt("Feedback")
                        if not feedback.strip():
                            continue
                        augmented_report = error_report + f"\n\nUser feedback: {feedback}"
                        fixed2, reply2 = _fix_code(
                            design, project, cfg, file_name, current_code,
                            augmented_report, ont, console, ontology_ctx=ontology_ctx,
                            arch_context=specs.get("architecture", ""),
                            lesson_context=lesson_ctx,
                            tag=f"fix-loop-r{round_num}-feedback",
                        )
                        if not fixed2:
                            console.print("  [yellow]No code block in response. Try again.[/yellow]")
                            continue
                        fixed = fixed2
                        fix_analysis = _extract_analysis(reply2)
                        if fix_analysis:
                            console.print(f"\n  [bold]Updated Analysis:[/bold]")
                            console.print(f"  {fix_analysis}")
                        stats = _diff_stats(current_code, fixed)
                        diff = _diff_text(current_code, fixed, file_name)
                        _show_diff(current_code, fixed, file_name, console)
                        continue
                    # choice == "a"
                    break

            # Write fixed code
            _write_fixed_code(design, file_name, fixed)

            console.print(f"  [green]Saved:[/green] {file_name} (+{stats[0]} -{stats[1]})")
            current_code = fixed
            fix_type = "code"
            fix_target = file_name
            fix_diff = diff
            fix_stats = stats

        # Rebuild
        console.print(f"  [dim]Rebuilding ({build_stage})...[/dim]")
        build_result = run_build(design, build_stage, sol, quiet=True)

        # Re-parse logs (HLS overwrites logs, doesn't append)
        log_file = build_result.log_file or _find_log_file(design, build_stage, sol)
        new_errors = parse_log_file(log_file) if log_file else []

        if build_result.success and not new_errors:
            # Success!
            console.print(f"  [bold green]Build PASSED on round {round_num}![/bold green]")
            _append_log(
                refinement_log, round_num, fix_type, fix_target,
                cfg.llm.model, errors_before_text, fix_analysis,
                fix_diff, fix_stats, "PASSED",
            )
            try:
                append_lesson(
                    benchmark=project.name, design=design.name,
                    round_num=round_num, fix_type=fix_type,
                    fix_target=fix_target, build_stage=build_stage or "csim",
                    error_summary=errors_before_text, fix_analysis=fix_analysis,
                    fix_diff=fix_diff, model=cfg.llm.model,
                )
            except Exception:
                pass  # best-effort, never block fix-loop
            console.print(f"\n[green]Fix loop completed successfully after {round_num} round(s).[/green]")
            console.print(f"[dim]Refinement log: {refinement_log}[/dim]")
            if arch_check:
                run_arch_check(project, design, cfg, console, ont=ont)
            return FixLoopResult(
                success=True,
                rounds_completed=round_num,
                file_fixed=fix_target,
                log_path=refinement_log,
            )

        if build_result.success and new_errors:
            console.print(
                f"  [yellow]Build returned 0 but {len(new_errors)} error(s) in logs[/yellow]"
            )
            remaining = format_errors(new_errors)
            _append_log(
                refinement_log, round_num, fix_type, fix_target,
                cfg.llm.model, errors_before_text, fix_analysis,
                fix_diff, fix_stats, "PARTIAL (rc=0 but errors in logs)",
                remaining,
            )
        else:
            console.print(f"  [yellow]Build failed — {len(new_errors)} error(s)[/yellow]")
            remaining = format_errors(new_errors) if new_errors else ""
            _append_log(
                refinement_log, round_num, fix_type, fix_target,
                cfg.llm.model, errors_before_text, fix_analysis,
                fix_diff, fix_stats, "FAILED", remaining,
            )

        errors = new_errors

        if not errors:
            # Build failed but no parseable errors — can't continue fixing
            console.print("[yellow]Build failed but no parseable errors. Stopping.[/yellow]")
            break

    # Exhausted rounds
    console.print(f"\n[bold yellow]Fix loop exhausted after {max_rounds} rounds.[/bold yellow]")
    console.print(f"[dim]Refinement log: {refinement_log}[/dim]")
    return FixLoopResult(
        success=False,
        rounds_completed=max_rounds,
        file_fixed=file_name,
        log_path=refinement_log,
    )

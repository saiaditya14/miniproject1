"""Export workflow — generate standalone header, stream component, and component spec."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console

from hlscribe.config import AppConfig
from hlscribe.extract import (
    extract_code_blocks,
    extract_first_code_block,
    extract_first_markdown_block,
)
from hlscribe.llm import chat_once, load_template
from hlscribe.project import Design, Project
from hlscribe.workflows.codegen_flow import _backup_if_exists, _load_specs


@dataclass
class ExportResult:
    """Result from an export run."""

    header_code: str = ""
    core_cpp: str = ""
    core_header: str = ""
    spec_text: str = ""
    files_saved: list[Path] = field(default_factory=list)


def run_export(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
) -> ExportResult:
    """Generate standalone header, stream component, and component spec.

    Requires kernel.cpp to already exist (run codegen first).
    Produces up to 4 files:
      - src/kernel.h          (standalone header)
      - src/<top>_core.h      (stream-based header)
      - src/<top>_core.cpp    (stream-based implementation)
      - src/component-spec.md (import spec)
    """
    # ── Preconditions ──
    if not design.kernel_file.exists():
        console.print("[red]No kernel.cpp found.[/red]")
        console.print("[dim]Run 'hlscribe codegen' first.[/dim]")
        raise SystemExit(1)

    kernel_code = design.read_kernel()
    if not kernel_code.strip():
        console.print("[red]kernel.cpp is empty.[/red]")
        console.print("[dim]Run 'hlscribe codegen' first.[/dim]")
        raise SystemExit(1)

    top_function = cfg.top_function or "kernel_top"
    specs = _load_specs(project, design)

    result = ExportResult()

    console.print("\n[bold]Export[/bold]")
    console.print(f"  Project: [cyan]{project.name}[/cyan]")
    console.print(f"  Design:  [cyan]{design.name}[/cyan]")
    console.print(f"  Model:   [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"  Top:     [cyan]{top_function}[/cyan]")
    console.print()

    # ── LLM call #1: Standalone header ──
    console.print("  Generating standalone header...")
    result.header_code = _generate_header(
        project, design, cfg, console, kernel_code, specs,
    )
    if result.header_code:
        _backup_if_exists(design.header_file, console)
        design.write_header(result.header_code)
        result.files_saved.append(design.header_file)
        console.print(f"  [green]Saved:[/green] {design.header_file}")
    else:
        console.print("  [yellow]Header generation failed — continuing.[/yellow]")

    # ── LLM call #2: Stream core (.h + .cpp) ──
    console.print("  Generating stream component...")
    core_h, core_cpp = _generate_core(
        project, design, cfg, console, kernel_code, specs, top_function,
    )

    core_header_path = design.core_header_file(top_function)
    core_file_path = design.core_file(top_function)

    if core_h:
        result.core_header = core_h
        _backup_if_exists(core_header_path, console)
        design.src_dir.mkdir(parents=True, exist_ok=True)
        core_header_path.write_text(core_h)
        result.files_saved.append(core_header_path)
        console.print(f"  [green]Saved:[/green] {core_header_path}")

    if core_cpp:
        result.core_cpp = core_cpp
        _backup_if_exists(core_file_path, console)
        design.src_dir.mkdir(parents=True, exist_ok=True)
        core_file_path.write_text(core_cpp)
        result.files_saved.append(core_file_path)
        console.print(f"  [green]Saved:[/green] {core_file_path}")

    if not core_h and not core_cpp:
        console.print("  [yellow]Core generation failed — continuing.[/yellow]")

    # ── LLM call #3: Component spec ──
    console.print("  Generating component spec...")
    result.spec_text = _generate_spec(
        project, design, cfg, console,
        kernel_code, specs, top_function,
        core_header=result.core_header,
    )
    if result.spec_text:
        _backup_if_exists(design.component_spec_file, console)
        design.src_dir.mkdir(parents=True, exist_ok=True)
        design.component_spec_file.write_text(result.spec_text)
        result.files_saved.append(design.component_spec_file)
        console.print(f"  [green]Saved:[/green] {design.component_spec_file}")
    else:
        console.print("  [yellow]Spec generation failed.[/yellow]")

    # ── Summary ──
    console.print()
    if result.files_saved:
        console.print(f"[bold green]Exported {len(result.files_saved)} file(s).[/bold green]")
        if core_file_path in result.files_saved:
            console.print(
                f"\n[dim]To import into another design:[/dim]\n"
                f"  hlscribe import-kernel "
                f"{core_file_path.name} {core_header_path.name}"
                f" --spec-file {design.component_spec_file.name}"
            )
    else:
        console.print("[yellow]No files were exported.[/yellow]")

    return result


# ── Private helpers ──


def _generate_header(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    kernel_code: str,
    specs: dict[str, str],
) -> str:
    """LLM call to produce standalone kernel.h."""
    try:
        template = load_template("export_header.md", project.root)
        user_msg = (
            template.replace("{kernel_code}", kernel_code)
            .replace("{interface_context}", specs.get("interface") or "_No interface spec._")
        )
        history: list[dict] = []
        with console.status("[dim]Generating header...[/dim]"):
            reply = chat_once(cfg, _system_prompt(), history, user_msg, tag="export-header")
        return extract_first_code_block(reply) or ""
    except Exception as exc:  # noqa: BLE001
        console.print(f"  [red]Header error: {exc}[/red]")
        return ""


def _generate_core(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    kernel_code: str,
    specs: dict[str, str],
    top_function: str,
) -> tuple[str, str]:
    """LLM call to produce _core.h and _core.cpp. Returns (header, impl)."""
    try:
        template = load_template("export_core.md", project.root)
        user_msg = (
            template.replace("{kernel_code}", kernel_code)
            .replace("{top_function}", top_function)
            .replace("{interface_context}", specs.get("interface") or "_No interface spec._")
            .replace("{architecture_context}", specs.get("architecture") or "_No architecture._")
        )
        history: list[dict] = []
        with console.status("[dim]Generating stream component...[/dim]"):
            reply = chat_once(cfg, _system_prompt(), history, user_msg, tag="export-core")

        blocks = extract_code_blocks(reply)
        cpp_blocks = [b for b in blocks if b.language in ("cpp", "c++", "c", "")]
        if len(cpp_blocks) >= 2:
            return cpp_blocks[0].code, cpp_blocks[1].code
        if len(cpp_blocks) == 1:
            # Single block — treat as combined; caller gets only impl
            return "", cpp_blocks[0].code
        return "", ""
    except Exception as exc:  # noqa: BLE001
        console.print(f"  [red]Core error: {exc}[/red]")
        return "", ""


def _generate_spec(
    project: Project,
    design: Design,
    cfg: AppConfig,
    console: Console,
    kernel_code: str,
    specs: dict[str, str],
    top_function: str,
    *,
    core_header: str = "",
) -> str:
    """LLM call to produce component-spec.md."""
    try:
        template = load_template("export_spec.md", project.root)
        user_msg = (
            template.replace("{kernel_code}", kernel_code)
            .replace("{top_function}", top_function)
            .replace("{core_header}", core_header or "_Core header not available._")
            .replace("{interface_context}", specs.get("interface") or "_No interface spec._")
            .replace("{requirements_context}", specs.get("requirements") or "_No requirements._")
        )
        history: list[dict] = []
        with console.status("[dim]Generating component spec...[/dim]"):
            reply = chat_once(cfg, _system_prompt(), history, user_msg, tag="export-spec")
        return extract_first_markdown_block(reply) or ""
    except Exception as exc:  # noqa: BLE001
        console.print(f"  [red]Spec error: {exc}[/red]")
        return ""


def _system_prompt() -> str:
    """Minimal system prompt for export tasks."""
    return (
        "You are an expert HLS (High-Level Synthesis) engineer. "
        "Follow the instructions precisely and produce only the requested output. "
        "Do not add explanatory text outside of code blocks unless asked."
    )

"""Project directory layout and file I/O."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass
class Project:
    """Root-level project: specs, config, tool state."""

    root: Path
    name: str
    description: str = ""

    # ── Directory properties ──

    @property
    def specs_dir(self) -> Path:
        return self.root / "specs"

    @property
    def hlscribe_dir(self) -> Path:
        """Hidden tool-internal directory."""
        return self.root / ".hlscribe"

    # ── File properties ──

    @property
    def config_file(self) -> Path:
        return self.root / "hlscribe.yaml"

    @property
    def requirements_file(self) -> Path:
        return self.specs_dir / "requirements.md"

    @property
    def interface_file(self) -> Path:
        """Path to the interface spec.

        Accepts two filenames for compatibility:
          - interface-specification.md (canonical, used by the benchmark suite)
          - interface-spec.md           (legacy short name)

        Reads return the canonical if present, else legacy. Writes always go
        to the canonical name.
        """
        canonical = self.specs_dir / "interface-specification.md"
        legacy = self.specs_dir / "interface-spec.md"
        if canonical.exists():
            return canonical
        if legacy.exists():
            return legacy
        return canonical

    @property
    def architecture_file(self) -> Path:
        return self.specs_dir / "architecture.md"

    @property
    def spec_dsl_file(self) -> Path:
        """Path to the self-contained DSL spec (replaces requirements +
        interface-spec when present and the caller opts in via use_dsl=True).
        Used by the DSL-input experiment."""
        return self.specs_dir / "spec.dsl"

    # ── File I/O ──

    def read_requirements(self) -> str:
        if self.requirements_file.exists():
            return self.requirements_file.read_text()
        return ""

    def read_spec_dsl(self) -> str:
        """Read the DSL spec if present; return empty string otherwise."""
        if self.spec_dsl_file.exists():
            return self.spec_dsl_file.read_text()
        return ""

    def read_architecture(self) -> str:
        if self.architecture_file.exists():
            return self.architecture_file.read_text()
        return ""

    def write_architecture(self, content: str) -> None:
        self.specs_dir.mkdir(parents=True, exist_ok=True)
        self.architecture_file.write_text(content)

    def write_requirements(self, content: str) -> None:
        self.specs_dir.mkdir(parents=True, exist_ok=True)
        self.requirements_file.write_text(content)

    def read_interface(self) -> str:
        if self.interface_file.exists():
            return self.interface_file.read_text()
        return ""

    def write_interface(self, content: str) -> None:
        self.specs_dir.mkdir(parents=True, exist_ok=True)
        self.interface_file.write_text(content)

    def list_designs(self) -> list[Design]:
        """List all design variants in this project."""
        designs = []
        for d in sorted(self.root.iterdir()):
            if d.is_dir() and (d / "Makefile").exists() and not d.name.startswith("."):
                designs.append(Design(root=d, name=d.name, project=self))
        return designs

    # ── Load / create ──

    @classmethod
    def load(cls, path: Path) -> Project:
        """Load an existing project from its root directory."""
        path = path.resolve()
        config_path = path / "hlscribe.yaml"
        if not config_path.exists():
            raise FileNotFoundError(
                f"Not an hlscribe project: {path} (no hlscribe.yaml)"
            )
        with open(config_path) as f:
            data = yaml.safe_load(f) or {}
        return cls(
            root=path,
            name=data.get("name", path.name),
            description=data.get("description", ""),
        )

    @classmethod
    def find(cls, start: Path) -> Project:
        """Find and load a project by walking up from *start* to locate hlscribe.yaml.

        Searches *start* and each parent up to the filesystem root.
        Raises FileNotFoundError if no hlscribe.yaml is found.
        """
        current = start.resolve()
        while True:
            if (current / "hlscribe.yaml").exists():
                return cls.load(current)
            parent = current.parent
            if parent == current:
                break
            current = parent
        raise FileNotFoundError(
            f"No hlscribe.yaml found in {start} or any parent directory"
        )

    @classmethod
    def create(cls, parent: Path, name: str, description: str = "") -> Project:
        """Create root project directory structure."""
        root = (parent / name).resolve()
        if root.exists():
            raise FileExistsError(f"Directory already exists: {root}")

        project = cls(root=root, name=name, description=description)

        for d in [project.specs_dir, project.hlscribe_dir]:
            d.mkdir(parents=True, exist_ok=True)

        return project


@dataclass
class Design:
    """A design variant within a project — has its own src, test, build."""

    root: Path
    name: str
    project: Project

    # ── Directory properties ──

    @property
    def src_dir(self) -> Path:
        return self.root / "src"

    @property
    def test_dir(self) -> Path:
        return self.root / "test"

    @property
    def configs_dir(self) -> Path:
        return self.root / "configs"

    @property
    def scripts_dir(self) -> Path:
        return self.root / "scripts"

    @property
    def artifacts_dir(self) -> Path:
        return self.root / "artifacts"

    # ── File properties ──

    @property
    def specs_dir(self) -> Path:
        return self.root / "specs"

    @property
    def kernel_file(self) -> Path:
        return self.src_dir / "kernel.cpp"

    @property
    def dse_kernel_file(self) -> Path:
        return self.src_dir / "kernel_dse.cpp"

    @property
    def testbench_file(self) -> Path:
        return self.test_dir / "kernel_tb.cpp"

    @property
    def host_file(self) -> Path:
        return self.src_dir / "host.cpp"

    @property
    def architecture_file(self) -> Path:
        return self.specs_dir / "architecture.md"

    @property
    def logs_dir(self) -> Path:
        return self.artifacts_dir / "logs"

    @property
    def workspace_dir(self) -> Path:
        return self.root / "workspace"

    @property
    def imports_manifest(self) -> Path:
        return self.root / "imports.yaml"

    @property
    def header_file(self) -> Path:
        return self.src_dir / "kernel.h"

    @property
    def component_spec_file(self) -> Path:
        return self.src_dir / "component-spec.md"

    def core_file(self, top_function: str) -> Path:
        """Path to stream-refactored core implementation."""
        return self.src_dir / f"{top_function}_core.cpp"

    def core_header_file(self, top_function: str) -> Path:
        """Path to stream-refactored core header."""
        return self.src_dir / f"{top_function}_core.h"

    # ── File I/O ──

    def read_header(self) -> str:
        if self.header_file.exists():
            return self.header_file.read_text()
        return ""

    def write_header(self, code: str) -> None:
        self.src_dir.mkdir(parents=True, exist_ok=True)
        self.header_file.write_text(code)

    def read_host(self) -> str:
        if self.host_file.exists():
            return self.host_file.read_text()
        return ""

    def write_host(self, code: str) -> None:
        self.src_dir.mkdir(parents=True, exist_ok=True)
        self.host_file.write_text(code)

    def list_configs(self) -> list[str]:
        """List config names (without .cfg extension)."""
        return sorted(p.stem for p in self.configs_dir.glob("*.cfg"))

    def read_architecture(self) -> str:
        if self.architecture_file.exists():
            return self.architecture_file.read_text()
        return ""

    def write_architecture(self, content: str) -> None:
        self.specs_dir.mkdir(parents=True, exist_ok=True)
        self.architecture_file.write_text(content)

    def read_kernel(self) -> str:
        return self.kernel_file.read_text()

    def write_kernel(self, code: str) -> None:
        self.src_dir.mkdir(parents=True, exist_ok=True)
        self.kernel_file.write_text(code)

    def read_dse_kernel(self) -> str:
        if self.dse_kernel_file.exists():
            return self.dse_kernel_file.read_text()
        return ""

    def write_dse_kernel(self, code: str) -> None:
        self.src_dir.mkdir(parents=True, exist_ok=True)
        self.dse_kernel_file.write_text(code)

    def read_testbench(self) -> str:
        return self.testbench_file.read_text()

    def write_testbench(self, code: str) -> None:
        self.test_dir.mkdir(parents=True, exist_ok=True)
        self.testbench_file.write_text(code)

    def list_imports(self) -> list[str]:
        """List imported .cpp/.h filenames (excluding reserved names)."""
        reserved = {"kernel.cpp", "host.cpp", "kernel_tb.cpp"}
        files: list[str] = []
        for ext in ("*.cpp", "*.h", "*.hpp"):
            files.extend(p.name for p in self.src_dir.glob(ext) if p.name not in reserved)
        return sorted(set(files))

    # ── Load / create ──

    @classmethod
    def load(cls, path: Path, project: Project | None = None) -> Design:
        """Load an existing design from its directory."""
        path = path.resolve()
        if not (path / "Makefile").exists():
            raise FileNotFoundError(
                f"Not an hlscribe design: {path} (no Makefile)"
            )
        if project is None:
            project = Project.load(path.parent)
        return cls(root=path, name=path.name, project=project)

    @classmethod
    def create(cls, project: Project, name: str) -> Design:
        """Create design variant directory structure inside a project."""
        root = (project.root / name).resolve()
        if root.exists():
            raise FileExistsError(f"Directory already exists: {root}")

        design = cls(root=root, name=name, project=project)

        for d in [
            design.src_dir,
            design.test_dir,
            design.configs_dir,
            design.scripts_dir,
            design.artifacts_dir,
        ]:
            d.mkdir(parents=True, exist_ok=True)

        return design

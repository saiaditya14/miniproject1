"""FPGA platform registry with resource specs."""

from __future__ import annotations

from dataclasses import dataclass

@dataclass(frozen=True)
class Platform:
    key: str
    name: str
    device: str
    platform_id: str
    family: str
    category: str  # "datacenter", "ai_engine", "embedded", "cloud"
    lut: int
    ff: int
    bram: int
    uram: int
    dsp: int
    memory: str
    clock: str = "3.3ns"

    def summary(self) -> str:
        return (
            f"{self.name} | LUT:{self.lut // 1000}K DSP:{self.dsp} "
            f"BRAM:{self.bram} | {self.memory}"
        )


# Registry — add new platforms here
PLATFORMS: dict[str, Platform] = {
    "u50": Platform(
        key="u50", name="Alveo U50",
        device="xcu50-fsvh2104-2-e",
        platform_id="xilinx_u50_gen3x16_xdma_5_202210_1",
        family="UltraScale+", category="datacenter",
        lut=872160, ff=1743360, bram=1344, uram=640, dsp=5952,
        memory="8GB HBM2 (316 GB/s)",
    ),
    "u200": Platform(
        key="u200", name="Alveo U200",
        device="xcu200-fsgd2104-2-e",
        platform_id="xilinx_u200_gen3x16_xdma_2_202110_1",
        family="UltraScale+", category="datacenter",
        lut=1182240, ff=2364480, bram=2160, uram=960, dsp=6840,
        memory="64GB DDR4 (77 GB/s, 4ch)",
    ),
    "u250": Platform(
        key="u250", name="Alveo U250",
        device="xcu250-figd2104-2L-e",
        platform_id="xilinx_u250_gen3x16_xdma_4_1_202210_1",
        family="UltraScale+", category="datacenter",
        lut=1728000, ff=3456000, bram=2688, uram=1280, dsp=12288,
        memory="64GB DDR4 (77 GB/s, 4ch)",
    ),
    "u280": Platform(
        key="u280", name="Alveo U280",
        device="xcu280-fsvh2892-2L-e",
        platform_id="xilinx_u280_gen3x16_xdma_1_202211_1",
        family="UltraScale+", category="datacenter",
        lut=1304640, ff=2607360, bram=2016, uram=960, dsp=9024,
        memory="8GB HBM2 + 32GB DDR4",
    ),
    "u55c": Platform(
        key="u55c", name="Alveo U55C",
        device="xcu55c-fsvh2892-2L-e",
        platform_id="xilinx_u55c_gen3x16_xdma_3_202210_1",
        family="UltraScale+", category="datacenter",
        lut=1304640, ff=2607360, bram=2016, uram=960, dsp=9024,
        memory="16GB HBM2 (460 GB/s)",
    ),
    "vck5000": Platform(
        key="vck5000", name="Versal VCK5000",
        device="xcvc1902-vsvd1760-2MP-e-S",
        platform_id="xilinx_vck5000_gen4x8_qdma_2_202220_1",
        family="Versal AI Core", category="ai_engine",
        lut=899840, ff=1799680, bram=967, uram=463, dsp=1968,
        memory="16GB DDR4 (25 GB/s)",
    ),
    "v70": Platform(
        key="v70", name="Alveo V70",
        device="xcve2802-vsvh1760-2MP-e-S",
        platform_id="xilinx_v70_gen5x8_qdma_2_202320_1",
        family="Versal AI Edge", category="ai_engine",
        lut=329000, ff=658000, bram=400, uram=160, dsp=1312,
        memory="32GB DDR5 (51 GB/s)",
    ),
    "zcu102": Platform(
        key="zcu102", name="Zynq UltraScale+ ZCU102",
        device="xczu9eg-ffvb1156-2-e",
        platform_id="zcu102_base",
        family="Zynq UltraScale+ MPSoC", category="embedded",
        lut=274080, ff=548160, bram=912, uram=80, dsp=2520,
        memory="4GB DDR4 (PS)",
    ),
    "zcu104": Platform(
        key="zcu104", name="Zynq UltraScale+ ZCU104",
        device="xczu7ev-ffvc1156-2-e",
        platform_id="zcu104_base",
        family="Zynq UltraScale+ MPSoC", category="embedded",
        lut=230400, ff=460800, bram=624, uram=96, dsp=1728,
        memory="2GB DDR4 (PS)",
    ),
    "aws_f1": Platform(
        key="aws_f1", name="AWS F1 Instance",
        device="xcvu9p-flgb2104-2-i",
        platform_id="xilinx_aws-vu9p-f1_shell-v04261818_201920_3",
        family="UltraScale+", category="cloud",
        lut=1182240, ff=2364480, bram=2160, uram=960, dsp=6840,
        memory="64GB DDR4 (77 GB/s, 4ch)",
    ),
}

CATEGORIES = [
    ("datacenter", "Alveo Data Center Cards"),
    ("ai_engine", "Versal AI Engine"),
    ("embedded", "Zynq UltraScale+ (Embedded)"),
    ("cloud", "Cloud FPGA"),
]


def get_platform(key: str) -> Platform | None:
    return PLATFORMS.get(key.lower())


def list_by_category() -> list[tuple[str, str, list[Platform]]]:
    """Return [(cat_key, cat_name, [platforms])] grouped by category."""
    result = []
    for cat_key, cat_name in CATEGORIES:
        plats = [p for p in PLATFORMS.values() if p.category == cat_key]
        if plats:
            result.append((cat_key, cat_name, plats))
    return result

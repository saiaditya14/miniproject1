"""LLM usage capture — token counts, cost estimates, generation IDs.

Single chokepoint: chat_once() in llm.py calls record() after every LLM call.
The sink path is set per-design by the CLI; if unset, calls are no-ops (the
LLM still works, just no usage log).

Cost estimates come from a YAML price table searched in this order:
  1. $HLSCRIBE_COST_TABLE (explicit override)
  2. <project_root>/llm_costs.yaml         (per-bench, shared by collaborators)
  3. ~/.hlscribe/llm_costs.yaml            (user global)
  4. Bundled default at hlscribe/data/llm_costs.yaml (last resort; warns)

Reconciliation: OpenRouter responses include a generation_id; the
`hlscribe usage reconcile` command queries OpenRouter's /generation
endpoint to overwrite the estimated cost with the authoritative value.
"""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

_PACKAGE_DIR = Path(__file__).parent
_BUNDLED_COSTS = _PACKAGE_DIR / "data" / "llm_costs.yaml"

# Module globals — initialized by CLI before any chat_once call.
_log_path: Path | None = None
_cost_table: dict[str, dict[str, float]] | None = None
_cost_table_source: Path | None = None


@dataclass
class UsageRecord:
    """One LLM call's worth of telemetry."""

    timestamp: str                   # ISO 8601 UTC
    tag: str                          # e.g. "arch", "codegen-kernel", "fix-loop-r1"
    provider: str                     # "anthropic" | "openrouter" | "openai"
    model: str
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0
    cost_usd: float | None = None     # est from local table; may be reconciled
    cost_source: str = "estimated"    # "estimated" | "openrouter" | "unknown"
    duration_s: float = 0.0
    generation_id: str | None = None  # OpenRouter response id, for reconcile
    extra: dict[str, Any] = field(default_factory=dict)


def set_log_path(path: Path | None) -> None:
    """Set the JSONL sink. None disables capture."""
    global _log_path
    _log_path = path
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)


def get_log_path() -> Path | None:
    return _log_path


def set_project_root(project_root: Path) -> None:
    """Hint for cost-table lookup. Call once before first chat_once."""
    global _cost_table, _cost_table_source
    _cost_table = None  # force reload with new search order
    _cost_table_source = None
    _load_cost_table(project_root)


def _load_cost_table(project_root: Path | None = None) -> None:
    """Find and load llm_costs.yaml into the module cache."""
    global _cost_table, _cost_table_source

    candidates: list[Path] = []
    env_path = os.environ.get("HLSCRIBE_COST_TABLE")
    if env_path:
        candidates.append(Path(env_path).expanduser())
    if project_root is not None:
        candidates.append(project_root / "llm_costs.yaml")
        # Also search one level up — designs live one dir deep in a bench.
        candidates.append(project_root.parent / "llm_costs.yaml")
    candidates.append(Path.home() / ".hlscribe" / "llm_costs.yaml")
    candidates.append(_BUNDLED_COSTS)

    for p in candidates:
        if p.exists():
            with open(p) as f:
                data = yaml.safe_load(f) or {}
            _cost_table = data.get("models", {}) or {}
            _cost_table_source = p
            return

    _cost_table = {}
    _cost_table_source = None


def estimate_cost(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
) -> float | None:
    """Estimate USD cost from local price table. None if model is unknown.

    Prices are in USD per 1,000,000 tokens. The lookup key is the model
    string as sent to the provider (e.g. "anthropic/claude-opus-4.6").
    """
    if _cost_table is None:
        _load_cost_table()

    row = (_cost_table or {}).get(model)
    if row is None:
        return None

    cost = 0.0
    cost += (input_tokens / 1_000_000) * float(row.get("input", 0.0))
    cost += (output_tokens / 1_000_000) * float(row.get("output", 0.0))
    cost += (cache_read_tokens / 1_000_000) * float(row.get("cache_read", 0.0))
    cost += (cache_creation_tokens / 1_000_000) * float(row.get("cache_write", 0.0))
    return cost


def record(rec: UsageRecord) -> None:
    """Append one record to the JSONL sink. No-op if sink unset."""
    if _log_path is None:
        return
    line = json.dumps(asdict(rec), default=str)
    with open(_log_path, "a") as f:
        f.write(line + "\n")


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def extract_anthropic_usage(response: Any) -> dict[str, int]:
    """Pull token counts from an Anthropic SDK response."""
    u = getattr(response, "usage", None)
    if u is None:
        return {"input_tokens": 0, "output_tokens": 0,
                "cache_read_tokens": 0, "cache_creation_tokens": 0}
    return {
        "input_tokens": int(getattr(u, "input_tokens", 0) or 0),
        "output_tokens": int(getattr(u, "output_tokens", 0) or 0),
        "cache_read_tokens": int(getattr(u, "cache_read_input_tokens", 0) or 0),
        "cache_creation_tokens": int(getattr(u, "cache_creation_input_tokens", 0) or 0),
    }


def extract_openai_usage(response: Any) -> dict[str, int]:
    """Pull token counts from an OpenAI-compatible SDK response."""
    u = getattr(response, "usage", None)
    if u is None:
        return {"input_tokens": 0, "output_tokens": 0,
                "cache_read_tokens": 0, "cache_creation_tokens": 0}
    # OpenRouter / OpenAI use prompt_tokens + completion_tokens
    input_tokens = int(getattr(u, "prompt_tokens", 0) or 0)
    output_tokens = int(getattr(u, "completion_tokens", 0) or 0)
    # OpenAI cached prompts come back under prompt_tokens_details.cached_tokens
    cache_read = 0
    details = getattr(u, "prompt_tokens_details", None)
    if details is not None:
        cache_read = int(getattr(details, "cached_tokens", 0) or 0)
    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_tokens": cache_read,
        "cache_creation_tokens": 0,
    }


def cost_table_source() -> Path | None:
    """Return the path of the loaded cost table (for diagnostics)."""
    if _cost_table is None:
        _load_cost_table()
    return _cost_table_source


def load_records(path: Path) -> list[dict]:
    """Read a usage JSONL file into a list of dicts. Missing file -> []."""
    if not path.exists():
        return []
    rows: list[dict] = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return rows


def summarize(rows: list[dict]) -> dict:
    """Aggregate records keyed by (tag, model). Returns:
        {by_tag_model: {(tag, model): bucket}, totals: bucket, sources: {...}}
    """
    by_tag_model: dict[tuple[str, str], dict] = {}
    for r in rows:
        tag = r.get("tag", "untagged")
        model = r.get("model", "unknown")
        key = (tag, model)
        bucket = by_tag_model.setdefault(key, {
            "calls": 0,
            "input_tokens": 0,
            "output_tokens": 0,
            "cache_read_tokens": 0,
            "cache_creation_tokens": 0,
            "cost_usd": 0.0,
            "duration_s": 0.0,
            "missing_cost": 0,
        })
        bucket["calls"] += 1
        bucket["input_tokens"] += int(r.get("input_tokens") or 0)
        bucket["output_tokens"] += int(r.get("output_tokens") or 0)
        bucket["cache_read_tokens"] += int(r.get("cache_read_tokens") or 0)
        bucket["cache_creation_tokens"] += int(r.get("cache_creation_tokens") or 0)
        cost = r.get("cost_usd")
        if cost is None:
            bucket["missing_cost"] += 1
        else:
            bucket["cost_usd"] += float(cost)
        bucket["duration_s"] += float(r.get("duration_s") or 0)

    totals = {
        "calls": sum(b["calls"] for b in by_tag_model.values()),
        "input_tokens": sum(b["input_tokens"] for b in by_tag_model.values()),
        "output_tokens": sum(b["output_tokens"] for b in by_tag_model.values()),
        "cache_read_tokens": sum(b["cache_read_tokens"] for b in by_tag_model.values()),
        "cache_creation_tokens": sum(b["cache_creation_tokens"] for b in by_tag_model.values()),
        "cost_usd": sum(b["cost_usd"] for b in by_tag_model.values()),
        "duration_s": sum(b["duration_s"] for b in by_tag_model.values()),
        "missing_cost": sum(b["missing_cost"] for b in by_tag_model.values()),
    }
    # Source breakdown for cost provenance
    sources: dict[str, int] = {}
    for r in rows:
        sources[r.get("cost_source", "unknown")] = sources.get(r.get("cost_source", "unknown"), 0) + 1
    return {"by_tag_model": by_tag_model, "totals": totals, "sources": sources}


def reconcile_openrouter(
    path: Path,
    api_key: str,
    force: bool = False,
) -> dict:
    """Replace estimated costs with OpenRouter's authoritative cost.

    For each record with a generation_id and cost_source=="estimated",
    queries https://openrouter.ai/api/v1/generation?id=<id> and overwrites
    cost_usd / cost_source. With force=True, also re-fetches already
    reconciled rows.

    Writes the file in place atomically (via .tmp + rename). Returns
    {updated: N, skipped: N, failed: N, errors: [(row_index, msg), ...]}.
    """
    import urllib.request
    import urllib.error

    rows = load_records(path)
    updated = skipped = failed = 0
    errors: list[tuple[int, str]] = []

    for i, r in enumerate(rows):
        gen_id = r.get("generation_id")
        if not gen_id:
            skipped += 1
            continue
        if not force and r.get("cost_source") == "openrouter":
            skipped += 1
            continue

        req = urllib.request.Request(
            f"https://openrouter.ai/api/v1/generation?id={gen_id}",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            errors.append((i, f"HTTP {e.code}: {e.reason}"))
            failed += 1
            continue
        except Exception as e:  # noqa: BLE001
            errors.append((i, str(e)))
            failed += 1
            continue

        data = payload.get("data") or {}
        # OpenRouter returns total_cost in USD (typically a float)
        cost = data.get("total_cost")
        if cost is None:
            errors.append((i, "no total_cost in response"))
            failed += 1
            continue

        r["cost_usd"] = float(cost)
        r["cost_source"] = "openrouter"
        # Optionally enrich with OpenRouter's reported token counts (more
        # accurate than client-side for cached/uncached splits).
        for k_remote, k_local in (
            ("tokens_prompt", "input_tokens"),
            ("tokens_completion", "output_tokens"),
            ("native_tokens_prompt", "native_input_tokens"),
            ("native_tokens_completion", "native_output_tokens"),
        ):
            if k_remote in data:
                r.setdefault("extra", {})[k_local] = int(data[k_remote])
        updated += 1

    # Atomic write
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w") as f:
        for r in rows:
            f.write(json.dumps(r, default=str) + "\n")
    tmp.replace(path)

    return {
        "updated": updated,
        "skipped": skipped,
        "failed": failed,
        "errors": errors,
    }

"""Lessons log — JSONL data layer for fix-loop discoveries."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

LESSONS_LOG_PATH = Path.home() / ".hlscribe" / "lessons-log.jsonl"

# Truncation limits (keep entries compact)
_MAX_ERROR = 500
_MAX_ANALYSIS = 2000
_MAX_DIFF = 3000


@dataclass
class LessonEntry:
    """One fix-loop discovery."""

    timestamp: str
    benchmark: str  # project.name
    design: str  # design.name
    round: int
    fix_type: str  # "code" | "config"
    fix_target: str  # "kernel.cpp", "baseline.cfg", etc.
    build_stage: str  # "csim" | "csynth" | "cosim"
    error_summary: str  # first 500 chars of error report
    fix_analysis: str  # LLM analysis (first 2000 chars)
    fix_diff: str  # unified diff (first 3000 chars)
    model: str
    reviewed: bool = False


def _truncate(text: str, limit: int) -> str:
    """Truncate text to limit characters."""
    if len(text) <= limit:
        return text
    return text[:limit] + "..."


def append_lesson(
    log_path: Path | None = None,
    *,
    benchmark: str,
    design: str,
    round_num: int,
    fix_type: str,
    fix_target: str,
    build_stage: str,
    error_summary: str,
    fix_analysis: str,
    fix_diff: str,
    model: str,
) -> None:
    """Append a lesson entry to the JSONL log file."""
    path = log_path or LESSONS_LOG_PATH
    entry = LessonEntry(
        timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        benchmark=benchmark,
        design=design,
        round=round_num,
        fix_type=fix_type,
        fix_target=fix_target,
        build_stage=build_stage,
        error_summary=_truncate(error_summary, _MAX_ERROR),
        fix_analysis=_truncate(fix_analysis, _MAX_ANALYSIS),
        fix_diff=_truncate(fix_diff, _MAX_DIFF),
        model=model,
        reviewed=False,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(json.dumps(asdict(entry)) + "\n")


def read_lessons(
    log_path: Path | None = None,
    *,
    unreviewed_only: bool = False,
) -> list[LessonEntry]:
    """Read lesson entries from the JSONL log file.

    Args:
        log_path: Override path (defaults to LESSONS_LOG_PATH).
        unreviewed_only: If True, return only entries with reviewed=False.

    Returns:
        List of LessonEntry objects.
    """
    path = log_path or LESSONS_LOG_PATH
    if not path.exists():
        return []

    entries: list[LessonEntry] = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
            entry = LessonEntry(**data)
            if unreviewed_only and entry.reviewed:
                continue
            entries.append(entry)
        except (json.JSONDecodeError, TypeError):
            continue  # skip malformed lines
    return entries


def mark_reviewed(
    log_path: Path | None = None,
    *,
    indices: list[int] | None = None,
) -> int:
    """Mark entries as reviewed in the JSONL log file.

    Args:
        log_path: Override path (defaults to LESSONS_LOG_PATH).
        indices: 0-based indices to mark. If None, mark ALL unreviewed.

    Returns:
        Number of entries marked.
    """
    path = log_path or LESSONS_LOG_PATH
    if not path.exists():
        return 0

    lines = path.read_text().splitlines()
    marked = 0
    new_lines: list[str] = []

    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            new_lines.append(line)
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            new_lines.append(line)
            continue

        should_mark = False
        if indices is not None:
            should_mark = i in indices and not data.get("reviewed", False)
        else:
            should_mark = not data.get("reviewed", False)

        if should_mark:
            data["reviewed"] = True
            marked += 1

        new_lines.append(json.dumps(data))

    path.write_text("\n".join(new_lines) + "\n" if new_lines else "")
    return marked


def clear_reviewed(log_path: Path | None = None) -> int:
    """Remove reviewed entries from the JSONL log file.

    Args:
        log_path: Override path (defaults to LESSONS_LOG_PATH).

    Returns:
        Number of entries removed.
    """
    path = log_path or LESSONS_LOG_PATH
    if not path.exists():
        return 0

    lines = path.read_text().splitlines()
    kept: list[str] = []
    removed = 0

    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
        except json.JSONDecodeError:
            kept.append(line)
            continue

        if data.get("reviewed", False):
            removed += 1
        else:
            kept.append(json.dumps(data))

    path.write_text("\n".join(kept) + "\n" if kept else "")
    return removed

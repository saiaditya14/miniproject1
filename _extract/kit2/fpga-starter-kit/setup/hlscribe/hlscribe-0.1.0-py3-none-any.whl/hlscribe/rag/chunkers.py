"""Document chunkers — PDF and code file splitting for RAG indexing."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Chunk:
    """A single chunk of text ready for embedding and storage."""

    text: str  # content to embed
    doc_id: str  # unique ID for ChromaDB
    metadata: dict = field(default_factory=dict)


def _content_hash(text: str, length: int = 8) -> str:
    """Short hash prefix for document IDs."""
    return hashlib.sha256(text.encode()).hexdigest()[:length]


# ── PDF Chunker ──


def pdf_chunker(
    path: Path,
    source_id: str,
    target_size: int = 1000,
    overlap: int = 200,
) -> list[Chunk]:
    """Chunk a PDF file into overlapping text segments.

    Args:
        path: Path to PDF file.
        source_id: Source identifier (e.g. "ug1399").
        target_size: Target tokens per chunk (~4 chars/token).
        overlap: Overlap tokens between consecutive chunks.

    Returns:
        List of Chunk objects with page metadata.
    """
    import fitz  # PyMuPDF

    doc = fitz.open(str(path))
    chunks: list[Chunk] = []

    # Extract text page by page with page numbers
    pages: list[tuple[int, str]] = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text")
        if text.strip():
            pages.append((page_num + 1, text))
    doc.close()

    if not pages:
        return []

    # Detect section headings: numbered (e.g. "3.2.1 Title") or ALL-CAPS lines
    heading_re = re.compile(
        r"^(?:\d+(?:\.\d+)*\s+[A-Z].*|[A-Z][A-Z\s]{5,})$", re.MULTILINE
    )

    target_chars = target_size * 4
    overlap_chars = overlap * 4

    # Build sections from pages, splitting at headings
    sections: list[dict] = []  # {"text", "page", "title"}
    current_text = ""
    current_page = pages[0][0]
    current_title = source_id

    for page_num, page_text in pages:
        lines = page_text.split("\n")
        for line in lines:
            stripped = line.strip()
            if not stripped:
                current_text += "\n"
                continue

            # Check if this line is a heading
            if heading_re.match(stripped) and len(stripped) < 120:
                # Save current section if it has content
                if current_text.strip() and len(current_text.strip()) > 50:
                    sections.append({
                        "text": current_text.strip(),
                        "page": current_page,
                        "title": current_title,
                    })
                current_text = stripped + "\n"
                current_page = page_num
                current_title = stripped[:100]
            else:
                current_text += stripped + "\n"

    # Don't forget last section
    if current_text.strip():
        sections.append({
            "text": current_text.strip(),
            "page": current_page,
            "title": current_title,
        })

    # Split sections into chunks of target_chars with overlap
    chunk_index = 0
    for section in sections:
        text = section["text"]
        if len(text) <= target_chars:
            doc_id = f"{source_id}:{_content_hash(text)}:{chunk_index}"
            chunks.append(Chunk(
                text=text,
                doc_id=doc_id,
                metadata={
                    "source": source_id,
                    "source_type": "pdf",
                    "title": section["title"],
                    "file_path": str(path),
                    "page": section["page"],
                    "chunk_index": chunk_index,
                },
            ))
            chunk_index += 1
        else:
            # Split long sections with overlap
            pos = 0
            while pos < len(text):
                end = pos + target_chars
                chunk_text = text[pos:end]

                # Try to break at sentence boundary
                if end < len(text):
                    last_period = chunk_text.rfind(". ")
                    if last_period > target_chars // 2:
                        chunk_text = chunk_text[: last_period + 1]
                        end = pos + last_period + 1

                doc_id = f"{source_id}:{_content_hash(chunk_text)}:{chunk_index}"
                chunks.append(Chunk(
                    text=chunk_text.strip(),
                    doc_id=doc_id,
                    metadata={
                        "source": source_id,
                        "source_type": "pdf",
                        "title": section["title"],
                        "file_path": str(path),
                        "page": section["page"],
                        "chunk_index": chunk_index,
                    },
                ))
                chunk_index += 1

                # Advance with overlap
                pos = end - overlap_chars
                if pos <= (end - target_chars):
                    pos = end  # prevent infinite loop

    return chunks


# ── Code Chunker ──


_PRAGMA_RE = re.compile(r"#pragma\s+HLS\s+(\w+)", re.IGNORECASE)
_FUNC_RE = re.compile(
    r"^(?:void|int|float|double|bool|unsigned|auto|static\s+)?\s*\w+\s*\([^)]*\)\s*\{",
    re.MULTILINE,
)


def _detect_pragmas(code: str) -> list[str]:
    """Extract unique HLS pragma names from code."""
    return sorted(set(_PRAGMA_RE.findall(code)))


def _category_from_path(path: Path) -> str:
    """Derive category from directory name (e.g. 'Pipelining', 'DSP')."""
    parts = path.parts
    # Look for meaningful directory name (skip common prefixes)
    for part in reversed(parts[:-1]):  # skip filename
        if part and not part.startswith(".") and part not in ("src", "include"):
            return part
    return "General"


def _read_description(directory: Path) -> str:
    """Read description.json or README from a directory for context."""
    desc_file = directory / "description.json"
    if desc_file.exists():
        try:
            data = json.loads(desc_file.read_text())
            parts = []
            if "name" in data:
                parts.append(data["name"])
            if "description" in data:
                parts.append(data["description"])
            if "key_concepts" in data:
                concepts = data["key_concepts"]
                if isinstance(concepts, list):
                    parts.append("Concepts: " + ", ".join(concepts))
            return " — ".join(parts) if parts else ""
        except (json.JSONDecodeError, KeyError):
            pass

    readme = directory / "README.md"
    if not readme.exists():
        readme = directory / "README"
    if readme.exists():
        text = readme.read_text()
        # Just first paragraph
        first_para = text.split("\n\n")[0].strip()
        return first_para[:300]

    return ""


def _split_at_functions(code: str, max_lines: int = 200) -> list[str]:
    """Split long code files at function boundaries."""
    lines = code.split("\n")
    if len(lines) <= max_lines:
        return [code]

    chunks: list[str] = []
    current: list[str] = []

    for line in lines:
        current.append(line)
        # Check if this looks like a function definition start
        if len(current) > max_lines and _FUNC_RE.match(line):
            # Split before this function
            chunks.append("\n".join(current[:-1]))
            current = [line]

    if current:
        chunks.append("\n".join(current))

    return chunks if chunks else [code]


def ontology_chunker(
    root: Path,
    source_id: str = "ontology",
) -> list[Chunk]:
    """Chunk the ontology's rich markdown docs for semantic retrieval.

    The ontology has two complementary representations:
      - schema/*.yaml  : terse structured data (one file per category)
      - docs/**/*.md   : long-form narrative with examples, diagrams,
                         and explanation per entry

    For embedding, the MD content is far better signal than YAML
    (narrative prose, code samples, ASCII diagrams, "when to use"
    sections). One chunk per non-index/non-template MD file under
    docs/. Category is derived from the parent directory name
    (pragmas/, patterns/, types/, decision-guides/, interfaces/).

    Args:
        root: Path to the ontology root (the dir containing docs/).
        source_id: Source identifier in the RAG index (default "ontology").

    Returns:
        List of Chunk objects, one per docs MD file.
    """
    docs_dir = root / "docs"
    if not docs_dir.is_dir():
        return []

    chunks: list[Chunk] = []
    chunk_index = 0

    # Walk recursively. Each .md file becomes one chunk. Category =
    # parent directory name. We DO include index.md files because in
    # this ontology they are the canonical pragma references
    # (e.g. docs/pragmas/index.md is the 500-line pragma reference,
    # not a navigation stub). Skip only TEMPLATE files.
    for md_path in sorted(docs_dir.rglob("*.md")):
        if "TEMPLATE" in md_path.name:
            continue
        try:
            body = md_path.read_text(errors="replace")
        except (OSError, PermissionError):
            continue
        if not body.strip():
            continue

        # category: parent dir name (e.g. "pragmas", "patterns", "types",
        # "decision-guides", "interfaces"). For the few MDs that live at
        # the top level (overview.md), use "ontology-root".
        try:
            rel = md_path.relative_to(docs_dir)
            parts = rel.parts
            category = parts[0] if len(parts) > 1 else "ontology-root"
        except ValueError:
            category = "unknown"

        # Title from filename (strip .md). For index.md (e.g. pragmas/
        # index.md = the pragma reference) use the parent dir name so
        # the title is informative ("pragmas-reference", not "index").
        if md_path.name == "index.md" and md_path.parent.name != "docs":
            title = f"{md_path.parent.name}-reference"
        else:
            title = md_path.stem

        # Compose embed text with a small category header so the
        # embedding model has clean category signal alongside the MD.
        header = f"[Category: ontology/{category}] [Title: {title}]"
        embed_text = f"{header}\n\n{body}"

        doc_id = f"{source_id}:{_content_hash(embed_text)}:{chunk_index}"
        chunks.append(Chunk(
            text=embed_text,
            doc_id=doc_id,
            metadata={
                "source": source_id,
                "source_type": "ontology-md",
                "category": category,
                "title": title,
                "file_path": str(md_path),
                "page": -1,
                "chunk_index": chunk_index,
            },
        ))
        chunk_index += 1

    return chunks


def code_chunker(
    directory: Path,
    source_id: str = "examples",
) -> list[Chunk]:
    """Chunk C/C++ code files from a directory tree.

    Each file becomes one chunk (most are 20-100 lines).
    Files > 200 lines are split at function boundaries.
    Embedding text is enriched with category, pragmas, and description context.

    Args:
        directory: Root directory to walk recursively.
        source_id: Source identifier (default "examples").

    Returns:
        List of Chunk objects with pragma/category metadata.
    """
    chunks: list[Chunk] = []
    extensions = {".cpp", ".h", ".c", ".hpp"}
    chunk_index = 0

    for code_path in sorted(directory.rglob("*")):
        if code_path.suffix not in extensions:
            continue
        if code_path.name.startswith("."):
            continue

        try:
            code = code_path.read_text(errors="replace")
        except (OSError, PermissionError):
            continue

        if not code.strip():
            continue

        pragmas = _detect_pragmas(code)
        category = _category_from_path(code_path)
        description = _read_description(code_path.parent)

        code_parts = _split_at_functions(code)

        for part_idx, part in enumerate(code_parts):
            # Build composite embedding text with context
            header_parts = [f"[Category: {category}]", f"[File: {code_path.name}]"]
            if pragmas:
                header_parts.append(f"[Pragmas: {', '.join(pragmas)}]")
            if description:
                header_parts.append(f"[Description: {description}]")
            embed_text = " ".join(header_parts) + "\n\n" + part

            suffix = f"_{part_idx}" if len(code_parts) > 1 else ""
            doc_id = f"{source_id}:{_content_hash(part)}:{chunk_index}"

            chunks.append(Chunk(
                text=embed_text,
                doc_id=doc_id,
                metadata={
                    "source": source_id,
                    "source_type": "code",
                    "title": code_path.name,
                    "file_path": str(code_path),
                    "page": -1,
                    "pragmas": ", ".join(pragmas) if pragmas else "",
                    "category": category,
                    "chunk_index": chunk_index,
                },
            ))
            chunk_index += 1

    return chunks

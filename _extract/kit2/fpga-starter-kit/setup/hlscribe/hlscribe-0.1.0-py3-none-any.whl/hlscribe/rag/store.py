"""ChromaDB vector store wrapper — single collection with metadata filtering."""

from __future__ import annotations

import sys
from pathlib import Path

# ChromaDB requires sqlite3 >= 3.35.0.  On older systems (e.g. Ubuntu 20.04)
# the built-in sqlite3 is too old.  pysqlite3-binary ships a modern version.
try:
    import pysqlite3  # type: ignore[import-untyped]
    sys.modules["sqlite3"] = pysqlite3
except ImportError:
    pass  # system sqlite3 is new enough


class RagStore:
    """Thin wrapper around a persistent ChromaDB collection."""

    COLLECTION = "hls_docs"

    def __init__(self, store_path: Path | None = None, ephemeral: bool = False):
        """Initialize store.

        Args:
            store_path: Directory for persistent ChromaDB storage.
            ephemeral: If True, use in-memory store (for testing).
        """
        import chromadb

        if ephemeral:
            self._client = chromadb.EphemeralClient()
        else:
            if store_path is None:
                raise ValueError("store_path required for persistent store")
            store_path.mkdir(parents=True, exist_ok=True)
            self._client = chromadb.PersistentClient(path=str(store_path))

        self._collection = self._client.get_or_create_collection(
            name=self.COLLECTION,
            metadata={"hnsw:space": "cosine"},
        )

    def add(
        self,
        ids: list[str],
        embeddings: list[list[float]],
        documents: list[str],
        metadatas: list[dict],
    ) -> None:
        """Add or upsert documents into the collection."""
        self._collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas,
        )

    def query(
        self,
        embedding: list[float],
        n_results: int = 10,
        where: dict | None = None,
    ) -> list[dict]:
        """Query by embedding vector, return list of result dicts."""
        kwargs: dict = {
            "query_embeddings": [embedding],
            "n_results": n_results,
            "include": ["documents", "metadatas", "distances"],
        }
        if where:
            kwargs["where"] = where

        results = self._collection.query(**kwargs)

        # Unpack ChromaDB's nested list format
        out: list[dict] = []
        if results["ids"] and results["ids"][0]:
            for i, doc_id in enumerate(results["ids"][0]):
                out.append({
                    "id": doc_id,
                    "document": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i],
                    "distance": results["distances"][0][i],
                })
        return out

    def delete(self, where: dict) -> None:
        """Delete documents matching metadata filter."""
        self._collection.delete(where=where)

    def count(self, where: dict | None = None) -> int:
        """Count documents, optionally filtered by metadata."""
        if where is None:
            return self._collection.count()
        # ChromaDB doesn't support count with where; use get
        result = self._collection.get(where=where, include=[])
        return len(result["ids"])

"""Embedding client — Voyage AI API wrapper + mock for testing."""

from __future__ import annotations

import hashlib
import math
from typing import Protocol


class Embedder(Protocol):
    """Protocol for embedding providers."""

    def embed(self, texts: list[str]) -> list[list[float]]: ...
    def embed_query(self, query: str) -> list[float]: ...


class EmbeddingClient:
    """Voyage AI embedding client (voyage-code-3, 1024 dims)."""

    MAX_BATCH = 128
    MAX_BATCH_TOKENS = 100_000  # Voyage limit is 120K; leave headroom

    def __init__(self, api_key: str, model: str = "voyage-code-3"):
        import voyageai
        self._client = voyageai.Client(api_key=api_key)
        self._model = model

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        """Rough token estimate: ~4 chars per token for English/code."""
        return len(text) // 4 + 1

    def _make_batches(self, texts: list[str]) -> list[list[str]]:
        """Split texts into batches respecting both count and token limits."""
        batches: list[list[str]] = []
        current: list[str] = []
        current_tokens = 0

        for text in texts:
            tok = self._estimate_tokens(text)
            if current and (
                len(current) >= self.MAX_BATCH
                or current_tokens + tok > self.MAX_BATCH_TOKENS
            ):
                batches.append(current)
                current = []
                current_tokens = 0
            current.append(text)
            current_tokens += tok

        if current:
            batches.append(current)
        return batches

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts, batching by count and token budget."""
        all_embeddings: list[list[float]] = []
        for batch in self._make_batches(texts):
            result = self._client.embed(batch, model=self._model, input_type="document")
            all_embeddings.extend(result.embeddings)
        return all_embeddings

    def embed_query(self, query: str) -> list[float]:
        """Embed a single query (uses query input_type for asymmetric search)."""
        result = self._client.embed([query], model=self._model, input_type="query")
        return result.embeddings[0]


class MockEmbeddingClient:
    """Deterministic hash-based vectors for testing (no API calls).

    Produces 64-dim unit vectors derived from content hash.
    Deterministic: same text always yields same vector.
    """

    DIMS = 64

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._hash_embed(t) for t in texts]

    def embed_query(self, query: str) -> list[float]:
        return self._hash_embed(query)

    def _hash_embed(self, text: str) -> list[float]:
        h = hashlib.sha256(text.encode()).digest()
        # Use hash bytes to seed a simple deterministic vector
        raw = [((b - 128) / 128.0) for b in h[: self.DIMS]]
        # Pad if needed (SHA-256 = 32 bytes, we want 64 dims)
        while len(raw) < self.DIMS:
            h2 = hashlib.sha256(h + len(raw).to_bytes(2, "big")).digest()
            raw.extend(((b - 128) / 128.0) for b in h2)
        raw = raw[: self.DIMS]
        # Normalize to unit vector
        norm = math.sqrt(sum(x * x for x in raw))
        if norm > 0:
            raw = [x / norm for x in raw]
        return raw

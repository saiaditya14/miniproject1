"""Index orchestration — incremental indexing with manifest tracking."""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from pathlib import Path

from hlscribe.rag.config import RagConfig
from hlscribe.rag.store import RagStore


@dataclass
class IndexResult:
    """Result from indexing a single source."""

    source_id: str
    chunks_added: int
    duration_seconds: float
    skipped: bool


class Indexer:
    """Orchestrates chunking, embedding, and storage for RAG sources."""

    def __init__(
        self,
        store: RagStore,
        embedder,
        config: RagConfig,
    ):
        self._store = store
        self._embedder = embedder
        self._config = config
        self._manifest = self._load_manifest()

    def _load_manifest(self) -> dict:
        """Load index manifest (tracks content hashes per source)."""
        if self._config.manifest_path.exists():
            return json.loads(self._config.manifest_path.read_text())
        return {}

    def _save_manifest(self) -> None:
        """Persist manifest to disk."""
        self._config.manifest_path.parent.mkdir(parents=True, exist_ok=True)
        self._config.manifest_path.write_text(
            json.dumps(self._manifest, indent=2)
        )

    def _compute_source_hash(self, source_id: str) -> str:
        """Compute a content hash for a source to detect changes."""
        path = self._config.sources.get(source_id)
        if path is None or not path.exists():
            return ""

        # Per-source extension set: ontology dirs contain YAML/MD, code
        # dirs contain C/C++. Add new sources here as needed.
        if source_id == "ontology":
            exts = {".yaml", ".yml", ".md"}
        else:
            exts = {".cpp", ".h", ".c", ".hpp"}

        h = hashlib.sha256()
        if path.is_file():
            # For PDF files, hash file size + mtime (fast approximation)
            stat = path.stat()
            h.update(f"{stat.st_size}:{stat.st_mtime_ns}".encode())
        elif path.is_dir():
            # For directories, hash all source files' names and sizes
            for f in sorted(path.rglob("*")):
                if f.suffix in exts and f.is_file():
                    stat = f.stat()
                    h.update(f"{f.name}:{stat.st_size}".encode())
        return h.hexdigest()[:16]

    def needs_reindex(self, source_id: str) -> bool:
        """Check if a source needs re-indexing (content changed or missing)."""
        current_hash = self._compute_source_hash(source_id)
        if not current_hash:
            return False  # source doesn't exist
        stored = self._manifest.get(source_id, {})
        return stored.get("hash") != current_hash

    def index_source(
        self,
        source_id: str,
        force: bool = False,
        progress_callback=None,
    ) -> IndexResult:
        """Index a single source.

        Args:
            source_id: Source identifier (e.g. "ug1399", "examples").
            force: Re-index even if content hasn't changed.
            progress_callback: Optional callable(msg: str) for status updates.

        Returns:
            IndexResult with stats.
        """
        path = self._config.sources.get(source_id)
        if path is None:
            raise ValueError(f"Unknown source: {source_id}")
        if not path.exists():
            raise FileNotFoundError(f"Source path not found: {path}")

        # Check if re-indexing is needed
        if not force and not self.needs_reindex(source_id):
            return IndexResult(
                source_id=source_id,
                chunks_added=0,
                duration_seconds=0.0,
                skipped=True,
            )

        start = time.time()

        # Chunk the source
        if progress_callback:
            progress_callback(f"Chunking {source_id}...")

        from hlscribe.rag.chunkers import code_chunker, ontology_chunker, pdf_chunker

        if path.is_file() and path.suffix.lower() == ".pdf":
            chunks = pdf_chunker(path, source_id)
        elif path.is_dir() and source_id == "ontology":
            chunks = ontology_chunker(path, source_id)
        elif path.is_dir():
            chunks = code_chunker(path, source_id)
        else:
            raise ValueError(f"Unsupported source type: {path}")

        if not chunks:
            return IndexResult(
                source_id=source_id,
                chunks_added=0,
                duration_seconds=time.time() - start,
                skipped=False,
            )

        # Delete old chunks for this source
        if progress_callback:
            progress_callback(f"Clearing old {source_id} chunks...")
        try:
            self._store.delete(where={"source": source_id})
        except Exception:
            pass  # collection might be empty

        # Embed in batches
        if progress_callback:
            progress_callback(f"Embedding {len(chunks)} chunks...")

        texts = [c.text for c in chunks]
        embeddings = self._embedder.embed(texts)

        # Store
        if progress_callback:
            progress_callback(f"Storing {len(chunks)} chunks...")

        ids = [c.doc_id for c in chunks]
        metadatas = [c.metadata for c in chunks]
        self._store.add(ids, embeddings, texts, metadatas)

        # Update manifest
        self._manifest[source_id] = {
            "hash": self._compute_source_hash(source_id),
            "chunks": len(chunks),
            "indexed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        self._save_manifest()

        duration = time.time() - start
        return IndexResult(
            source_id=source_id,
            chunks_added=len(chunks),
            duration_seconds=duration,
            skipped=False,
        )

    def index_all(
        self,
        force: bool = False,
        progress_callback=None,
    ) -> dict[str, IndexResult]:
        """Index all configured sources.

        Returns:
            Dict mapping source_id to IndexResult.
        """
        results: dict[str, IndexResult] = {}
        for source_id in self._config.sources:
            path = self._config.sources[source_id]
            if not path.exists():
                if progress_callback:
                    progress_callback(f"Skipping {source_id} (not found: {path})")
                continue
            try:
                result = self.index_source(
                    source_id, force=force, progress_callback=progress_callback
                )
                results[source_id] = result
            except Exception as e:
                if progress_callback:
                    progress_callback(f"Error indexing {source_id}: {e}")
                results[source_id] = IndexResult(
                    source_id=source_id,
                    chunks_added=0,
                    duration_seconds=0.0,
                    skipped=False,
                )
        return results

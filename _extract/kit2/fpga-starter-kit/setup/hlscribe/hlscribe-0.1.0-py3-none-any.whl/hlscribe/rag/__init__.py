"""HLS Documentation RAG — semantic search over Vitis HLS docs and examples.

Public API:
    HLSRag      — main entry point (search, get_context, stats)
    SearchResult — typed result from search queries
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SearchResult:
    """A single search result from the RAG store."""

    text: str
    score: float  # 0.0 = perfect match, higher = worse (cosine distance)
    source: str  # e.g. "ug1399", "examples"
    source_type: str  # "pdf" or "code"
    title: str  # section heading or filename
    file_path: str  # original source path
    page: int | None  # PDF page number, None for code
    metadata: dict = field(default_factory=dict)


class HLSRag:
    """Semantic search over HLS documentation and code examples.

    Usage::

        rag = HLSRag()
        if rag.is_indexed:
            results = rag.search("how to pipeline a loop")
            context = rag.get_context("DATAFLOW pragma usage")
    """

    def __init__(
        self,
        store_path: Path | None = None,
        api_key: str | None = None,
    ):
        from hlscribe.rag.config import RagConfig

        self._config = RagConfig.load()
        self._store_path = store_path or self._config.store_path
        self._api_key = api_key or self._config.get_api_key()
        self._store = None
        self._embedder = None

    def _get_store(self):
        if self._store is None:
            from hlscribe.rag.store import RagStore
            if not self._store_path.exists():
                return None
            self._store = RagStore(store_path=self._store_path)
        return self._store

    def _get_embedder(self):
        if self._embedder is None:
            if not self._api_key:
                raise RuntimeError(
                    "VOYAGE_API_KEY not set. Add it to ~/.hlscribe/.env or set the environment variable."
                )
            from hlscribe.rag.embeddings import EmbeddingClient
            self._embedder = EmbeddingClient(
                api_key=self._api_key,
                model=self._config.embedding_model,
            )
        return self._embedder

    def search(
        self,
        query: str,
        n_results: int = 10,
        source: str | None = None,
    ) -> list[SearchResult]:
        """Semantic search across indexed HLS documentation.

        Args:
            query: Natural language query.
            n_results: Max results to return.
            source: Filter by source ID (e.g. "ug1399", "examples").

        Returns:
            List of SearchResult, sorted by relevance (best first).
        """
        store = self._get_store()
        if store is None:
            return []

        embedder = self._get_embedder()
        query_vec = embedder.embed_query(query)

        where = {"source": source} if source else None
        raw = store.query(query_vec, n_results=n_results, where=where)

        results = []
        for r in raw:
            meta = r["metadata"]
            page = meta.get("page")
            if page is not None and page < 0:
                page = None
            results.append(SearchResult(
                text=r["document"],
                score=r["distance"],
                source=meta.get("source", ""),
                source_type=meta.get("source_type", ""),
                title=meta.get("title", ""),
                file_path=meta.get("file_path", ""),
                page=page,
                metadata=meta,
            ))
        return results

    def get_context(self, query: str, max_tokens: int = 4000) -> str:
        """Get formatted context string for LLM prompt injection.

        Searches and concatenates results, truncating to max_tokens
        (estimated at 4 chars per token).
        """
        results = self.search(query, n_results=15)
        if not results:
            return ""

        max_chars = max_tokens * 4
        sections: list[str] = []
        total = 0

        for r in results:
            header = f"### {r.title}"
            if r.page is not None:
                header += f" (p.{r.page})"
            header += f"\n*Source: {r.source}*\n"
            entry = f"{header}\n{r.text}\n"

            if total + len(entry) > max_chars:
                # Add truncated remainder if there's room
                remaining = max_chars - total
                if remaining > 200:
                    sections.append(entry[:remaining] + "\n...(truncated)")
                break
            sections.append(entry)
            total += len(entry)

        return "\n".join(sections)

    def get_error_context(self, error_text: str, max_tokens: int = 2000) -> str:
        """Get context specifically for HLS error messages."""
        return self.get_context(error_text, max_tokens=max_tokens)

    @property
    def is_indexed(self) -> bool:
        """True if the store exists and has documents."""
        store = self._get_store()
        if store is None:
            return False
        return store.count() > 0

    @property
    def stats(self) -> dict:
        """Return index statistics: total count and per-source counts."""
        store = self._get_store()
        if store is None:
            return {"total": 0, "sources": {}}

        total = store.count()
        sources: dict[str, int] = {}
        # Pull the source list from RagConfig instead of hardcoding so
        # new sources (e.g. "ontology") are picked up automatically.
        from hlscribe.rag.config import RagConfig
        for src in RagConfig.load().sources.keys():
            cnt = store.count(where={"source": src})
            if cnt > 0:
                sources[src] = cnt

        return {"total": total, "sources": sources}


__all__ = ["HLSRag", "SearchResult"]

"""RAG-specific configuration — paths, source registry, embedding model."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

RAG_DIR = Path.home() / ".hlscribe" / "rag"

# Default source paths (override via ~/.hlscribe/rag/config.yaml)
_DEFAULT_SOURCES: dict[str, str] = {
    "ug1399": "~/hls-codegen-ontology/manuals/ug1399-vitis-hls-en-us-2025.2.pdf",
    "ug1448": "~/hls-codegen-ontology/manuals/UG1448.pdf",
    "bluebook": "~/hls-codegen-ontology/hls/books/hls_bluebook_uv.pdf",
    "examples": "~/hls-codegen-ontology/Vitis-HLS-Introductory-Examples/",
    # The structured ontology — pragmas, patterns, types, guides, errors —
    # served via the ontology_chunker into the same vector store. Folding
    # it in lets `query_rag` semantically retrieve structured ontology
    # entries alongside free-text Vitis docs.
    "ontology": "~/hls-codegen-ontology/",
}


@dataclass
class RagConfig:
    """Configuration for the RAG subsystem."""

    store_path: Path = field(default_factory=lambda: RAG_DIR / "chroma")
    manifest_path: Path = field(default_factory=lambda: RAG_DIR / "index_manifest.json")
    embedding_model: str = "voyage-code-3"
    sources: dict[str, Path] = field(default_factory=dict)

    def __post_init__(self):
        if not self.sources:
            self.sources = {
                k: Path(v).expanduser() for k, v in _DEFAULT_SOURCES.items()
            }

    @classmethod
    def load(cls) -> RagConfig:
        """Load RAG config, merging overrides from ~/.hlscribe/rag/config.yaml."""
        cfg = cls()
        override_path = RAG_DIR / "config.yaml"
        if override_path.exists():
            data = yaml.safe_load(override_path.read_text()) or {}
            if "store_path" in data:
                cfg.store_path = Path(data["store_path"]).expanduser()
            if "manifest_path" in data:
                cfg.manifest_path = Path(data["manifest_path"]).expanduser()
            if "embedding_model" in data:
                cfg.embedding_model = data["embedding_model"]
            if "sources" in data and isinstance(data["sources"], dict):
                for k, v in data["sources"].items():
                    cfg.sources[k] = Path(v).expanduser()
        return cfg

    def get_api_key(self) -> str | None:
        """Read VOYAGE_API_KEY from environment or ~/.hlscribe/.env."""
        import os
        key = os.environ.get("VOYAGE_API_KEY")
        if key:
            return key
        env_path = Path.home() / ".hlscribe" / ".env"
        if env_path.exists():
            from dotenv import dotenv_values
            vals = dotenv_values(env_path)
            return vals.get("VOYAGE_API_KEY")
        return None

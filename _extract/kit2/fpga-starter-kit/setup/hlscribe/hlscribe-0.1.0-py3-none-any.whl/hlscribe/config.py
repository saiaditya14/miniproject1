"""Configuration loading from ~/.hlscribe/.env + hlscribe.yaml."""

from __future__ import annotations

import getpass
import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml
from dotenv import load_dotenv

from hlscribe.platforms import Platform, get_platform

# Provider → (default API base, env var for API key, default model)
PROVIDERS = {
    "anthropic": {
        "api_base": "https://api.anthropic.com",
        "key_env": "ANTHROPIC_API_KEY",
        "default_model": "claude-sonnet-4-20250514",
    },
    "openrouter": {
        "api_base": "https://openrouter.ai/api/v1",
        "key_env": "OPENROUTER_API_KEY",
        "default_model": "anthropic/claude-sonnet-4",
    },
    "openai": {
        "api_base": "https://api.openai.com/v1",
        "key_env": "OPENAI_API_KEY",
        "default_model": "gpt-4o",
    },
}


@dataclass
class LLMConfig:
    provider: str
    api_key: str
    api_base: str
    model: str
    max_tokens: int = 16384
    temperature: float = 0.2
    # Reasoning/thinking effort: None, "low", "medium", or "high".
    # When set on OpenRouter routes, passed as extra_body.reasoning.effort —
    # enables extended thinking for Anthropic, reasoning_effort for OpenAI
    # o-series, and the equivalent for Gemini/DeepSeek-R1.
    reasoning: str | None = None


@dataclass
class SlurmConfig:
    host: str = ""
    user: str = ""
    partition: str = "batch"
    nodes: int = 4
    cpus: int = 8
    mem: str = "32G"
    time: str = "02:00:00"

    @property
    def enabled(self) -> bool:
        return bool(self.host)

    @property
    def ssh_target(self) -> str:
        if self.user:
            return f"{self.user}@{self.host}"
        return self.host


@dataclass
class AppConfig:
    llm: LLMConfig
    slurm: SlurmConfig = field(default_factory=SlurmConfig)
    platform: Platform | None = None
    clock: str = "3.3ns"
    top_function: str = "kernel_top"
    max_fix_rounds: int = 5
    build_timeout: int = 300
    no_rag: bool = False
    no_ontology: bool = False


def _load_slurm_config(global_data: dict, project_data: dict) -> SlurmConfig:
    """Build SlurmConfig from user-level + project-level settings."""
    merged: dict = {}
    for src in (global_data.get("slurm") or {}, project_data.get("slurm") or {}):
        merged.update(src)
    if not merged:
        return SlurmConfig()
    return SlurmConfig(
        host=str(merged.get("host", "")),
        user=str(merged.get("user", "")),
        partition=str(merged.get("partition", "batch")),
        nodes=int(merged.get("nodes", 4)),
        cpus=int(merged.get("cpus", 8)),
        mem=str(merged.get("mem", "32G")),
        time=str(merged.get("time", "02:00:00")),
    )


def load_config(project_dir: Path | None = None) -> AppConfig:
    """Load config from ~/.hlscribe/.env (secrets) + hlscribe.yaml (project).

    Also loads user-level defaults from ~/.hlscribe/config.yaml (slurm, etc.).

    Args:
        project_dir: Project root containing hlscribe.yaml. Defaults to cwd.

    Returns:
        Populated AppConfig.

    Raises:
        SystemExit: If the required API key is not set.
    """
    # Load secrets from global .env
    global_env = Path.home() / ".hlscribe" / ".env"
    if global_env.exists():
        load_dotenv(global_env)

    # Load user-level config (slurm defaults, etc.)
    global_config_path = Path.home() / ".hlscribe" / "config.yaml"
    global_data: dict = {}
    if global_config_path.exists():
        with open(global_config_path) as f:
            global_data = yaml.safe_load(f) or {}

    # Load project config (if present)
    if project_dir is None:
        project_dir = Path.cwd()
    yaml_path = project_dir / "hlscribe.yaml"

    data: dict = {}
    if yaml_path.exists():
        with open(yaml_path) as f:
            data = yaml.safe_load(f) or {}

    # Resolve provider
    provider_name = data.get("provider", "anthropic")
    if provider_name not in PROVIDERS:
        raise SystemExit(
            f"Unknown provider: {provider_name}. "
            f"Choose from: {', '.join(PROVIDERS)}"
        )
    provider = PROVIDERS[provider_name]

    # Resolve API key — if no explicit provider was configured and the
    # default key is missing, auto-detect a provider whose key IS set.
    api_key = os.environ.get(provider["key_env"], "")
    if not api_key and "provider" not in data:
        for fallback_name, fallback in PROVIDERS.items():
            if fallback_name == provider_name:
                continue
            fb_key = os.environ.get(fallback["key_env"], "")
            if fb_key:
                provider_name = fallback_name
                provider = fallback
                api_key = fb_key
                break
    if not api_key:
        raise SystemExit(
            f"{provider['key_env']} not set. "
            f"Add it to ~/.hlscribe/.env or export it."
        )

    reasoning = data.get("reasoning")
    if reasoning is not None and reasoning not in ("low", "medium", "high"):
        raise SystemExit(
            f"Invalid reasoning level: {reasoning!r}. "
            f"Choose from: low, medium, high (or omit to disable)."
        )

    llm = LLMConfig(
        provider=provider_name,
        api_key=api_key,
        api_base=provider["api_base"],
        model=data.get("model", provider["default_model"]),
        max_tokens=data.get("max_tokens", 16384),
        temperature=data.get("temperature", 0.2),
        reasoning=reasoning,
    )

    # Resolve platform
    platform = None
    platform_key = data.get("platform")
    if platform_key:
        platform = get_platform(platform_key)

    # Resolve slurm config (global defaults + project overrides)
    slurm = _load_slurm_config(global_data, data)

    return AppConfig(
        llm=llm,
        slurm=slurm,
        platform=platform,
        clock=data.get("clock", "3.3ns"),
        top_function=data.get("top_function", "kernel_top"),
        max_fix_rounds=data.get("max_fix_rounds", 5),
        build_timeout=data.get("build_timeout", 300),
    )

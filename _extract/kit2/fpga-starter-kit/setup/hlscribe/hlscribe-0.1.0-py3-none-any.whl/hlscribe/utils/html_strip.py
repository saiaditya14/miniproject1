"""Strip HTML to plain text using stdlib html.parser."""

from __future__ import annotations

from html.parser import HTMLParser


class _HTMLTextExtractor(HTMLParser):
    """Extract plain text from HTML, skipping style/script blocks."""

    _SKIP_TAGS = frozenset(("style", "script", "svg"))
    _HEADING_TAGS = {"h1": "# ", "h2": "## ", "h3": "### ", "h4": "#### "}

    def __init__(self):
        super().__init__()
        self._parts: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs):
        if tag in self._SKIP_TAGS:
            self._skip_depth += 1
            return
        if self._skip_depth:
            return
        if tag in self._HEADING_TAGS:
            self._parts.append("\n" + self._HEADING_TAGS[tag])
        elif tag in ("p", "div", "li", "tr", "br"):
            self._parts.append("\n")

    def handle_endtag(self, tag: str):
        if tag in self._SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
            return
        if self._skip_depth:
            return
        if tag in self._HEADING_TAGS or tag in ("p", "div", "ul", "ol", "table"):
            self._parts.append("\n")

    def handle_data(self, data: str):
        if self._skip_depth:
            return
        self._parts.append(data)

    def get_text(self) -> str:
        return "".join(self._parts)


def strip_html(html: str) -> str:
    """Convert HTML to readable plain text.

    - Strips ``<style>`` and ``<script>`` blocks entirely.
    - Converts ``<h1>``–``<h4>`` to markdown-style headings.
    - Preserves ``<pre>``/``<code>`` content.
    - Collapses runs of 3+ blank lines into 2.
    """
    parser = _HTMLTextExtractor()
    parser.feed(html)
    text = parser.get_text()

    # Collapse excessive blank lines
    import re

    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

"""Parse Vitis HLS build logs into structured errors."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


@dataclass
class BuildError:
    """A single parsed build error."""

    kind: str  # "compilation", "linker", "simulation", "config"
    file: str  # source file name
    line: int  # line number (0 if unknown)
    message: str  # error message text


def parse_log(log_text: str) -> list[BuildError]:
    """Parse HLS log text into structured errors."""
    errors: list[BuildError] = []

    # Compilation: kernel.cpp:42:15: error: 'foo' was not declared
    for m in re.finditer(
        r"([^\s:]+\.(?:cpp|h|hpp)):(\d+):\d+:\s+error:\s+(.+)", log_text
    ):
        errors.append(
            BuildError(
                kind="compilation",
                file=m.group(1),
                line=int(m.group(2)),
                message=m.group(3).strip(),
            )
        )

    # Linker: undefined reference to `symbol`
    for m in re.finditer(
        r"(undefined reference to|multiple definition of)\s+[`'\"]([^'\"]+)['\"]",
        log_text,
    ):
        errors.append(
            BuildError(
                kind="linker",
                file="unknown",
                line=0,
                message=f"{m.group(1)} `{m.group(2)}`",
            )
        )

    # Simulation: assertion failures
    for m in re.finditer(
        r"([^\s:]+\.cpp):(\d+):\s+(?:Assertion|assert)\s+(.+)\s+failed",
        log_text,
    ):
        errors.append(
            BuildError(
                kind="simulation",
                file=m.group(1),
                line=int(m.group(2)),
                message=f"Assertion failed: {m.group(3).strip()}",
            )
        )

    # Simulation: signal crashes (SIGSEGV, SIGABRT, etc.)
    for m in re.finditer(
        r"(?:System received a signal named|received signal)\s+(SIG\w+)", log_text
    ):
        errors.append(
            BuildError(
                kind="simulation",
                file="testbench",
                line=0,
                message=f"Crash: {m.group(1)} — likely null pointer, out-of-bounds access, or uninitialized memory",
            )
        )

    # Simulation: COSIM framework errors (keep actionable ones, skip wrappers)
    # 212-360: "Aborting co-simulation: C TB simulation failed" — actionable
    # 212-320: "C TB testing failed" — actionable
    # 212-5, 212-4: generic "finished: FAIL" wrappers — skip
    for m in re.finditer(
        r"ERROR:\s*\[COSIM\s+212-(\d+)\]\s*(.+)", log_text
    ):
        code = m.group(1)
        if code in ("5", "4"):
            continue  # skip generic wrappers
        errors.append(
            BuildError(
                kind="simulation",
                file="testbench",
                line=0,
                message=f"[COSIM 212-{code}] {m.group(2).strip()}",
            )
        )

    # Simulation: TEST FAILED / ERROR: lines (non-COSIM)
    for m in re.finditer(r"(Test\s+FAILED|ERROR:|FAIL:)\s*(.+)", log_text):
        msg = m.group(2).strip()
        # Skip errors handled by dedicated parsers above, and framework noise
        if (
            not msg
            or re.match(r"\[COSIM\s+212-", msg)
            or re.match(r"\[HLS\s+", msg)
            or "received a signal named" in msg
            or "simulation failed for" in msg.lower()
            or msg.startswith("INFO:")
        ):
            continue
        errors.append(
            BuildError(kind="simulation", file="testbench", line=0, message=msg)
        )

    # Config: HLS 200-1912 config ini entry errors
    for m in re.finditer(
        r"ERROR:\s*\[HLS\s+200-1912\]\s*Problem with config ini entry\s+'([^']+)'\s+"
        r"from\s+([^\s(]+)\((\d+)\)",
        log_text,
    ):
        errors.append(
            BuildError(
                kind="config",
                file=m.group(2),
                line=int(m.group(3)),
                message=f"Problem with config ini entry: {m.group(1)}",
            )
        )

    # Config: HLS 200-101 set_directive errors
    for m in re.finditer(
        r"ERROR:\s*\[HLS\s+200-101\]\s*set_directive_(\w+):\s*(.+)", log_text
    ):
        errors.append(
            BuildError(
                kind="config",
                file="unknown",
                line=0,
                message=f"set_directive_{m.group(1)}: {m.group(2).strip()}",
            )
        )

    return errors


def parse_log_file(log_path: Path) -> list[BuildError]:
    """Read log file and parse it."""
    if not log_path.exists():
        return []
    return parse_log(log_path.read_text())


def format_errors(errors: list[BuildError]) -> str:
    """Format errors for LLM context injection."""
    if not errors:
        return "No errors found."

    sections: dict[str, list[str]] = {}
    for err in errors:
        sections.setdefault(err.kind, []).append(err)

    lines: list[str] = []

    for kind, kind_errors in sections.items():
        heading = {
            "compilation": "Compilation Errors",
            "linker": "Linker Errors",
            "simulation": "Simulation/Testbench Errors",
            "config": "Config File Errors",
        }.get(kind, kind.title() + " Errors")
        lines.append(f"## {heading}\n")

        for i, err in enumerate(kind_errors, 1):
            if err.line:
                lines.append(f"{i}. **{err.file}:{err.line}**")
            else:
                lines.append(f"{i}. **{err.file}**")
            lines.append(f"   {err.message}\n")

    return "\n".join(lines)

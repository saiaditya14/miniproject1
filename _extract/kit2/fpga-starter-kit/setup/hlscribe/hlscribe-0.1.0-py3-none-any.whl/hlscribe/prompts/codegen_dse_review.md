You are reviewing a DSE (Design Space Exploration) kernel that was created by
stripping micro-optimization pragmas from a working HLS kernel.

## Task
Review `kernel_dse.cpp` and `baseline_dse.cfg` for correctness:

1. **No micro-knobs left in code**: Verify kernel_dse.cpp has NO `#pragma HLS PIPELINE`,
   `UNROLL`, `ARRAY_PARTITION`, or `INLINE` (without OFF). These belong in the .cfg file.
2. **Structural pragmas intact**: Verify kernel_dse.cpp KEEPS all `INTERFACE`, `DATAFLOW`,
   `STREAM`, `DEPENDENCE`, `LOOP_TRIPCOUNT`, and `INLINE OFF` pragmas.
3. **cfg completeness**: Every stripped pragma has a matching `syn.directive.*` line in
   baseline_dse.cfg with correct scope (function/label) and parameters.
4. **Code unchanged**: No algorithmic logic was modified — only pragma lines were replaced
   with `// cfg:` comments.

## Output
Reply with ONLY one of:
- `PASS` — if everything is correct
- `ISSUES:` followed by a numbered list of problems found

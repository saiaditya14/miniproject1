Generate the HLS testbench (`kernel_tb.cpp`) for **{project_name}**.

## Kernel Code

{kernel_context}

## Interface Specification

{interface_context}

## Requirements

{requirements_context}

{imports_context}

## Test Plan

{testplan_context}

## Testbench Rules

The testbench is **software verification code** (NOT synthesizable). You may use STL, malloc, any standard C++ features.

### Structure

```cpp
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cassert>
// ... any standard headers

extern "C" void {top_function}(<parameters>);

// Pure C++ golden reference — same algorithm, no HLS pragmas
// Comment: explain what this reference implements and any simplifications
static void golden_reference(<parameters>) {
    // Software implementation
}

int main() {
    // 1. Allocate test data
    // 2. Initialize with diverse test patterns (edge cases + typical)
    // 3. Compute golden reference
    // 4. Call kernel ONCE (single invocation)
    // 5. Compare outputs with tolerance — print index, expected, actual, error for mismatches
    // 6. Print TEST PASSED or TEST FAILED
    // 7. Return 0 for pass, 1 for fail
}
```

### Critical Rules

1. **Single kernel call** — ONE call to `{top_function}()`. Multiple calls cause cosim heap corruption.
2. **Buffer size = kernel's m_axi depth** (≤ 16384 elements per port). The kernel's `depth=N` pragma and the testbench's buffer allocation MUST match exactly. If the kernel has `depth=16384`, allocate `malloc(16384 * sizeof(element))`. Mismatch causes cosim SIGSEGV.
3. **Golden reference** — pure C++ reference implementation for comparison.
4. **Tolerance** — use relative tolerance for floating-point (e.g., 1e-3 for float, 1e-6 for double).
5. **Composite test data** — include edge cases (zeros, max values, boundaries) alongside typical values in a single buffer.
6. **Match kernel interface exactly** — same parameter names, types, and order.

### Assertions and Error Reporting

- Use `assert()` to verify setup invariants (e.g., buffer sizes, allocation success).
- On mismatch, print detailed diagnostics BEFORE failing:
  ```cpp
  if (error > tolerance) {
      printf("MISMATCH at [%d][%d]: expected=%.6f actual=%.6f error=%.6f\n",
             row, col, expected, actual, error);
      mismatch_count++;
  }
  ```
- Print summary statistics: total comparisons, mismatches, max error, average error.
- Print `TEST PASSED` or `TEST FAILED (N mismatches out of M comparisons)`.

### Comments

- Comment the purpose of each test pattern (why this specific data tests a specific behavior).
- Comment the tolerance choice and why it's appropriate for this algorithm.
- Comment any non-obvious aspects of the golden reference implementation.

Provide the complete `kernel_tb.cpp` in a single ```cpp code block.

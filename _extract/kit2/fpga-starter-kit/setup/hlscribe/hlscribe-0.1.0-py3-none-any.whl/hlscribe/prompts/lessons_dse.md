# HLS DSE Lessons

Rules learned from running micro-DSE on 8 vision benchmarks (185 configs synthesized, Alveo U50, Vitis HLS 2025.1, 3.3ns clock). Apply these when generating DSE configuration variants.

## Anti-patterns (avoid these — they cause regressions)

### Never pipeline the outer row loop of a stencil kernel
Pipelining the outer (row) loop instead of the inner (column/pixel) loop causes **4x to 155x latency blowup**. Vitis HLS cannot efficiently flatten imperfect loop nests containing line-buffer shift operations. The tool serializes the inner iteration space instead of pipelining it.
```cfg
# BAD — causes 4x-155x latency explosion:
syn.directive.pipeline=process_pixel/PROC_ROW II=1

# GOOD — achieves II=1 correctly:
syn.directive.pipeline=process_pixel/PROC_COL II=1
```
Observed in: gaussian-filter (4x), box-blur (155x), median-filter (48x), unsharp-mask (14x), gaussian-difference (5x), harris-corner (4x).

### Never completely partition line buffers on the width dimension
Complete partitioning of `line_buf` along the column dimension converts BRAM into flip-flops. For image widths of 1920–3840, this creates tens of thousands of FFs per line buffer, causing csynth failure or impractical resource usage. Use cyclic factor=2–4 instead.
```cfg
# BAD — register explosion (156K FF for optical-flow):
syn.directive.array_partition=func variable=line_buf type=complete dim=2

# GOOD — extra BRAM ports without register blowup:
syn.directive.array_partition=func variable=line_buf type=cyclic factor=2 dim=2
```

### Do not use URAM or LUTRAM bind_storage for line buffers
URAM mapping fails because line-buffer shift-register access patterns violate URAM's single-port-per-address constraint. LUTRAM bind_storage is unreliable for arrays above a few hundred elements. Leave line buffers in default BRAM.
```cfg
# BAD — csynth fails:
syn.directive.bind_storage=func variable=line_buf type=ram_s2p impl=uram

# GOOD — let HLS auto-map to dual-port BRAM:
# (no directive needed)
```

## Trade-offs (Pareto-useful knobs)

### Inlining dataflow sub-functions reduces DSP at zero latency cost
Inlining allows the HLS scheduler to share multipliers across what were separate dataflow stages. This is the single most effective DSE knob for area reduction without latency penalty.
- gaussian-filter: DSP 7→5 (-29%), same latency
- gaussian-difference: DSP 5→3 (-40%), same latency
- harris-corner: DSP 36→30 (-17%), FF -7%, same latency
- canny-edge: DSP 12→10 (-17%), same latency

Start by inlining **stateless** stages (pure compute, no line buffers). Inlining stateful stages risks name collisions but often works.
```cfg
# Inline stateless compute stages, keep I/O and stateful stages separate
syn.directive.inline=tensor_product
syn.directive.inline=harris_response
```

### Relaxing pipeline II from 1 to 2 trades 2x latency for DSP/area savings
II=2 allows time-multiplexing of resources across two cycles. For multi-stage dataflow, selectively relax II on **compute-heavy stages only** (division, wide multiplication) while keeping I/O stages at II=1 for burst efficiency.
- box-blur: DSP 8→5 (-38%), latency 2x
- median-filter: DSP 7→4 (-43%), latency 2x
- optical-flow-lk: DSP 29→25 (-14%), latency 1.5x (only solve stage relaxed)
```cfg
syn.directive.pipeline=read_input/READ_LOOP II=1
syn.directive.pipeline=compute/HEAVY_LOOP II=2
syn.directive.pipeline=write_output/WRITE_LOOP II=1
```

## No-effect directives (skip these — HLS already handles them)

### Explicit unrolling of small fixed-trip loops is redundant
Loops with trip count ≤16 inside a pipelined region are automatically fully unrolled by Vitis HLS 2025.1. Adding explicit unroll directives produces **identical** synthesis results. Do not waste DSE configs on these.

### Explicit window array partitioning is redundant
Small local arrays (3×3, 5×5 windows) used inside pipelined loops are automatically promoted to registers. Explicit `array_partition type=complete` on window arrays has zero effect on synthesis.

### Stream depth tuning has no effect on synthesis resources
Changing `hls::stream` FIFO depths via config directives rarely affects synthesis results when the dataflow stages are balanced at the same II. The tool allocates minimal FIFOs regardless of the depth hint when stages match.

## Config generation guidance

When generating DSE configs, focus on **3 knobs that actually change synthesis outcomes**:

1. **Inline vs dataflow** — inline stateless sub-functions to share DSPs
2. **II target** — II=1 (max throughput) vs II=2 (area savings)
3. **Line buffer partitioning factor** — cyclic factor on row dimension only (dim=1)

**Skip** these — they produce configs identical to baseline:
- Small loop unrolling (auto-handled)
- Window array partitioning (auto-handled)
- Stream depth tuning (no effect)
- Burst parameter tuning (no effect for streaming stencil kernels)
- URAM/LUTRAM binding (fails)
- Outer loop pipelining (latency blowup)

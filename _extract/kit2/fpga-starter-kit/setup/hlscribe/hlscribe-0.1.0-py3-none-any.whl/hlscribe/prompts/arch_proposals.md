Generate exactly {num_proposals} diverse macro architecture proposals for the HLS project described below. Each proposal should take a fundamentally different approach to the design.

## Project: {project_name}

### Requirements
{requirements}

### Interface Specification
{interface_spec}

{hints_context}

## Proposal Focus Areas
{proposal_focuses}

---

## Instructions

For each proposal, provide:

### Proposal N: [Descriptive Name]

**Focus**: [One-line description of the optimization goal]

1. **Architecture Overview** — paradigm, design philosophy, top function signature
2. **Computational Pipeline** — stages with ASCII data-flow diagram
3. **Memory Architecture** — buffers table (name | type | depth | width | access pattern)
4. **Parallelization Strategy** — loop-level, task-level, compute units
5. **Resource & Performance Estimates** — resource table, latency, throughput, bottleneck
6. **Trade-offs** — what this design sacrifices for its focus
7. **DSE Dimensions** — tunable parameters with ranges specific to this proposal

---

After all proposals, provide:

## Comparison Table

| Aspect | Proposal 1 | Proposal 2 | ... |
|--------|-----------|-----------|-----|
| Paradigm | ... | ... | ... |
| Throughput | ... | ... | ... |
| Latency | ... | ... | ... |
| Resource usage | ... | ... | ... |
| Memory bandwidth | ... | ... | ... |
| DSE flexibility | ... | ... | ... |

## Recommendation

State which proposal is recommended as the starting point and why. Consider the requirements, target platform, and DSE potential.

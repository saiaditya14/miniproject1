Generate the HLS kernel (`kernel.cpp`) for **{project_name}**.

## Interface Specification

{interface_context}

## Requirements

{requirements_context}

## Architecture

{architecture_context}

{imports_context}

## Top Function

The kernel function name MUST be **`{top_function}`**.

## Instructions

1. Function name MUST be `{top_function}` — wrapped in `extern "C" {{ ... }}`.
2. Include ALL HLS INTERFACE pragmas from the interface spec above.
3. Implement the algorithm described in requirements and architecture.
4. Add `#pragma HLS LOOP_TRIPCOUNT` to every loop.
5. `m_axi depth=` must equal the testbench buffer size (typically ≤ 16384). Do NOT use MAX dimensions — depth controls cosim memory allocation and must match the testbench exactly.
6. For line buffers in pipelined loops, add `#pragma HLS DEPENDENCE variable=<buf> inter false` to enable II=1.
7. No dynamic memory, STL containers, or printf in kernel code.
8. Include `#include <cassert>` and add `assert()` calls for parameter validation and key invariants. **Also `#include <cstdint>` whenever the kernel uses `uint8_t` / `int8_t` / `int16_t` / `uint16_t` / `int32_t` / `uint32_t` / `int64_t` / `uint64_t` (the function signature typically does — csim picks it up transitively from the testbench but csynth does NOT, and missing this include causes synthesis to fail with `unknown type name 'uint8_t'`).
9. Add comments explaining WHY each design choice was made — algorithm rationale, pragma purposes, and trade-offs.
10. If imported components are provided above, `#include` their headers and call them
    as sub-functions within a `#pragma HLS DATAFLOW` region. Do NOT rewrite their
    internal logic — only write the new stages and the top-level wrapper.

## Output

Provide the complete `kernel.cpp` in a single ```cpp code block with:
- Algorithm summary comment at the top (3-5 lines)
- Section headers (`// ── Load ──`, `// ── Compute ──`, `// ── Store ──`)
- Comments after each pragma explaining its purpose
- `assert()` for parameter bounds and invariants
- Descriptive loop labels

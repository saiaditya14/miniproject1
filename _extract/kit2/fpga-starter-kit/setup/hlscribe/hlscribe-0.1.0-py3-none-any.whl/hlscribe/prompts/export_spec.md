# Generate Component Specification

Write a concise component specification for importing this HLS core into another
design via `hlscribe import-kernel`. This spec will be passed to the code generator
as context when composing the component into a DATAFLOW region.

## Core Header

```cpp
{core_header}
```

## Original Kernel Source (for reference)

```cpp
{kernel_code}
```

## Requirements

{requirements_context}

## Interface Specification

{interface_context}

## Output Format

Produce a markdown document (in a single `markdown` code block) with these sections:

```
# <Component Name>

<One-sentence summary of what this component does.>

## Stream Interface

| Parameter | Direction | Type | Description |
|-----------|-----------|------|-------------|
| ... | in/out | `hls::stream<T>&` | ... |

## Data Types

| Type | Definition | Bit Width |
|------|-----------|-----------|
| ... | ... | ... |

## Behavior

<2-3 sentences: algorithm, processing order, latency characteristics.>

## Usage Example

\`\`\`cpp
#include "{top_function}_core.h"

void top(hls::stream<T>& in, hls::stream<T>& out, ...) {{
    #pragma HLS DATAFLOW
    {top_function}_core(in, out, ...);
}}
\`\`\`
```

Keep it concise — this is a reference card, not full documentation.

Generate the XRT host code (`host.cpp`) for **{project_name}**.

## Kernel Code

{kernel_context}

## Interface Specification

{interface_context}

## Requirements

{requirements_context}

## Architecture

{architecture_context}

## Top Function

The kernel function name is **`{top_function}`**.

## Host Code Rules

This is **runtime management code** — completely different from the HLS kernel.
Use XRT (Xilinx Runtime) native API. Do NOT use OpenCL.

### XRT API Usage

```cpp
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>
```

- `xrt::device` — open the FPGA device (index 0)
- `xrt::uuid` — load the xclbin file
- `xrt::kernel` — instantiate kernel by name `"{top_function}"`
- `xrt::bo` — create buffer objects for each m_axi interface port
- `xrt::bo::map()` — get host pointer for data access
- `xrt::bo::sync(XCL_BO_SYNC_BO_TO_DEVICE)` — transfer host → device
- `xrt::bo::sync(XCL_BO_SYNC_BO_FROM_DEVICE)` — transfer device → host
- `xrt::run` — execute kernel, `run.wait()` to block until complete

### Structure

```cpp
#include <iostream>
#include <cstdlib>
#include <chrono>
#include <xrt/xrt_bo.h>
#include <xrt/xrt_device.h>
#include <xrt/xrt_kernel.h>

int main(int argc, char* argv[]) {
    // 1. Parse argv[1] as xclbin path
    // 2. Open device, load xclbin
    // 3. Create kernel object with name "{top_function}"
    // 4. Create buffer objects (BOs) for each m_axi port
    // 5. Map BOs, initialize input data
    // 6. Sync input BOs to device
    // 7. Execute kernel, measure time
    // 8. Sync output BOs from device
    // 9. Validate results against golden reference
    // 10. Print results and timing
    // 11. Return 0 for pass, 1 for fail
}
```

### Critical Rules

1. **argv[1] = xclbin path** — print usage if missing.
2. **One BO per m_axi bundle** — match the kernel interface exactly.
3. **Golden reference** — compute expected output in software and compare.
4. **Timing** — measure kernel execution with `std::chrono::high_resolution_clock`.
5. **Error handling** — check device open, xclbin load, kernel creation; print clear messages on failure.
6. **No HLS pragmas or headers** — this is pure host-side C++.
7. **Resource cleanup** — XRT objects use RAII, so scope-based cleanup is sufficient.

## Output

Provide the complete `host.cpp` in a single ```cpp code block.

# Generate Stream-Refactored Core Component

Refactor the HLS kernel below into a **stream-based core component** suitable for
composition inside a DATAFLOW region. The goal is to strip the m_axi Load/Store
wrappers and expose only the computational core with `hls::stream` I/O.

## Refactoring Rules

1. **Strip** all `// ── Load ──` and `// ── Store ──` sections (m_axi burst read/write wrappers)
2. **Keep** all `// ── Compute ──` stages, line buffers, internal streams, and DATAFLOW pragmas
3. **Replace** the `extern "C" void {top_function}(...)` signature with:
   `void {top_function}_core(hls::stream<T>& in_stream, hls::stream<T>& out_stream, ...)`
   - Replace m_axi pointer parameters with `hls::stream<T>&` parameters
   - Keep scalar parameters (dimensions, thresholds, etc.)
4. **Remove**: `extern "C"`, `#pragma HLS INTERFACE m_axi`, `#pragma HLS INTERFACE s_axilite`
5. **Keep**: all `PIPELINE`, `UNROLL`, `ARRAY_PARTITION`, `DATAFLOW` pragmas, all internal sub-functions, all typedefs/constants
6. If the kernel has multiple compute stages connected by internal streams, keep them all

## Interface Specification

{interface_context}

## Architecture

{architecture_context}

## Original Kernel Source

```cpp
{kernel_code}
```

Produce exactly **TWO** `cpp` code blocks in this order:

1. **`{top_function}_core.h`** — Header with `#pragma once`, types/constants, and the stream-based function prototype(s)
2. **`{top_function}_core.cpp`** — Implementation with `#include "{top_function}_core.h"`, the computational core, and all internal helpers

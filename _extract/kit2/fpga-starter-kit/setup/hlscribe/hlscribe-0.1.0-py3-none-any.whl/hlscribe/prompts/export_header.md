# Generate Standalone Header

Generate a standalone C/C++ header file (`kernel.h`) for the HLS kernel below.

## Requirements

- Start with `#pragma once`
- Include only the HLS headers the kernel actually uses (e.g., `<hls_stream.h>`, `<ap_int.h>`)
- Copy all `typedef`, `#define`, `constexpr`, and `enum` declarations from the source
- Declare the top-level function with `extern "C"` linkage
- Declare any **public** sub-function prototypes (not `static` or anonymous-namespace helpers)
- Do **NOT** include function bodies
- Do **NOT** include HLS pragmas
- Add a brief Doxygen-style comment for the top function

## Interface Specification

{interface_context}

## Kernel Source

```cpp
{kernel_code}
```

Produce exactly ONE `cpp` code block containing the complete header file.

Generate the DSE kernel (`kernel_dse.cpp`) for **{project_name}**.

This kernel follows the **macro architecture** but leaves micro-optimization knobs for external `.cfg` files.

## Interface Specification

{interface_context}

## Requirements

{requirements_context}

## Architecture

{architecture_context}

{imports_context}

## Top Function

The kernel function name MUST be **`{top_function}`**.

## DSE Kernel Rules

1. Function name MUST be `{top_function}` — wrapped in `extern "C" {{ ... }}`.
2. Include ALL HLS INTERFACE pragmas from the interface spec above.
3. Implement the algorithm described in requirements and architecture.
4. Add `#pragma HLS LOOP_TRIPCOUNT` to every loop.
5. `m_axi depth=` must equal the testbench buffer size (typically ≤ 16384).
6. For line buffers in pipelined loops, add `#pragma HLS DEPENDENCE variable=<buf> inter false`.
7. No dynamic memory, STL containers, or printf in kernel code.
8. Include `#include <cassert>` and add `assert()` calls for parameter validation.
9. Add comments explaining WHY each design choice was made.
10. If imported components are provided above, `#include` their headers and call them as sub-functions.

### INCLUDE in kernel_dse.cpp (macro architecture — structural):
- ALL HLS INTERFACE pragmas (`m_axi`, `s_axilite`, `axis`)
- `#pragma HLS DATAFLOW` (architectural choice from arch spec)
- `#pragma HLS STREAM variable=... depth=N` (structural, enables DATAFLOW)
- `#pragma HLS DEPENDENCE` (data dependency hints)
- `#pragma HLS LOOP_TRIPCOUNT` on ALL loops

### EXCLUDE from kernel_dse.cpp (micro knobs — swept via .cfg):
- **NO** `#pragma HLS PIPELINE` — II is a tuning knob
- **NO** `#pragma HLS UNROLL` — factor is a tuning knob
- **NO** `#pragma HLS ARRAY_PARTITION` — type/factor are tuning knobs
- **NO** `#pragma HLS INLINE` — inlining is a tuning choice

### Loop Labeling (REQUIRED for all loops):
Every loop MUST have a descriptive label so `.cfg` directives can target it:
```cpp
load_data: for (int i = 0; i < n; i++) {{
    // cfg: syn.directive.pipeline=kernel_top/load_data II=1
    ...
}}
compute_outer: for (int i = 0; i < rows; i++) {{
    compute_inner: for (int j = 0; j < cols; j++) {{
        // cfg: syn.directive.pipeline=kernel_top/compute_inner II=1
        // cfg: syn.directive.unroll=kernel_top/compute_inner factor=4
        ...
    }}
}}
```

The `// cfg:` comments are hints showing which `.cfg` directives will target each loop. They are NOT pragmas — do not include the actual pragma.

## Output

Provide the complete `kernel_dse.cpp` in a single ```cpp code block with:
- Algorithm summary comment at the top (3-5 lines)
- Section headers (`// ── Load ──`, `// ── Compute ──`, `// ── Store ──`)
- `// cfg:` hint comments showing which directives will target each loop/array
- `assert()` for parameter bounds and invariants
- **Named labels on ALL loops** — this is critical for DSE directive targeting

You are an expert HLS (High-Level Synthesis) engineer reviewing fix-loop discoveries to update a shared lessons file.

## Current lessons.md

{current_lessons}

## New discoveries from fix-loop sessions

{new_discoveries}

## Your task

Review the new discoveries above and propose additions to lessons.md. Follow these rules:

1. **Deduplicate**: Skip discoveries that duplicate or are already covered by existing rules.
2. **Generalize**: Convert project-specific fixes into universal rules. Replace specific variable names, function names, and file names with generic descriptions.
3. **Categorize**: Place new rules under existing sections (Compilation, Simulation, Synthesis, Cosim, Architecture, Config) or create a new section if needed.
4. **Format**: Match the existing lessons.md style:
   - `### Rule title` (imperative, concise)
   - 1–3 sentence explanation of the rule
   - Optional code example with WRONG / CORRECT pattern
5. **Be selective**: Only graduate discoveries that represent a **reusable pattern** — not one-off typos or project-specific bugs.

## Output format

Return ONLY the new rules to append, inside a markdown fence:

```markdown
### Rule title here
Explanation of the rule.

### Another rule
Another explanation.
```

If no new rules should be added (all duplicates or too specific), return:

```markdown
_No new lessons to add._
```

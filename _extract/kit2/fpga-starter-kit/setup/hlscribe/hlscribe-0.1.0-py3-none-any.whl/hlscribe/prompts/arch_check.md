Review the following HLS kernel code for alignment with the intended architecture.

## Architecture Specification

{architecture_context}

## Current Kernel Code

```cpp
{kernel_code}
```

## Instructions

Compare the kernel implementation against the architecture spec. Evaluate:

1. **Structural alignment** — Does the code follow the described pipeline stages, data flow, and module organization?
2. **Optimization alignment** — Are the pragmas and optimization strategies consistent with the architecture's intent?
3. **Interface alignment** — Do the function signatures and data access patterns match the spec?

Provide:
- A one-line **verdict**: ALIGNED, MINOR DRIFT, or SIGNIFICANT DRIFT
- A brief summary (3-5 bullet points) of what matches and what diverges
- If drift exists, specific suggestions to realign

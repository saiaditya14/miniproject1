Fix the HLS configuration file **{config_file}** based on the build errors below.

## Current Config

```ini
{config_content}
```

## Build Errors

{error_report}

{lesson_context}

## Kernel Source (for reference)

```cpp
{kernel_code}
```

## Fix Rules

1. **MINIMAL CHANGES** — only fix directives that are causing errors. Do not add new optimizations.
2. **VALID SCOPE PATHS** — directive scopes must match the kernel's actual function/loop/array names.
   - Top function scope: `{top_function}`
   - Use loop labels and array names exactly as they appear in the kernel source.
3. **VALID SYNTAX** — follow Vitis HLS `.cfg` format:
   - `syn.directive.pipeline=<scope> II=<N>`
   - `syn.directive.unroll=<scope> factor=<N>`
   - `syn.directive.array_partition=<scope> variable=<name> type=<type> factor=<N>`
4. **COMPLETE FILE** — output the entire corrected config file, not a diff or partial snippet.
5. **PRESERVE HEADER** — keep the `part=`, `[hls]`, `flow_target=`, `clock_period=`, and `syn.top=` lines unchanged.
6. **EXPLAIN FIXES** — briefly state what was wrong and how you fixed it before the config block.

### Common Config Errors

- **Invalid scope**: directive references a loop label or function that doesn't exist in the kernel.
- **Syntax error**: wrong directive format (missing `=`, wrong key names).
- **Type mismatch**: `array_partition type=` must be `cyclic`, `block`, or `complete`.
- **Missing variable**: `array_partition` must specify `variable=<name>` that exists in the scope.

Provide the corrected config in a single ```ini code block.

# HLS Codegen Lessons

Rules learned from building 19+ HLS benchmarks. Apply these proactively during code generation to avoid common failures.

## Compilation

### Never assert on signed accumulators
Only assert on input parameter ranges and structural invariants (array sizes, loop bounds). Never assert on computed values from signed arithmetic — signed accumulators (`int`, `ap_int`) legitimately produce negative intermediate values.
```cpp
// WRONG:
int acc = 0;
for (...) acc += data[i];
assert(acc >= 0);  // fails for negative intermediate values

// CORRECT:
assert(size > 0 && size <= MAX_SIZE);  // input parameter range — OK
```

### Never assert on pointer parameters
`assert(ptr != nullptr)` on function parameters crashes the Vitis HLS synthesizer. Port addresses are not regular pointers; comparing them to nullptr triggers an ICmpInst crash in HLS IR generation. Only assert on scalar value ranges.

### Always include `<cstdint>` when using fixed-width integer types
The kernel.cpp is synthesized with a stricter compiler than csim uses. csim picks up `uint8_t`, `int8_t`, `int16_t`, `uint16_t`, `int32_t`, `uint32_t`, `int64_t`, `uint64_t` transitively from headers the testbench pulls in, but csynth does NOT. **Every kernel file that uses any of these types must `#include <cstdint>` (or `<stdint.h>`) directly.** Symptom of the bug: csim passes, csynth fails with `unknown type name 'uint8_t'`. The kernel function signature typically uses these types (e.g., `uint8_t* img_inp`) so this almost always applies.

```cpp
#include <cstdint>     // REQUIRED when kernel uses uint8_t / int16_t / etc.
#include <ap_int.h>
#include <hls_stream.h>

extern "C" void my_kernel(uint8_t* img_inp, int16_t* flow_u, int rows, int cols) {
  // ...
}
```

### Always include `<algorithm>` for std::min/std::max
Vitis HLS clang does not provide unqualified `min()`/`max()`. Always use `std::min()`/`std::max()` with `#include <algorithm>`.

### Define all constants in the kernel file
Never reference undefined macros or variables. HLS kernels are self-contained compilation units — all constants must be `#define`d or declared `const` in the kernel file itself.

### extern "C" cannot return HLS types
Functions declared `extern "C"` must NOT return C++ class types like `ap_fixed<W,I>` or `ap_int<N>`. Either return `void` and pass output via pointer/reference, or omit `extern "C"`.

### Testbench linkage must match kernel
If the kernel uses `extern "C"`, the testbench declaration must also use `extern "C"`. Mismatched linkage causes linker errors due to C++ name mangling vs C symbol names.

## Simulation

### Use `val % 2 != 0` for odd number tests
`val % 2 == 1` returns false for negative odd numbers in C/C++ (e.g., `-5 % 2 == -1`, not `1`). Always use `val % 2 != 0`.

### hls::task needs blocking reads with exact counts
In `hls::task` csim, `while(!out.empty())` does not work — the csim scheduler doesn't guarantee all tasks complete before the top function returns. Use blocking reads with exact counts:
```cpp
// WRONG:
while (!out1.empty()) sum1 += out1.read();

// CORRECT:
for (int i = 0; i < N/2; i++) sum1 += out1.read();
```

### Struct alignment must match between kernel and testbench
If the kernel defines `struct alignas(32) A { ... }`, the testbench must use the identical struct definition (copy verbatim). Mismatched struct sizes cause buffer overflow and memory corruption during cosim.

### Non-deterministic routing requires data conservation verification
`hls::split::load_balance` routes data non-deterministically. The golden reference must NOT assume a specific distribution pattern. Instead, collect all outputs, sort, and compare against sorted inputs.

### Single kernel call in testbench
Use ONE call to the top function in the testbench. Multiple kernel calls cause cosim heap corruption. Pack diverse test patterns (edge cases, boundaries, typical values) into a single buffer.

## Synthesis

### Do not specify bundle= on s_axilite in Vitis mode
In Vitis kernel mode, m_axi ports auto-generate s_axilite offset ports with bundle name `control_r`. Explicitly setting `bundle=control` conflicts (HLS 214-219). Omit `bundle=` from all s_axilite pragmas.

### Vivado IP interfaces fail in Vitis mode
Interfaces like `ap_memory`, `ap_vld`, `ap_fifo`, and `ap_ctrl_hs` are Vivado IP mode interfaces. Using them with `flow_target=vitis` causes pre-synthesis failure. For Vitis mode, use only `m_axi`, `axis`, `s_axilite`.

### DATAFLOW canonical form
A `#pragma HLS DATAFLOW` region allows only variable declarations and function calls. No inline loops, no if-statements, no assignments. Extract all loops into separate functions with `#pragma HLS INLINE OFF`.
```cpp
// WRONG:
void top(...) {
    #pragma HLS DATAFLOW
    for (int i = 0; i < N; i++) B[i] = A[i] + i;  // inline loop
    process(strm, strm_out);
}

// CORRECT:
void transform(data_t A[N], data_t B[N]) {
    #pragma HLS INLINE OFF
    for (int i = 0; i < N; i++) B[i] = A[i] + i;
}
void top(...) {
    #pragma HLS DATAFLOW
    transform(A, B);
    process(strm, strm_out);
}
```

## Cosim

### m_axi depth must match testbench buffer size
The kernel's `depth=N` in the m_axi INTERFACE pragma tells cosim how much memory to allocate. It MUST be a literal integer equal to the testbench buffer size (typically <= 16384). Never use expressions like `MAX_WIDTH*MAX_HEIGHT`. Mismatch causes SIGSEGV.

### All pointer parameters need depth= for cosim
Even scalar pointer outputs (e.g., `int* result`) need `#pragma HLS INTERFACE m_axi port=result depth=1`. Without it, cosim aborts with "depth specification required."

### Always set hls::stream depth explicitly
`hls::stream` defaults to depth=2. If a producer writes faster than the consumer reads, the FIFO overflows causing SIGSEGV or deadlock during cosim. Always set depth with `#pragma HLS STREAM variable=<var> depth=<N>`. Size depth to the maximum number of elements in-flight (e.g., image width for line-level streams).

## Architecture

### Use array_stencil for 2D stencil operations — ONLY with compile-time-constant dimensions
Per UG1399 (Vitis HLS User Guide v2025.2, page 552), 2D `ARRAY_STENCIL` has strict canonical-form requirements:
- **Loop bounds need to be constant for multi-dimensional stencil patterns**
- Stencil optimization can only be applied to the top level
- Must be inside a perfect nested loop with PIPELINE II=1
- Pragma must be located within the loop

**This rules out 2D ARRAY_STENCIL for parametric image dimensions** (`int rows`, `int cols` arguments). Verified by inspecting `Vitis-HLS-Introductory-Examples/Modeling/using_array_stencil_2d/filter2d_hw.cpp` — the canonical example hardcodes `for(y=0; y<30; y++)` and `for(x=0; x<1000; x++)`, not parametric loops.

**For parametric streaming stencils, use a manual line-buffer + sliding-window pattern instead.**

When dimensions ARE compile-time constant (e.g., specialized fixed-size kernel), ARRAY_STENCIL is good:
```cpp
ROW_LOOP: for (int y = 0; y < HEIGHT; y++) {        // HEIGHT must be constant
    COL_LOOP: for (int x = 0; x < WIDTH; x++) {     // WIDTH must be constant
        #pragma HLS PIPELINE II=1
        #pragma HLS array_stencil variable=src
        // Direct 2D read — pragma auto-creates line buffers
        pixel = src[y + row][x + col];
    }
}
```

### Line buffer DEPENDENCE pragma for II=1
When using manual line buffers in a pipelined loop, add `#pragma HLS DEPENDENCE variable=line_buf inter false`. Without this, HLS conservatively assumes inter-iteration dependencies and fails to achieve II=1.

### Line buffer ARRAY_PARTITION: use dim=1, NOT dim=0
For a stencil line buffer `T line_buf[NROWS][MAX_WIDTH]`:

```cpp
// WRONG — partitions BOTH dimensions completely.
// For [2][3840], this creates 7680 individual registers/LUTs.
// Synthesis search space explodes; csynth can run for an hour+
// trying to schedule that many simultaneous storage elements.
#pragma HLS ARRAY_PARTITION variable=line_buf complete dim=0

// CORRECT — partitions only the rows dimension.
// Creates NROWS independent BRAM-backed arrays, each of MAX_WIDTH
// elements. Row-parallel access (what the stencil needs); column
// access is sequential through BRAM, which is fine for II=1
// when paired with DEPENDENCE inter false.
#pragma HLS ARRAY_PARTITION variable=line_buf complete dim=1
```

**Rule:** for any 2D buffer `[ROWS][WIDTH]` where `WIDTH` is large (> ~64),
partition only the small dimension. `dim=0 complete` on wide arrays is
nearly always a bug.

## Config

### syn.top must match actual function name
Verify `syn.top` in the .cfg file matches the actual `extern "C"` function name in the kernel source. Template defaults often use `kernel` or `kernel_top` which may not match.

### hls::task output streams need explicit depth
In `hls::task` designs, output streams default to depth=2 which causes deadlock. Set depth >= expected element count on ALL streams, including output streams passed to the top function.

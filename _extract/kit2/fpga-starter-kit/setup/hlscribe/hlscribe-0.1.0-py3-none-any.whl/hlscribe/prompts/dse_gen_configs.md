Generate **{num_configs}** HLS configuration variants for the **{project_name}** kernel.

## Working Kernel Code

The following kernel compiles and passes C simulation. It contains inline pragmas that represent the current baseline optimization. Your configs should explore alternatives to (and variations of) these inline pragmas.

```cpp
{kernel_code}
```

## Constraint Space

{constraint_space}

## Project Context

### Requirements
{requirements_context}

### Architecture
{architecture_context}

### Interface
{interface_context}

## Vitis HLS Directive Syntax Reference

Each directive must be a single line in `syn.directive.<type>=<scope> [params]` format:

```
# Pipeline a loop with initiation interval
syn.directive.pipeline=<top_func>/<loop_label> II=<n>

# Unroll a loop by factor (omit factor for full unroll)
syn.directive.unroll=<top_func>/<loop_label> factor=<n>

# Partition a local array (cyclic, block, or complete)
syn.directive.array_partition=<top_func> variable=<array_name> type=cyclic factor=<n>
syn.directive.array_partition=<top_func> variable=<array_name> type=complete dim=<d>

# Enable dataflow (task-level pipelining between functions/loops)
syn.directive.dataflow=<top_func>

# Inline a sub-function (or disable with "off")
syn.directive.inline=<sub_func>
```

**Important**:
- `<scope>` must use exact function/label names from the kernel code above.
- For nested loops: `<top_func>/<outer_label>/<inner_label>`.
- Array partition `variable=` must match exact array names in the code.
- `factor=` values should divide the array dimension or loop trip count evenly.

## Output Format

For EACH configuration, provide:

1. A `###` heading with a short descriptive name
2. A `**Strategy**:` line (conservative, moderate, or aggressive)
3. A `**Rationale**:` line explaining the optimization trade-off
4. A ```` ```cfg ```` block with the directives

### Example format:

### opt1: Baseline pipelining
**Strategy**: conservative
**Rationale**: Pipeline the innermost loops at II=1. Low resource cost, predictable latency improvement.

```cfg
syn.directive.pipeline={top_function}/inner_loop II=1
```

### opt2: Moderate unroll + partition
**Strategy**: moderate
**Rationale**: Unroll inner loop 4x with matching array partition to increase throughput by ~4x while keeping resource usage manageable.

```cfg
syn.directive.pipeline={top_function}/outer_loop II=1
syn.directive.unroll={top_function}/inner_loop factor=4
syn.directive.array_partition={top_function} variable=local_buf type=cyclic factor=4
```

## DSE Lessons (from prior synthesis campaigns)

{dse_lessons}

## Instructions

1. Generate exactly **{num_configs}** configurations.
2. Progress from conservative → moderate → aggressive.
3. Each config should explore a **distinct optimization strategy** — not just parameter tweaks.
4. Consider trade-offs: latency vs throughput vs resource usage.
5. For unroll directives, match with proportional array partitioning.
6. Use the tunable knobs and suggested value ranges from the constraint space above.
7. Keep directive scopes consistent with the kernel code identifiers.
8. **Respect the DSE lessons above** — do not generate configs that use known anti-patterns (outer-loop pipelining, complete line-buffer partitioning, URAM/LUTRAM binding). Do not waste configs on no-effect directives (small-loop unrolling, window partitioning, stream depth tuning).

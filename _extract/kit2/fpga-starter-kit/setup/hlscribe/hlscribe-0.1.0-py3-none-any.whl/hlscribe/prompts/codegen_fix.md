Fix **{file_name}** based on the build errors below.

## Architecture (reference — do not deviate)

{architecture_context}

## Current Code

```cpp
{existing_code}
```

## Build Errors

{error_report}

{lesson_context}

## Fix Rules

1. **MINIMAL CHANGES** — only fix what is broken. Do not refactor or restructure.
2. **PRESERVE INTERFACE** — keep the exact function signature, parameter names, types, and HLS INTERFACE pragmas.
3. **COMPLETE FILE** — output the entire corrected file, not a diff or partial snippet.
4. **EXPLAIN FIXES** — briefly state what was wrong and how you fixed it before the code block.

### Common Fix Patterns

**Compilation errors**: missing includes, type mismatches, undeclared identifiers, pragma syntax.
**Simulation errors**: logic bugs, off-by-one, incorrect boundary conditions, wrong golden reference.
**Cosim SIGSEGV at ENTER_WRAPC**: caused by `m_axi depth` exceeding the testbench buffer allocation. The cosim wrapper copies `depth` elements from the testbench buffer — if depth > buffer size, it reads past the allocation. Fix: set `depth=` to exactly match the testbench's `malloc`/array size. Check BOTH `img_inp` and `img_out` ports. **After changing depth, csynth must be re-run before cosim** (the wrapper is generated during csynth).
**Cosim SIGSEGV/deadlock (streams)**: caused by `hls::stream` depth overflow. The default depth is 2 — if the producer writes more than 2 elements before the consumer reads, the FIFO overflows. Fix by adding `#pragma HLS STREAM variable=<var> depth=<N>` where N accommodates worst-case in-flight elements. For FIFOs between dataflow stages, depth = one full row of data.
**Cosim debugging**: add `cosim.trace_level=all` to the .cfg file to generate VCD waveform traces for diagnosis.
**Config errors**: invalid directive syntax, wrong scope paths, missing variables.

Provide the corrected `{file_name}` in a single ```cpp code block.

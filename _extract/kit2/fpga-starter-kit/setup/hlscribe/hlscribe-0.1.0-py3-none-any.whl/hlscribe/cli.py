"""CLI entry point — thin wrappers over workflow functions."""

from __future__ import annotations

import re
from pathlib import Path

import click
from rich.console import Console

from hlscribe import __version__

console = Console()


def _init_usage_log(target) -> None:
    """Configure the usage log sink for an LLM-using command.

    Accepts a Design (logs to <design>/artifacts/llm_usage.jsonl) or a
    Project (logs to <project>/.hlscribe/llm_usage.jsonl). Also seeds
    the cost-table search with the project root so a shared
    llm_costs.yaml in the bench/project dir is picked up.
    """
    from hlscribe import usage
    from hlscribe.project import Design, Project

    if isinstance(target, Design):
        usage.set_log_path(target.artifacts_dir / "llm_usage.jsonl")
        usage.set_project_root(target.project.root)
    elif isinstance(target, Project):
        usage.set_log_path(target.hlscribe_dir / "llm_usage.jsonl")
        usage.set_project_root(target.root)


@click.group()
@click.version_option(__version__, prog_name="hlscribe")
def cli():
    """hlscribe — AI-powered HLS development tool."""


@cli.command("init-project")
@click.argument("name")
@click.option("-d", "--description", default="", help="Project description.")
@click.option("--platform", default=None, help="FPGA platform key (e.g. u50, u280).")
@click.option("--clock", default="3.3ns", help="Clock period.")
@click.option("--top", "top_function", default="kernel_top", help="Top function name.")
def init_project_cmd(name, description, platform, clock, top_function):
    """Create a new HLS project (root with specs + config)."""
    from hlscribe.platforms import get_platform

    # Interactive platform selection if not specified
    if platform is None:
        platform_obj = _select_platform()
    else:
        platform_obj = get_platform(platform)
        if platform_obj is None:
            console.print(f"[red]Unknown platform: {platform}[/red]")
            raise SystemExit(1)

    from hlscribe.workflows.init_project import init_project

    try:
        project = init_project(
            parent=Path.cwd(),
            name=name,
            description=description,
            platform=platform_obj,
            clock=clock,
            top_function=top_function,
        )
    except FileExistsError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    console.print(f"\n[green]Created project:[/green] {project.root}")
    console.print(f"  Platform: {platform_obj.name} ({platform_obj.device})")
    console.print(f"  Clock:    {clock}")

    # Next-steps guidance
    console.print(f"\n[bold]Next steps:[/bold]")
    console.print(f"  1. Add your API key to [cyan]~/.hlscribe/.env[/cyan] (if not already done):")
    console.print(f"     [dim]mkdir -p ~/.hlscribe && nano ~/.hlscribe/.env[/dim]")
    console.print()
    console.print(f"     [dim]# Anthropic (default provider)[/dim]")
    console.print(f"     [dim]ANTHROPIC_API_KEY=sk-ant-your-key-here[/dim]")
    console.print(f"     [dim]# OpenRouter[/dim]")
    console.print(f"     [dim]OPENROUTER_API_KEY=sk-or-your-key-here[/dim]")
    console.print(f"     [dim]# OpenAI[/dim]")
    console.print(f"     [dim]OPENAI_API_KEY=sk-your-key-here[/dim]")
    console.print()
    console.print(f"  2. Edit [cyan]{name}/hlscribe.yaml[/cyan] to set top_function, provider, model, etc.")
    console.print(f"     [dim]top_function defaults to kernel_top — change it to your kernel name[/dim]")
    console.print(f"  3. Verify your setup:")
    console.print(f"     [dim]cd {name} && hlscribe check-config[/dim]")
    console.print(f"  4. (Optional) Configure Slurm cluster for remote builds:")
    console.print(f"     [dim]nano ~/.hlscribe/config.yaml[/dim]")
    console.print()
    console.print(f"     [dim]slurm:[/dim]")
    console.print(f"     [dim]  host: your-cluster-host[/dim]")
    console.print(f"     [dim]  user: your-username[/dim]")
    console.print(f"     [dim]  partition: batch[/dim]")
    console.print()
    console.print(f"  5. Create a design variant:")
    console.print(f"     [dim]hlscribe init-design baseline[/dim]")


@cli.command("init-design")
@click.argument("name")
@click.option("--arch", type=click.Path(exists=True, path_type=Path), default=None,
              help="Seed with an architecture file (copied to design specs/).")
def init_design_cmd(name, arch):
    """Create a design variant inside the current project."""
    from hlscribe.project import Project
    from hlscribe.workflows.init_project import init_design
    from hlscribe.config import load_config

    # Must be inside a project (search current dir and parents)
    try:
        project = Project.find(Path.cwd())
    except FileNotFoundError:
        console.print("[red]Not inside an hlscribe project (no hlscribe.yaml found).[/red]")
        console.print("[dim]Run this from a project or design directory created by 'hlscribe init-project'.[/dim]")
        raise SystemExit(1)

    # Read platform/clock/top from hlscribe.yaml
    cfg = load_config(project_dir=project.root)
    platform = cfg.platform
    if platform is None:
        from hlscribe.platforms import get_platform
        platform = get_platform("u50")

    try:
        design = init_design(
            project=project,
            name=name,
            platform=platform,
            clock=cfg.clock,
            top_function=cfg.top_function,
        )
    except FileExistsError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    # Copy architecture file into design if provided
    if arch:
        import shutil
        design.specs_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(arch, design.architecture_file)
        console.print(f"\n[green]Created design variant:[/green] {design.root}")
        console.print(f"  Project:      {project.name}")
        console.print(f"  Platform:     {platform.name} ({platform.device})")
        console.print(f"  Architecture: [cyan]{arch.name}[/cyan] → {design.architecture_file.relative_to(project.root)}")
    else:
        console.print(f"\n[green]Created design variant:[/green] {design.root}")
        console.print(f"  Project:  {project.name}")
        console.print(f"  Platform: {platform.name} ({platform.device})")

    console.print()
    console.print(f"  [bold]Next steps:[/bold]")
    console.print(f"    [dim]cd {name}[/dim]")
    if not arch:
        console.print(f"    [dim]hlscribe arch[/dim]                  [dim]# design architecture[/dim]")
    else:
        console.print(f"    [dim]hlscribe arch[/dim]                  [dim]# refine seeded architecture[/dim]")
    console.print(f"    [dim]hlscribe codegen[/dim]               [dim]# generate kernel + testbench[/dim]")
    console.print(f"    [dim]hlscribe build csim[/dim]            [dim]# build & test[/dim]")
    console.print(f"    [dim]hlscribe codegen --fix-loop[/dim]    [dim]# auto-fix errors[/dim]")


@cli.command("check-config")
def check_config_cmd():
    """Verify API key and provider configuration."""
    from hlscribe.config import load_config

    project_dir = Path.cwd()
    console.print("[bold]Checking configuration...[/bold]\n")

    # Load config
    try:
        cfg = load_config(project_dir=project_dir)
    except SystemExit as e:
        console.print(f"[red]Config error: {e}[/red]")
        raise

    console.print(f"  Provider: [cyan]{cfg.llm.provider}[/cyan]")
    console.print(f"  Model:    [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"  API base: [dim]{cfg.llm.api_base}[/dim]")
    console.print(f"  API key:  [dim]{cfg.llm.api_key[:8]}...{cfg.llm.api_key[-4:]}[/dim]")

    if cfg.platform:
        console.print(f"  Platform: [cyan]{cfg.platform.name}[/cyan] ({cfg.platform.device})")
    console.print(f"  Clock:    {cfg.clock}")
    console.print(f"  Top fn:   {cfg.top_function}")

    # Slurm config
    if cfg.slurm.enabled:
        console.print(f"\n  [bold]Slurm:[/bold]")
        console.print(f"    Host:      [cyan]{cfg.slurm.ssh_target}[/cyan]")
        console.print(f"    Partition: {cfg.slurm.partition}")
        console.print(f"    Nodes:     {cfg.slurm.nodes}")
        console.print(f"    CPUs:      {cfg.slurm.cpus}")
        console.print(f"    Memory:    {cfg.slurm.mem}")
        console.print(f"    Time:      {cfg.slurm.time}")
    else:
        console.print(f"\n  Slurm:    [dim]not configured[/dim]")
        console.print(f"            [dim]Add slurm settings to ~/.hlscribe/config.yaml[/dim]")

    # Test API connectivity
    console.print(f"\n  Testing API connection...")
    try:
        if cfg.llm.provider == "anthropic":
            import anthropic
            client = anthropic.Anthropic(api_key=cfg.llm.api_key)
            response = client.messages.create(
                model=cfg.llm.model,
                max_tokens=16,
                messages=[{"role": "user", "content": "Say OK"}],
            )
            console.print(f"  [green]API connection successful[/green] (model: {response.model})")
        elif cfg.llm.provider in ("openrouter", "openai"):
            import openai
            client = openai.OpenAI(
                api_key=cfg.llm.api_key,
                base_url=cfg.llm.api_base,
            )
            response = client.chat.completions.create(
                model=cfg.llm.model,
                max_tokens=16,
                messages=[{"role": "user", "content": "Say OK"}],
            )
            console.print(f"  [green]API connection successful[/green] (model: {response.model})")
    except Exception as e:
        console.print(f"  [red]API connection failed: {e}[/red]")
        raise SystemExit(1)


# ── Architecture command ──


@cli.command("arch")
@click.option("--hints", type=click.Path(exists=True, path_type=Path), default=None,
              help="Path to hints file (YAML or markdown) with architectural preferences.")
@click.option("--nproposals", type=int, default=None,
              help="Generate N diverse proposals instead of interactive refinement.")
@click.option("--prompt", "prompt_variant", default=None,
              help="Prompt variant name (loads arch_{variant}_system.md).")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
@click.option("--no-rag", is_flag=True, help="Disable RAG semantic search.")
@click.option("--no-ontology", "no_ontology", is_flag=True, help="Disable curated-ontology keyword context.")
@click.option("--rich-ontology", "rich_ontology", is_flag=True, help="Inject full MD docs for arch-declared + top-3 baseline patterns instead of YAML snippets.")
@click.option("--fresh", is_flag=True, help="Ignore any existing architecture.md and generate from scratch (independent sample, no refinement chain).")
@click.option("--use-dsl", "use_dsl", is_flag=True, help="Read specs/spec.dsl as the sole specification instead of requirements.md + interface-specification.md. For the DSL-input experiment.")
@click.option("--non-interactive", "non_interactive", is_flag=True, help="Skip the post-generation refinement REPL; auto-save the initial proposal. Use this for headless experiment runs — gives the lean single-arch path without the heavy multi-proposal scaffold of '--nproposals 1'.")
@click.option("--reasoning", type=click.Choice(["low", "medium", "high"]), default=None,
              help="Enable reasoning/extended-thinking on the model (OpenRouter unified parameter; ignored by models without reasoning support).")
def arch_cmd(hints, nproposals, prompt_variant, provider, model, no_rag, no_ontology, rich_ontology, fresh, use_dsl, non_interactive, reasoning):
    """Design macro-level HLS architecture (interactive or multi-proposal)."""
    from hlscribe.project import Project
    from hlscribe.config import load_config, PROVIDERS

    # Must be inside a project (search current dir and parents)
    try:
        project = Project.find(Path.cwd())
    except FileNotFoundError:
        console.print("[red]Not inside an hlscribe project (no hlscribe.yaml found).[/red]")
        console.print("[dim]Run this from a project or design directory created by 'hlscribe init-project'.[/dim]")
        raise SystemExit(1)

    # Detect design context — save architecture to design dir if running from one
    from hlscribe.project import Design
    save_target = None
    cwd = Path.cwd().resolve()
    if cwd != project.root:
        try:
            save_target = Design.load(cwd, project=project)
        except FileNotFoundError:
            pass

    _init_usage_log(save_target if save_target is not None else project)

    # Load config with optional overrides
    cfg = load_config(project_dir=project.root)
    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model
    if reasoning:
        cfg.llm.reasoning = reasoning
    if no_rag:
        cfg.no_rag = True
    if no_ontology:
        cfg.no_ontology = True
    if rich_ontology:
        cfg.rich_ontology = True

    # Load ontology (optional)
    ont = None
    try:
        from hlscribe.ontology import load_ontology
        ont = load_ontology()
    except (FileNotFoundError, Exception):
        pass

    # Load hints (optional)
    hints_data = None
    if hints:
        from hlscribe.workflows.arch_flow import load_hints
        hints_data = load_hints(hints)

    # Run appropriate flow
    from hlscribe.workflows.arch_flow import run_arch_interactive, run_arch_proposals

    if nproposals:
        run_arch_proposals(
            project, cfg, console,
            num_proposals=nproposals, ont=ont,
            hints=hints_data, prompt_variant=prompt_variant,
            save_target=save_target, fresh=fresh,
            use_dsl=use_dsl,
        )
    else:
        run_arch_interactive(
            project, cfg, console,
            ont=ont, hints=hints_data, prompt_variant=prompt_variant,
            save_target=save_target, fresh=fresh,
            use_dsl=use_dsl,
            non_interactive=non_interactive,
        )


# ── Requirements command ──


@cli.command("ra")
@click.option("-d", "--description", default="", help="Initial project description.")
@click.option("--auto", is_flag=True, default=False,
              help="Auto-generate requirements (skip questions, make assumptions).")
@click.option("--hints", type=click.Path(exists=True, path_type=Path), default=None,
              help="Path to hints file (YAML or markdown).")
@click.option("--prompt", "prompt_variant", default=None,
              help="Prompt variant name (loads ra_{variant}_system.md).")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
def ra_cmd(description, auto, hints, prompt_variant, provider, model):
    """Gather and refine project requirements (interactive)."""
    from hlscribe.project import Project
    from hlscribe.config import load_config, PROVIDERS

    try:
        project = Project.find(Path.cwd())
    except FileNotFoundError:
        console.print("[red]Not inside an hlscribe project (no hlscribe.yaml found).[/red]")
        console.print("[dim]Run this from a project directory created by 'hlscribe init-project'.[/dim]")
        raise SystemExit(1)

    _init_usage_log(project)
    cfg = load_config(project_dir=project.root)
    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model

    # Load ontology (optional)
    ont = None
    try:
        from hlscribe.ontology import load_ontology
        ont = load_ontology()
    except (FileNotFoundError, Exception):
        pass

    # Load hints (optional)
    hints_text = ""
    if hints:
        from hlscribe.workflows.arch_flow import load_hints, format_hints
        hints_text = format_hints(load_hints(hints))

    if auto:
        console.print("  [cyan]Auto mode[/cyan]: generating with best-guess assumptions.\n")

    from hlscribe.workflows.doc_flow import run_ra
    run_ra(
        project, cfg, console,
        description=description, hints=hints_text,
        prompt_variant=prompt_variant, ont=ont,
        auto=auto,
    )


# ── Interface command ──


@cli.command("interface-spec")
@click.option("--auto", is_flag=True, default=False,
              help="Auto-generate interface spec (skip questions, make assumptions).")
@click.option("--hints", type=click.Path(exists=True, path_type=Path), default=None,
              help="Path to hints file (YAML or markdown).")
@click.option("--prompt", "prompt_variant", default=None,
              help="Prompt variant name (loads interface_{variant}_system.md).")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
def interface_spec_cmd(auto, hints, prompt_variant, provider, model):
    """Define HLS interface specification (interactive)."""
    from hlscribe.project import Project
    from hlscribe.config import load_config, PROVIDERS

    try:
        project = Project.find(Path.cwd())
    except FileNotFoundError:
        console.print("[red]Not inside an hlscribe project (no hlscribe.yaml found).[/red]")
        console.print("[dim]Run this from a project directory created by 'hlscribe init-project'.[/dim]")
        raise SystemExit(1)

    _init_usage_log(project)
    cfg = load_config(project_dir=project.root)
    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model

    # Load ontology (optional)
    ont = None
    try:
        from hlscribe.ontology import load_ontology
        ont = load_ontology()
    except (FileNotFoundError, Exception):
        pass

    # Load hints (optional)
    hints_text = ""
    if hints:
        from hlscribe.workflows.arch_flow import load_hints, format_hints
        hints_text = format_hints(load_hints(hints))

    if auto:
        console.print("  [cyan]Auto mode[/cyan]: generating with best-guess assumptions.\n")

    from hlscribe.workflows.doc_flow import run_interface
    run_interface(
        project, cfg, console,
        hints=hints_text,
        prompt_variant=prompt_variant, ont=ont,
        auto=auto,
    )


# ── Ontology commands ──


@cli.group()
def ontology():
    """Query the HLS ontology — pragmas, patterns, types, decision guides."""


@ontology.command("stats")
def ontology_stats_cmd():
    """Show ontology statistics."""
    from hlscribe.ontology import load_ontology

    try:
        ont = load_ontology()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    s = ont.stats
    console.print(f"\n[bold]HLS Ontology[/bold] ({ont.path})\n")
    console.print(f"  Pragmas:         {s.num_pragmas}")
    console.print(f"  Patterns:        {s.num_patterns}")
    console.print(f"  Types:           {s.num_types}")
    console.print(f"  Decision guides: {s.num_guides}")
    console.print(f"  Error entries:   {s.num_errors}")
    if ont.examples_dir:
        console.print(f"  Examples:        {ont.examples_dir}")


@ontology.command("list")
@click.argument("category", type=click.Choice(["pragmas", "patterns", "types", "guides", "errors"]))
def ontology_list_cmd(category):
    """List entries in a category."""
    from hlscribe.ontology import load_ontology

    try:
        ont = load_ontology()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    items = getattr(ont, f"list_{category}")()
    console.print(f"\n[bold]{category.title()}[/bold] ({len(items)} entries)\n")
    for item in items:
        console.print(f"  {item}")


@ontology.command("lookup")
@click.argument("query")
def ontology_lookup_cmd(query):
    """Look up a specific pragma, pattern, type, or guide by name/ID."""
    from hlscribe.ontology import (
        format_error,
        format_guide,
        format_pattern,
        format_pragma,
        format_type,
        load_ontology,
    )

    try:
        ont = load_ontology()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    # Try exact match in each category
    p = ont.get_pragma(query)
    if p:
        console.print(f"\n[bold cyan]Pragma:[/bold cyan]")
        console.print(format_pragma(p))
        return

    p = ont.get_pattern(query)
    if p:
        console.print(f"\n[bold cyan]Pattern:[/bold cyan]")
        console.print(format_pattern(p, ont.examples_dir))
        return

    t = ont.get_type(query)
    if t:
        console.print(f"\n[bold cyan]Type:[/bold cyan]")
        console.print(format_type(t))
        return

    g = ont.get_guide(query)
    if g:
        console.print(f"\n[bold cyan]Decision Guide:[/bold cyan]")
        console.print(format_guide(g))
        return

    e = ont.get_error(query)
    if e:
        console.print(f"\n[bold cyan]Error Guidance:[/bold cyan]")
        console.print(format_error(e))
        return

    # Fall back to search
    results = ont.search(query)
    if results:
        console.print(f"\n[bold]Search results for '{query}':[/bold] ({len(results)} matches)\n")
        for r in results[:15]:
            cat = r["category"]
            entry = r["entry"]
            name = entry.get("name") or entry.get("id") or entry.get("title", "?")
            desc = entry.get("description", entry.get("question", ""))
            if isinstance(desc, str):
                desc = desc[:80].strip().replace("\n", " ")
            console.print(f"  [{cat:>8}]  [cyan]{name}[/cyan]  {desc}")
        if len(results) > 15:
            console.print(f"\n  ... and {len(results) - 15} more")
    else:
        console.print(f"[yellow]No results for '{query}'[/yellow]")


@ontology.command("search")
@click.argument("query")
def ontology_search_cmd(query):
    """Search across all ontology categories."""
    # Delegate to lookup which already does search as fallback
    from hlscribe.ontology import load_ontology

    try:
        ont = load_ontology()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    results = ont.search(query)
    if results:
        console.print(f"\n[bold]Search results for '{query}':[/bold] ({len(results)} matches)\n")
        for r in results[:20]:
            cat = r["category"]
            entry = r["entry"]
            name = entry.get("name") or entry.get("id") or entry.get("title", "?")
            desc = entry.get("description", entry.get("question", ""))
            if isinstance(desc, str):
                desc = desc[:80].strip().replace("\n", " ")
            console.print(f"  [{cat:>8}]  [cyan]{name}[/cyan]  {desc}")
        if len(results) > 20:
            console.print(f"\n  ... and {len(results) - 20} more")
    else:
        console.print(f"[yellow]No results for '{query}'[/yellow]")


@ontology.command("chat")
def ontology_chat_cmd():
    """Interactive Q&A with the HLS ontology (LLM-powered)."""
    from hlscribe.ontology import load_ontology
    from hlscribe.config import load_config

    try:
        ont = load_ontology()
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    # Load LLM config (try project dir, fall back to just env)
    try:
        cfg = load_config(project_dir=Path.cwd())
    except SystemExit as exc:
        msg = str(exc) if str(exc) else "Configuration error"
        console.print(f"[red]{msg}[/red]")
        raise SystemExit(1)

    from hlscribe.workflows.ontology_chat import run_ontology_chat
    run_ontology_chat(ont, cfg, console)


# ── Lessons commands ──


@cli.group()
def lessons():
    """Manage fix-loop lesson discoveries."""


@lessons.command("log")
@click.option("-n", "--count", default=20, help="Number of entries to show.")
@click.option("--all", "show_all", is_flag=True, help="Show all entries.")
def lessons_log_cmd(count, show_all):
    """Show recent entries from the lessons log."""
    from hlscribe.lessons_log import LESSONS_LOG_PATH, read_lessons

    entries = read_lessons()
    if not entries:
        console.print("[dim]No entries in lessons log.[/dim]")
        console.print(f"[dim]Log path: {LESSONS_LOG_PATH}[/dim]")
        return

    if not show_all:
        entries = entries[-count:]

    console.print(f"\n[bold]Lessons Log[/bold] ({len(entries)} entries)\n")

    from rich.table import Table

    table = Table(show_header=True, header_style="bold")
    table.add_column("Status", width=8)
    table.add_column("Date", width=10)
    table.add_column("Benchmark/Design", width=25)
    table.add_column("Rd", width=3, justify="right")
    table.add_column("Type", width=6)
    table.add_column("Error Summary", max_width=50)

    for e in entries:
        status = "[dim]reviewed[/dim]" if e.reviewed else "[green]new[/green]"
        date = e.timestamp[:10] if len(e.timestamp) >= 10 else e.timestamp
        bd = f"{e.benchmark}/{e.design}"
        summary = e.error_summary[:60].replace("\n", " ")
        table.add_row(status, date, bd, str(e.round), e.fix_type, summary)

    console.print(table)
    console.print(f"\n[dim]Log path: {LESSONS_LOG_PATH}[/dim]")


@lessons.command("review")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
@click.option("--dry-run", is_flag=True, help="Show proposal without writing.")
def lessons_review_cmd(provider, model, dry_run):
    """LLM-powered review: graduate fix-loop discoveries into lessons.md."""
    from hlscribe.config import PROVIDERS, load_config
    from hlscribe.lessons_log import LESSONS_LOG_PATH, mark_reviewed, read_lessons
    from hlscribe.llm import load_template, chat_once

    entries = read_lessons(unreviewed_only=True)
    if not entries:
        console.print("[dim]No unreviewed entries to review.[/dim]")
        return

    console.print(f"[bold]Reviewing {len(entries)} unreviewed lesson(s)...[/bold]\n")

    # Load LLM config
    try:
        cfg = load_config(project_dir=Path.cwd())
    except SystemExit as exc:
        msg = str(exc) if str(exc) else "Configuration error"
        console.print(f"[red]{msg}[/red]")
        raise SystemExit(1)

    # Provider/model override
    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model

    # Load current lessons.md
    from hlscribe.llm import _PROMPTS_DIR
    lessons_path = _PROMPTS_DIR / "lessons.md"
    current_lessons = lessons_path.read_text() if lessons_path.exists() else "_No lessons file yet._"

    # Format discoveries
    lines = []
    for i, e in enumerate(entries):
        lines.append(f"### Discovery #{i+1}")
        lines.append(f"- **Benchmark**: {e.benchmark}/{e.design} round {e.round}")
        lines.append(f"- **Fix type**: {e.fix_type} ({e.fix_target})")
        lines.append(f"- **Build stage**: {e.build_stage}")
        lines.append(f"- **Error**: {e.error_summary}")
        lines.append(f"- **Analysis**: {e.fix_analysis}")
        if e.fix_diff:
            lines.append(f"- **Diff**:\n```diff\n{e.fix_diff}\n```")
        lines.append("")
    new_discoveries = "\n".join(lines)

    # Build prompt from template
    review_template = load_template("lessons_review.md")
    system_prompt = (
        review_template
        .replace("{current_lessons}", current_lessons)
        .replace("{new_discoveries}", new_discoveries)
    )

    console.print(f"  Model: [cyan]{cfg.llm.model}[/cyan]")
    console.print(f"  Entries: [cyan]{len(entries)}[/cyan]\n")

    history: list[dict] = []
    with console.status("[dim]Reviewing discoveries with LLM...[/dim]"):
        reply = chat_once(cfg, system_prompt, history, "Review the discoveries and propose additions to lessons.md.", tag="lessons-review")

    # Extract lessons block
    new_rules = _extract_lessons_block(reply)

    console.print("[bold]Proposed additions:[/bold]\n")
    from rich.markdown import Markdown
    console.print(Markdown(new_rules))

    if "_No new lessons to add._" in new_rules:
        console.print("\n[dim]Nothing to add. Marking entries as reviewed.[/dim]")
        mark_reviewed()
        return

    if dry_run:
        console.print("\n[dim](dry-run — no changes written)[/dim]")
        return

    # Prompt user
    console.print()
    choice = click.prompt(
        "Action",
        type=click.Choice(["approve", "edit", "skip"], case_sensitive=False),
        default="approve",
    )

    if choice == "approve":
        # Append to lessons.md
        with open(lessons_path, "a") as f:
            f.write("\n\n" + new_rules.strip() + "\n")
        mark_reviewed()
        console.print(f"[green]Appended to {lessons_path}[/green]")
        console.print(f"[dim]Marked {len(entries)} entries as reviewed.[/dim]")
    elif choice == "edit":
        mark_reviewed()
        console.print(f"[dim]Marked {len(entries)} entries as reviewed.[/dim]")
        console.print(f"[dim]Edit {lessons_path} manually to add rules.[/dim]")
    else:
        console.print("[dim]Skipped — entries left unreviewed for next time.[/dim]")


def _extract_lessons_block(reply: str) -> str:
    """Extract markdown fence content or fall back to ## headings."""
    import re

    # Try markdown fence first
    m = re.search(r"```(?:markdown)?\s*\n(.*?)```", reply, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Fall back to content starting from first ### heading
    m = re.search(r"(###\s+.+)", reply, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Last resort: return full reply
    return reply.strip()


@lessons.command("clear")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def lessons_clear_cmd(yes):
    """Remove reviewed entries from the lessons log (housekeeping)."""
    from hlscribe.lessons_log import LESSONS_LOG_PATH, clear_reviewed, read_lessons

    entries = read_lessons()
    reviewed = [e for e in entries if e.reviewed]

    if not reviewed:
        console.print("[dim]No reviewed entries to clear.[/dim]")
        return

    if not yes:
        if not click.confirm(f"Remove {len(reviewed)} reviewed entries from log?"):
            return

    removed = clear_reviewed()
    console.print(f"[green]Removed {removed} reviewed entries.[/green]")
    remaining = read_lessons()
    console.print(f"[dim]{len(remaining)} entries remaining.[/dim]")


# ── Docs / RAG commands ──


@cli.group()
def docs():
    """Semantic search over HLS documentation (RAG)."""


@docs.command("index")
@click.option("--source", default="all",
              type=click.Choice(["ug1399", "ug1448", "bluebook", "examples", "ontology", "all"]),
              help="Source to index (default: all).")
@click.option("--force", is_flag=True, help="Re-index even if unchanged.")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed progress.")
def docs_index_cmd(source, force, verbose):
    """Index HLS documentation for semantic search."""
    try:
        from hlscribe.rag.config import RagConfig
        from hlscribe.rag.embeddings import EmbeddingClient
        from hlscribe.rag.indexer import Indexer
        from hlscribe.rag.store import RagStore
    except ImportError as e:
        console.print(f"[red]RAG dependencies not installed: {e}[/red]")
        console.print("[dim]Install with: pip install hlscribe[rag][/dim]")
        raise SystemExit(1)

    config = RagConfig.load()
    api_key = config.get_api_key()
    if not api_key:
        console.print("[red]VOYAGE_API_KEY not set.[/red]")
        console.print("[dim]Add VOYAGE_API_KEY=... to ~/.hlscribe/.env[/dim]")
        raise SystemExit(1)

    store = RagStore(store_path=config.store_path)
    embedder = EmbeddingClient(api_key=api_key, model=config.embedding_model)
    indexer = Indexer(store, embedder, config)

    from rich.progress import Progress

    def log(msg):
        if verbose:
            console.print(f"  [dim]{msg}[/dim]")

    with Progress(console=console) as progress:
        if source == "all":
            task = progress.add_task("Indexing all sources...", total=len(config.sources))
            results = {}
            for src_id in config.sources:
                path = config.sources[src_id]
                if not path.exists():
                    console.print(f"  [yellow]Skipping {src_id} (not found: {path})[/yellow]")
                    progress.advance(task)
                    continue
                progress.update(task, description=f"Indexing {src_id}...")
                result = indexer.index_source(src_id, force=force, progress_callback=log)
                results[src_id] = result
                progress.advance(task)
        else:
            task = progress.add_task(f"Indexing {source}...", total=1)
            result = indexer.index_source(source, force=force, progress_callback=log)
            results = {source: result}
            progress.advance(task)

    # Summary
    console.print()
    from rich.table import Table

    table = Table(title="Indexing Results", show_header=True, header_style="bold")
    table.add_column("Source")
    table.add_column("Chunks", justify="right")
    table.add_column("Time", justify="right")
    table.add_column("Status")

    for src_id, res in results.items():
        if res.skipped:
            status = "[dim]up-to-date[/dim]"
        elif res.chunks_added > 0:
            status = "[green]indexed[/green]"
        else:
            status = "[yellow]empty[/yellow]"
        table.add_row(
            src_id,
            str(res.chunks_added),
            f"{res.duration_seconds:.1f}s",
            status,
        )

    console.print(table)


@docs.command("search")
@click.argument("query")
@click.option("-n", "--num-results", default=10, help="Max results to return.")
@click.option("--source", default=None,
              type=click.Choice(["ug1399", "ug1448", "bluebook", "examples", "ontology"]),
              help="Filter by source.")
def docs_search_cmd(query, num_results, source):
    """Semantic search across indexed HLS documentation."""
    try:
        from hlscribe.rag import HLSRag
    except ImportError as e:
        console.print(f"[red]RAG dependencies not installed: {e}[/red]")
        console.print("[dim]Install with: pip install hlscribe[rag][/dim]")
        raise SystemExit(1)

    rag = HLSRag()
    if not rag.is_indexed:
        console.print("[yellow]No index found. Run 'hlscribe docs index' first.[/yellow]")
        raise SystemExit(1)

    results = rag.search(query, n_results=num_results, source=source)
    if not results:
        console.print("[dim]No results found.[/dim]")
        return

    from rich.table import Table

    table = Table(title=f"Search: {query}", show_header=True, header_style="bold")
    table.add_column("Score", width=6, justify="right")
    table.add_column("Source", width=10)
    table.add_column("Title", width=30)
    table.add_column("Excerpt", width=60)

    for r in results:
        score_str = f"{1 - r.score:.2f}"  # convert distance to similarity
        excerpt = r.text[:120].replace("\n", " ") + "..."
        page_info = f" p.{r.page}" if r.page else ""
        table.add_row(score_str, f"{r.source}{page_info}", r.title[:30], excerpt)

    console.print(table)


@docs.command("stats")
def docs_stats_cmd():
    """Show RAG index statistics."""
    try:
        from hlscribe.rag import HLSRag
    except ImportError as e:
        console.print(f"[red]RAG dependencies not installed: {e}[/red]")
        console.print("[dim]Install with: pip install hlscribe[rag][/dim]")
        raise SystemExit(1)

    rag = HLSRag()
    stats = rag.stats

    if stats["total"] == 0:
        console.print("[yellow]No index found.[/yellow]")
        console.print("[dim]Run 'hlscribe docs index' to build the index.[/dim]")
        return

    from rich.table import Table

    table = Table(title="RAG Index Statistics", show_header=True, header_style="bold")
    table.add_column("Source")
    table.add_column("Chunks", justify="right")

    for src, count in stats["sources"].items():
        table.add_row(src, str(count))
    table.add_row("[bold]Total[/bold]", f"[bold]{stats['total']}[/bold]")

    console.print(table)

    # Show manifest info if available
    from hlscribe.rag.config import RagConfig
    config = RagConfig.load()
    if config.manifest_path.exists():
        import json
        manifest = json.loads(config.manifest_path.read_text())
        console.print()
        for src_id, info in manifest.items():
            ts = info.get("indexed_at", "unknown")
            console.print(f"  [dim]{src_id}: indexed at {ts}[/dim]")


# ── Help / Ask command ──


@cli.command("ask")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
def ask_cmd(provider, model):
    """Interactive help — ask questions about hlscribe commands and workflows."""
    from hlscribe.config import load_config, PROVIDERS

    # Load config — works without a project dir (just needs API key)
    try:
        cfg = load_config(project_dir=Path.cwd())
    except SystemExit as exc:
        # Pass through the real error message from load_config
        msg = str(exc) if str(exc) else "Configuration error"
        console.print(f"[red]{msg}[/red]")
        raise SystemExit(1)

    # Provider/model override (standard boilerplate)
    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model

    from hlscribe.workflows.help_chat import run_help_chat
    run_help_chat(cfg, console)


# ── Import commands ──


@cli.command("import-kernel")
@click.argument("files", nargs=-1, type=click.Path(exists=True, path_type=Path), required=True)
@click.option("--spec", default=None, help="Brief description of the imported component.")
@click.option("--spec-file", type=click.Path(exists=True, path_type=Path), default=None,
              help="Detailed spec file (.md) for the imported component.")
def import_kernel_cmd(files, spec, spec_file):
    """Import pre-built .cpp/.h files into the current design for multi-file composition."""
    from hlscribe.workflows.import_kernel import import_files

    design = _find_design()

    sources = [Path(f).resolve() for f in files]
    try:
        record = import_files(design, sources, spec=spec, spec_file=spec_file)
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)

    console.print(f"[green]Imported {len(record.files)} file(s) into {design.src_dir}:[/green]")
    for f in record.files:
        console.print(f"  {f}")
    if record.spec:
        console.print(f"  Spec: [dim]{record.spec}[/dim]")
    if record.spec_file:
        console.print(f"  Spec file: [dim]{record.spec_file}[/dim]")
    console.print(f"  Manifest: [dim]{design.imports_manifest}[/dim]")


@cli.command("list-imports")
def list_imports_cmd():
    """List imported source files in the current design."""
    from hlscribe.workflows.import_kernel import load_imports

    design = _find_design()
    records = load_imports(design)

    if not records:
        console.print("[dim]No imports found.[/dim]")
        return

    for i, rec in enumerate(records, 1):
        console.print(f"\n[bold]Import #{i}[/bold]")
        console.print(f"  Files:  {', '.join(rec.files)}")
        if rec.spec:
            console.print(f"  Spec:   {rec.spec}")
        if rec.spec_file:
            console.print(f"  Detail: {rec.spec_file}")
        console.print(f"  Source: [dim]{rec.source}[/dim]")
        console.print(f"  Date:   [dim]{rec.imported_at}[/dim]")

    # Also show all non-reserved files in src/
    extra = design.list_imports()
    if extra:
        console.print(f"\n[dim]All imported files in src/: {', '.join(extra)}[/dim]")


# ── Export command ──


@cli.command("export")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
def export_cmd(provider, model):
    """Export kernel.h, stream component, and component-spec.md for import."""
    from hlscribe.config import PROVIDERS, load_config

    design = _find_design()
    project = design.project
    cfg = load_config(project_dir=project.root)

    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model

    from hlscribe.workflows.export_flow import run_export

    run_export(project, design, cfg, console)


# ── Build commands ──


def _find_design() -> "Design":
    """Locate the current Design (must be in a design directory)."""
    from hlscribe.project import Design, Project

    cwd = Path.cwd().resolve()

    # Check if cwd itself is a design (has Makefile)
    if (cwd / "Makefile").exists():
        try:
            project = Project.find(cwd.parent)
            design = Design.load(cwd, project=project)
            _init_usage_log(design)
            return design
        except FileNotFoundError:
            pass

    console.print("[red]Not inside a design directory (no Makefile found).[/red]")
    console.print("[dim]Run this from a design directory created by 'hlscribe init-design'.[/dim]")
    raise SystemExit(1)


@cli.command("build")
@click.argument("stage", type=click.Choice(["csim", "csynth", "cosim", "host", "hw_emu", "hw"]))
@click.option("--sol", multiple=True, help="Solution name(s) to build (repeatable; default: baseline).")
@click.option("--sweep", is_flag=True, help="Build all configs.")
@click.option("--slurm", is_flag=True, help="Submit to Slurm cluster.")
@click.option("--nodes", type=int, default=None, help="Max concurrent Slurm array tasks.")
@click.option("--time", "slurm_time", default=None, help="Slurm time limit (HH:MM:SS).")
def build_cmd(stage, sol, sweep, slurm, nodes, slurm_time):
    """Run HLS build (csim, csynth, cosim, host, hw_emu, or hw)."""
    from hlscribe.config import load_config
    from hlscribe.workflows.build import list_configs, run_build, run_sweep, submit_slurm

    design = _find_design()
    cfg = load_config(project_dir=design.project.root)

    # host is solution-independent — skip SOL loop
    if stage == "host":
        console.print("Building: host application")
        result = run_build(design, stage, "baseline")
        if result.success:
            dur = f" ({result.duration:.1f}s)" if result.duration else ""
            console.print(f"[green]Host build succeeded[/green]{dur}")
        else:
            console.print(f"[red]Host build failed[/red] (exit code {result.return_code})")
            if result.log_file:
                console.print(f"  Log: {result.log_file}")
            raise SystemExit(1)
        return

    # Determine solutions
    if sweep:
        sols = list_configs(design)
        if not sols:
            console.print("[red]No configs found in configs/.[/red]")
            raise SystemExit(1)
    elif sol:
        sols = [s.strip() for v in sol for s in v.split(",") if s.strip()]
    else:
        sols = ["baseline"]

    if slurm:
        # Apply CLI overrides to slurm config
        if nodes is not None:
            cfg.slurm.nodes = nodes
        if slurm_time is not None:
            cfg.slurm.time = slurm_time

        if not cfg.slurm.enabled:
            console.print("[red]Slurm not configured. Set slurm.host in ~/.hlscribe/config.yaml[/red]")
            raise SystemExit(1)

        console.print(f"Submitting to Slurm: {len(sols)} solution(s), stage={stage}")
        try:
            job_id = submit_slurm(design, stage, sols, cfg.slurm)
            console.print(f"[green]Submitted job {job_id}[/green] ({len(sols)} tasks)")
            console.print(f"  Track with: [cyan]hlscribe jobs[/cyan]")
        except RuntimeError as e:
            console.print(f"[red]{e}[/red]")
            raise SystemExit(1)
    elif len(sols) > 1:
        console.print(f"Local build: {len(sols)} solution(s), stage={stage}")
        results = run_sweep(design, stage, sols)
        for r in results:
            status = "[green]OK[/green]" if r.success else "[red]FAIL[/red]"
            dur = f" ({r.duration:.1f}s)" if r.duration else ""
            console.print(f"  {r.sol}: {status}{dur}")
    else:
        console.print(f"Building: {sols[0]} ({stage})")
        result = run_build(design, stage, sols[0])
        if result.success:
            dur = f" ({result.duration:.1f}s)" if result.duration else ""
            console.print(f"[green]Build succeeded[/green]{dur}")
        else:
            console.print(f"[red]Build failed[/red] (exit code {result.return_code})")
            if result.log_file:
                console.print(f"  Log: {result.log_file}")
            raise SystemExit(1)


@cli.command("run-hw-emu")
@click.option("--sol", default="baseline", help="Solution name (default: baseline).")
def run_hw_emu_cmd(sol):
    """Run hardware emulation (requires prior hw_emu build)."""
    from hlscribe.workflows.build import run_build

    design = _find_design()
    console.print(f"Running hw_emu: {sol}")
    result = run_build(design, "run-hw-emu", sol)
    if result.success:
        dur = f" ({result.duration:.1f}s)" if result.duration else ""
        console.print(f"[green]hw_emu execution succeeded[/green]{dur}")
    else:
        console.print(f"[red]hw_emu execution failed[/red] (exit code {result.return_code})")
        if result.log_file:
            console.print(f"  Log: {result.log_file}")
        raise SystemExit(1)


@cli.command("run-hw")
@click.option("--sol", default="baseline", help="Solution name (default: baseline).")
def run_hw_cmd(sol):
    """Run on hardware (requires prior hw build)."""
    from hlscribe.workflows.build import run_build

    design = _find_design()
    console.print(f"Running on hardware: {sol}")
    result = run_build(design, "run-hw", sol)
    if result.success:
        dur = f" ({result.duration:.1f}s)" if result.duration else ""
        console.print(f"[green]hw execution succeeded[/green]{dur}")
    else:
        console.print(f"[red]hw execution failed[/red] (exit code {result.return_code})")
        if result.log_file:
            console.print(f"  Log: {result.log_file}")
        raise SystemExit(1)


@cli.command("jobs")
@click.option("--cancel", type=int, default=None, help="Cancel Slurm job ID.")
@click.option("--cancel-all", is_flag=True, help="Cancel the last submitted job.")
def jobs_cmd(cancel, cancel_all):
    """Show Slurm job status for the current design."""
    from hlscribe.config import load_config
    from hlscribe.workflows.slurm import cancel_job, load_job_metadata, query_jobs

    design = _find_design()
    cfg = load_config(project_dir=design.project.root)

    if not cfg.slurm.enabled:
        console.print("[red]Slurm not configured. Set slurm.host in ~/.hlscribe/config.yaml[/red]")
        raise SystemExit(1)

    if cancel is not None or cancel_all:
        jid = cancel if cancel is not None else None
        if cancel_job(design, cfg.slurm, jid):
            console.print(f"[green]Job cancelled.[/green]")
        else:
            console.print("[red]Cancel failed (no job found or already completed).[/red]")
        return

    meta = load_job_metadata(design)
    if meta is None:
        console.print("No Slurm jobs found for this design.")
        return

    console.print(f"[bold]Job {meta['job_id']}[/bold] (mode: {meta['mode']}, {meta['num_tasks']} tasks)\n")

    tasks = query_jobs(design, cfg.slurm)
    if not tasks:
        console.print("  No task data available (job may be queued or completed).")
        return

    for t in tasks:
        state_color = {
            "RUNNING": "cyan",
            "COMPLETED": "green",
            "FAILED": "red",
            "PENDING": "yellow",
            "CANCELLED": "dim",
        }.get(t.state, "white")
        console.print(
            f"  {t.task_id:>3}  {t.sol:<20}  [{state_color}]{t.state:<12}[/{state_color}]  "
            f"{t.elapsed}  {t.node}"
        )


@cli.command("logs")
@click.argument("sol", default=None, required=False)
@click.option("--stage", default=None, help="Build stage (csim/csynth/cosim).")
@click.option("--errors", is_flag=True, help="Show only error lines.")
@click.option("--tail", type=int, default=None, help="Show last N lines.")
def logs_cmd(sol, stage, errors, tail):
    """View build logs for a solution."""
    design = _find_design()
    logs_dir = design.logs_dir

    if not logs_dir.exists():
        console.print("No logs found. Run a build first.")
        raise SystemExit(1)

    # Find log file(s)
    if sol and stage:
        candidates = [logs_dir / f"{sol}_{stage}.log"]
    elif sol:
        candidates = sorted(logs_dir.glob(f"{sol}_*.log"))
    elif stage:
        candidates = sorted(logs_dir.glob(f"*_{stage}.log"))
    else:
        candidates = sorted(logs_dir.glob("*.log"))

    if not candidates or not any(c.exists() for c in candidates):
        console.print("[yellow]No matching log files found.[/yellow]")
        if sol or stage:
            available = sorted(logs_dir.glob("*.log"))
            if available:
                console.print("  Available logs:")
                for f in available:
                    console.print(f"    {f.name}")
        raise SystemExit(1)

    for log_path in candidates:
        if not log_path.exists():
            continue
        console.print(f"\n[bold]--- {log_path.name} ---[/bold]")
        lines = log_path.read_text().splitlines()

        if errors:
            lines = [l for l in lines if re.search(r"ERROR|FAIL|error:|fatal:", l, re.IGNORECASE)]
            if not lines:
                console.print("  [dim]No errors found.[/dim]")
                continue

        if tail is not None:
            lines = lines[-tail:]

        for line in lines:
            console.print(line)


@cli.group("usage")
def usage_group():
    """LLM usage telemetry — token counts, costs, generation IDs."""


@usage_group.command("show")
@click.option("--path", "path_str", type=click.Path(), default=None,
              help="Path to a usage JSONL file (default: current design's log).")
@click.option("--all", "all_designs", is_flag=True,
              help="Aggregate across all designs under the current project.")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output.")
def usage_show_cmd(path_str, all_designs, as_json):
    """Show rollup of LLM token counts and cost per tag."""
    import json as _json
    from hlscribe import usage as _usage

    paths: list[Path] = []
    if path_str:
        paths.append(Path(path_str))
    elif all_designs:
        from hlscribe.project import Project
        try:
            project = Project.find(Path.cwd())
        except FileNotFoundError:
            console.print("[red]Not inside an hlscribe project.[/red]")
            raise SystemExit(1)
        for d in project.list_designs():
            p = d.artifacts_dir / "llm_usage.jsonl"
            if p.exists():
                paths.append(p)
    else:
        design = _find_design()
        paths.append(design.artifacts_dir / "llm_usage.jsonl")

    rows: list[dict] = []
    for p in paths:
        rows.extend(_usage.load_records(p))

    if not rows:
        console.print("[dim]No usage records.[/dim]")
        return

    summary = _usage.summarize(rows)

    if as_json:
        console.print(_json.dumps({
            "paths": [str(p) for p in paths],
            "summary": summary,
        }, indent=2, default=str))
        return

    from rich.table import Table
    table = Table(title=f"LLM usage ({len(rows)} calls)")
    table.add_column("Tag", style="cyan")
    table.add_column("Model", style="magenta")
    table.add_column("Calls", justify="right")
    table.add_column("Input tok", justify="right")
    table.add_column("Output tok", justify="right")
    table.add_column("Cost (USD)", justify="right")
    table.add_column("Dur (s)", justify="right")

    for (tag, model) in sorted(summary["by_tag_model"]):
        b = summary["by_tag_model"][(tag, model)]
        table.add_row(
            tag,
            model,
            str(b["calls"]),
            f"{b['input_tokens']:,}",
            f"{b['output_tokens']:,}",
            f"${b['cost_usd']:.4f}",
            f"{b['duration_s']:.1f}",
        )
    t = summary["totals"]
    table.add_row(
        "[bold]TOTAL[/bold]",
        "",
        f"[bold]{t['calls']}[/bold]",
        f"[bold]{t['input_tokens']:,}[/bold]",
        f"[bold]{t['output_tokens']:,}[/bold]",
        f"[bold]${t['cost_usd']:.4f}[/bold]",
        f"[bold]{t['duration_s']:.1f}[/bold]",
    )
    console.print(table)

    sources = summary["sources"]
    src_str = ", ".join(f"{s}={n}" for s, n in sources.items())
    console.print(f"[dim]Cost source breakdown: {src_str}[/dim]")
    if t["missing_cost"]:
        console.print(f"[yellow]{t['missing_cost']} call(s) have no cost (model not in price table).[/yellow]")
    cs = _usage.cost_table_source()
    if cs:
        console.print(f"[dim]Cost table: {cs}[/dim]")


@usage_group.command("reconcile")
@click.option("--path", "path_str", type=click.Path(), default=None,
              help="Path to a usage JSONL file (default: current design's log).")
@click.option("--all", "all_designs", is_flag=True,
              help="Reconcile all designs under the current project.")
@click.option("--force", is_flag=True,
              help="Re-fetch even rows already reconciled.")
def usage_reconcile_cmd(path_str, all_designs, force):
    """Replace estimated costs with OpenRouter's authoritative cost.

    Queries the OpenRouter generation API for each row carrying a
    generation_id and overwrites cost_usd in place.
    """
    import os
    from dotenv import load_dotenv
    from hlscribe import usage as _usage

    # Load secrets the same way load_config() does, so this works
    # standalone (no project config required).
    global_env = Path.home() / ".hlscribe" / ".env"
    if global_env.exists():
        load_dotenv(global_env)

    api_key = os.environ.get("OPENROUTER_API_KEY", "")
    if not api_key:
        console.print("[red]OPENROUTER_API_KEY not set.[/red]")
        console.print("[dim]Add it to ~/.hlscribe/.env or export it.[/dim]")
        raise SystemExit(1)

    paths: list[Path] = []
    if path_str:
        paths.append(Path(path_str))
    elif all_designs:
        from hlscribe.project import Project
        try:
            project = Project.find(Path.cwd())
        except FileNotFoundError:
            console.print("[red]Not inside an hlscribe project.[/red]")
            raise SystemExit(1)
        for d in project.list_designs():
            p = d.artifacts_dir / "llm_usage.jsonl"
            if p.exists():
                paths.append(p)
    else:
        design = _find_design()
        paths.append(design.artifacts_dir / "llm_usage.jsonl")

    total_updated = total_skipped = total_failed = 0
    for p in paths:
        if not p.exists():
            console.print(f"[yellow]Skipping (missing): {p}[/yellow]")
            continue
        console.print(f"Reconciling [cyan]{p}[/cyan]")
        result = _usage.reconcile_openrouter(p, api_key, force=force)
        console.print(
            f"  updated={result['updated']}  "
            f"skipped={result['skipped']}  "
            f"failed={result['failed']}"
        )
        for idx, err in result["errors"][:5]:
            console.print(f"  [yellow]row {idx}: {err}[/yellow]")
        if len(result["errors"]) > 5:
            console.print(f"  [dim]... and {len(result['errors']) - 5} more[/dim]")
        total_updated += result["updated"]
        total_skipped += result["skipped"]
        total_failed += result["failed"]

    console.print(
        f"\n[bold]Total:[/bold] updated={total_updated}  "
        f"skipped={total_skipped}  failed={total_failed}"
    )


@cli.command("results")
@click.option("--sort", "sort_by", default=None,
              help="Sort by metric (latency, bram, dsp, lut, ff, ii).")
@click.option("--csv", "csv_path", type=click.Path(), default=None,
              help="Export to CSV file.")
@click.option("--best", is_flag=True, help="Highlight best config per metric.")
def results_cmd(sort_by, csv_path, best):
    """Show synthesis results comparison table."""
    import re as _re

    from hlscribe.report_parser import collect_all_reports, format_comparison_table

    design = _find_design()
    metrics = collect_all_reports(design)

    if not metrics:
        console.print("No synthesis reports found. Run 'hlscribe build csynth' first.")
        raise SystemExit(1)

    # Sort
    sort_keys = {
        "latency": lambda m: m.latency_max or float("inf"),
        "latency_avg": lambda m: m.latency_avg or float("inf"),
        "bram": lambda m: m.bram or float("inf"),
        "dsp": lambda m: m.dsp or float("inf"),
        "lut": lambda m: m.lut or float("inf"),
        "ff": lambda m: m.ff or float("inf"),
        "uram": lambda m: m.uram or float("inf"),
        "ii": lambda m: m.interval_min or float("inf"),
        "cosim": lambda m: m.cosim_cycles or float("inf"),
    }
    if sort_by and sort_by in sort_keys:
        metrics.sort(key=sort_keys[sort_by])

    console.print(f"\n[bold]Synthesis Results ({len(metrics)} solutions)[/bold]\n")
    console.print(format_comparison_table(metrics))

    if best and len(metrics) > 1:
        console.print("\n[bold]Best per metric:[/bold]")
        for name, key in sort_keys.items():
            b = min(metrics, key=key)
            val = key(b)
            if val != float("inf"):
                console.print(f"  {name:<8}: {b.sol} ({int(val)})")

    if csv_path:
        import csv
        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "solution", "latency_min", "latency_avg", "latency_max",
                "ii_min", "ii_max",
                "bram", "bram_avail", "dsp", "dsp_avail",
                "ff", "ff_avail", "lut", "lut_avail", "uram", "uram_avail",
                "clock_achieved", "clock_target", "clock_uncertainty",
                "pipeline_type",
                "realtime_best", "realtime_avg", "realtime_worst",
                "cosim_cycles", "cosim_status",
            ])
            for m in metrics:
                writer.writerow([
                    m.sol, m.latency_min, m.latency_avg, m.latency_max,
                    m.interval_min, m.interval_max,
                    m.bram, m.bram_avail, m.dsp, m.dsp_avail,
                    m.ff, m.ff_avail, m.lut, m.lut_avail, m.uram, m.uram_avail,
                    m.clock_achieved, m.clock_target, m.clock_uncertainty,
                    m.pipeline_type,
                    m.realtime_best, m.realtime_avg, m.realtime_worst,
                    m.cosim_cycles, m.cosim_status,
                ])
        console.print(f"\n  Exported to [cyan]{csv_path}[/cyan]")


# ── Code generation commands ──


@cli.command("codegen")
@click.option("--step", type=click.Choice(["kernel", "testbench", "host", "all"]), default="all",
              help="Generate kernel, testbench, host, or all.")
@click.option("--refine", is_flag=True, help="Fix code from build error log (single round).")
@click.option("--fix-loop", "fix_loop", is_flag=True,
              help="Multi-round fix loop: build → parse → fix → rebuild.")
@click.option("--build-stage", "build_stage",
              type=click.Choice(["csim", "csynth", "cosim"]), default=None,
              help="Build stage for --fix-loop/--refine (default: auto-detect from latest log).")
@click.option("--max-rounds", "max_rounds", type=int, default=None,
              help="Max fix rounds for --fix-loop (default: from config).")
@click.option("--log", "log_path", type=click.Path(exists=True, path_type=Path), default=None,
              help="Path to build log file (for --refine/--fix-loop).")
@click.option("--file", "fix_file", default="kernel.cpp",
              help="File to fix (for --refine/--fix-loop).")
@click.option("--prompt", "prompt_variant", default=None,
              help="Prompt variant name.")
@click.option("--dse", is_flag=True,
              help="Generate pragma-free kernel (kernel_dse.cpp) for DSE config sweeps.")
@click.option("--strip", is_flag=True,
              help="Strip pragmas from kernel.cpp instead of LLM generation (use with --dse).")
@click.option("--nollm", is_flag=True,
              help="Skip LLM review when using --strip (pure regex, no API call).")
@click.option("--interactive", "-i", is_flag=True,
              help="Interactive mode: show diff and accept/reject each fix round.")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
@click.option("--no-rag", is_flag=True, help="Disable RAG semantic search.")
@click.option("--no-ontology", "no_ontology", is_flag=True, help="Disable curated-ontology keyword context.")
@click.option("--rich-ontology", "rich_ontology", is_flag=True, help="Inject full MD docs for arch-declared + top-3 baseline patterns instead of YAML snippets.")
@click.option("--sol", default=None,
              help="Solution/config name for builds (default: baseline, or baseline_dse with --dse).")
@click.option("--use-dsl", "use_dsl", is_flag=True,
              help="Read specs/spec.dsl as the sole specification instead of requirements.md + interface-specification.md. Applies to codegen, --refine, and --fix-loop. For the DSL-input experiment.")
@click.option("--arch-check", "arch_check", is_flag=True,
              help="After codegen/refine/fix-loop, run an LLM call to compare the generated kernel against architecture.md (diagnostic only, never gates). Adds one chat_once per command; off by default to keep experiment cost down.")
@click.option("--reasoning", type=click.Choice(["low", "medium", "high"]), default=None,
              help="Enable reasoning/extended-thinking on the model (OpenRouter unified parameter; ignored by models without reasoning support).")
def codegen_cmd(step, refine, fix_loop, build_stage, max_rounds,
                log_path, fix_file, prompt_variant, dse, strip, nollm,
                interactive, provider, model, no_rag, no_ontology, rich_ontology, sol, use_dsl, arch_check, reasoning):
    """Generate HLS kernel and/or testbench code from specs."""
    from hlscribe.config import load_config, PROVIDERS

    if refine and fix_loop:
        console.print("[red]--refine and --fix-loop are mutually exclusive.[/red]")
        raise SystemExit(1)
    if strip and not dse:
        console.print("[red]--strip requires --dse.[/red]")
        raise SystemExit(1)
    if nollm and not strip:
        console.print("[red]--nollm requires --strip.[/red]")
        raise SystemExit(1)

    design = _find_design()
    project = design.project
    cfg = load_config(project_dir=project.root)

    if provider:
        if provider not in PROVIDERS:
            console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
            raise SystemExit(1)
        import os
        prov = PROVIDERS[provider]
        api_key = os.environ.get(prov["key_env"], "")
        if not api_key:
            console.print(f"[red]{prov['key_env']} not set.[/red]")
            raise SystemExit(1)
        cfg.llm.provider = provider
        cfg.llm.api_key = api_key
        cfg.llm.api_base = prov["api_base"]
        if not model:
            cfg.llm.model = prov["default_model"]
    if model:
        cfg.llm.model = model
    if reasoning:
        cfg.llm.reasoning = reasoning
    if no_rag:
        cfg.no_rag = True
    if no_ontology:
        cfg.no_ontology = True
    if rich_ontology:
        cfg.rich_ontology = True

    # Load ontology (optional)
    ont = None
    try:
        from hlscribe.ontology import load_ontology
        ont = load_ontology()
    except (FileNotFoundError, Exception):
        pass

    # --dse defaults to kernel-only (testbench/host are shared, don't overwrite)
    if dse and step == "all":
        step = "kernel"

    dse_file = "kernel_dse.cpp" if dse else fix_file

    # Default sol: baseline_dse when --dse, else baseline
    if sol is None:
        sol = "baseline_dse" if dse else "baseline"

    if fix_loop:
        from hlscribe.workflows.fix_loop import run_fix_loop
        run_fix_loop(
            project, design, cfg, console,
            file_name=dse_file, build_stage=build_stage,
            sol=sol,
            log_path=log_path,
            max_rounds=max_rounds, ont=ont,
            interactive=interactive,
            use_dsl=use_dsl,
            arch_check=arch_check,
        )
    elif refine:
        from hlscribe.workflows.codegen_flow import run_refine
        run_refine(
            project, design, cfg, console,
            file_name=dse_file, log_path=log_path,
            build_stage=build_stage, ont=ont,
            use_dsl=use_dsl,
            arch_check=arch_check,
        )
    elif dse and strip:
        from hlscribe.workflows.codegen_flow import run_strip_dse
        run_strip_dse(project, design, cfg, console, skip_review=nollm)
    else:
        from hlscribe.workflows.codegen_flow import run_codegen
        run_codegen(
            project, design, cfg, console,
            step=step, ont=ont,
            prompt_variant=prompt_variant,
            dse=dse,
            use_dsl=use_dsl,
            arch_check=arch_check,
        )


@cli.command("gen-configs")
@click.option("--sweep", multiple=True,
              help="Mechanical sweep (no LLM): 'ii=1,2,4' or 'partition=2,4,complete'.")
@click.option("--max", "max_configs", type=int, default=50,
              help="Max configs for mechanical sweep.")
@click.option("-n", "--num", "num_configs", type=int, default=10,
              help="Number of LLM-generated configs (default: 10).")
@click.option("--provider", default=None,
              help="Override LLM provider (anthropic, openrouter, openai).")
@click.option("--model", default=None,
              help="Override LLM model.")
@click.option("--no-rag", is_flag=True, help="Disable RAG semantic search.")
def gen_configs_cmd(sweep, max_configs, num_configs, provider, model, no_rag):
    """Generate DSE configuration files.

    Default: LLM-based intelligent generation (extracts pragmas, reasons about trade-offs).
    With --sweep: mechanical cartesian-product sweep (no LLM needed).
    """
    design = _find_design()

    # Prefer DSE kernel when available
    has_dse_kernel = design.dse_kernel_file.exists()
    if not has_dse_kernel and not design.kernel_file.exists():
        console.print("[red]No kernel found in src/.[/red]")
        console.print("[dim]Run 'hlscribe codegen' first to generate kernel code.[/dim]")
        raise SystemExit(1)

    if sweep:
        # ── Mechanical sweep path ──
        from hlscribe.config_gen import (
            detect_top_function,
            generate_configs,
            load_base_header,
            write_configs,
            _parse_sweep_string,
        )

        if has_dse_kernel:
            kernel_code = design.read_dse_kernel()
            console.print("  [dim]Using kernel_dse.cpp for analysis[/dim]")
        else:
            kernel_code = design.read_kernel()
        top = detect_top_function(kernel_code)

        sweep_dict = {}
        for spec in sweep:
            name, values = _parse_sweep_string(spec)
            sweep_dict[name] = values

        configs = generate_configs(kernel_code, top, sweep=sweep_dict, max_configs=max_configs)

        if not configs:
            console.print("[yellow]No configurations generated.[/yellow]")
            raise SystemExit(1)

        base_header = load_base_header(design.root, top, prefer_dse=has_dse_kernel)
        paths = write_configs(configs, design.configs_dir, base_header=base_header)

        console.print(f"\n[bold]Generated {len(paths)} configuration(s) (sweep)[/bold]")
        for p in paths:
            console.print(f"  [cyan]{p.name}[/cyan]")
        console.print(f"\n  Written to: {design.configs_dir}")
    else:
        # ── LLM-based intelligent generation ──
        from hlscribe.project import Project
        from hlscribe.config import load_config, PROVIDERS

        try:
            project = Project.find(Path.cwd())
        except FileNotFoundError:
            console.print("[red]Not inside an hlscribe project (no hlscribe.yaml found).[/red]")
            raise SystemExit(1)

        cfg = load_config(project_dir=project.root)

        if provider:
            if provider not in PROVIDERS:
                console.print(f"[red]Unknown provider: {provider}. Choose from: {', '.join(PROVIDERS)}[/red]")
                raise SystemExit(1)
            import os
            prov = PROVIDERS[provider]
            api_key = os.environ.get(prov["key_env"], "")
            if not api_key:
                console.print(f"[red]{prov['key_env']} not set.[/red]")
                raise SystemExit(1)
            cfg.llm.provider = provider
            cfg.llm.api_key = api_key
            cfg.llm.api_base = prov["api_base"]
            if not model:
                cfg.llm.model = prov["default_model"]
        if model:
            cfg.llm.model = model
        if no_rag:
            cfg.no_rag = True

        ont = None
        try:
            from hlscribe.ontology import load_ontology
            ont = load_ontology()
        except (FileNotFoundError, Exception):
            pass

        from hlscribe.workflows.dse_flow import run_dse_gen

        run_dse_gen(
            project, design, cfg, console,
            num_configs=num_configs, ont=ont,
        )


# ── Helpers ──


def _select_platform():
    """Interactive platform selection menu."""
    from hlscribe.platforms import list_by_category

    console.print("\n[bold]FPGA Platform Selection[/bold]\n")

    idx = 1
    index_map = {}
    for cat_key, cat_name, platforms in list_by_category():
        console.print(f"  [bold]{cat_name}[/bold]")
        for p in platforms:
            console.print(f"    {idx:>2}. {p.name:<30} {p.summary()}")
            index_map[str(idx)] = p
            idx += 1
        console.print()

    while True:
        choice = click.prompt("Select platform", default="1")
        if choice in index_map:
            selected = index_map[choice]
            console.print(f"\n  [cyan]Selected: {selected.name}[/cyan]")
            return selected
        console.print(f"  [red]Invalid choice: {choice}[/red]")

"""Shared LLM helpers — chat_once() and load_template()."""

from __future__ import annotations

import time
from pathlib import Path

from hlscribe.config import AppConfig
from hlscribe import usage as _usage

_PROMPTS_DIR = Path(__file__).parent / "prompts"


def load_template(name: str, project_root: Path | None = None) -> str:
    """Load a prompt template, searching project prompts/ first, then package.

    Search order:
      1. <project_root>/prompts/<name>  (user customizations)
      2. <package>/hlscribe/prompts/<name>  (built-in defaults)
    """
    if project_root is not None:
        project_path = project_root / "prompts" / name
        if project_path.exists():
            return project_path.read_text()

    package_path = _PROMPTS_DIR / name
    if package_path.exists():
        return package_path.read_text()

    searched = []
    if project_root is not None:
        searched.append(str(project_root / "prompts"))
    searched.append(str(_PROMPTS_DIR))
    raise FileNotFoundError(
        f"Prompt template '{name}' not found. Searched: {', '.join(searched)}"
    )


def chat_once(
    cfg: AppConfig,
    system_prompt: str,
    history: list[dict],
    user_message: str,
    max_tokens: int | None = None,
    tag: str = "untagged",
) -> str:
    """Send one chat turn and return the assistant response text.

    `tag` labels this call for the usage log (e.g. "arch", "codegen-kernel",
    "fix-loop-r1"). If no usage sink is configured, the tag is ignored.
    """
    history.append({"role": "user", "content": user_message})

    tokens = max_tokens or cfg.llm.max_tokens
    started = time.perf_counter()

    if cfg.llm.provider == "anthropic":
        import anthropic

        client = anthropic.Anthropic(api_key=cfg.llm.api_key)
        response = client.messages.create(
            model=cfg.llm.model,
            max_tokens=tokens,
            temperature=cfg.llm.temperature,
            system=system_prompt,
            messages=history,
        )
        reply = response.content[0].text
        usage_dict = _usage.extract_anthropic_usage(response)
        generation_id = getattr(response, "id", None)
    else:
        # OpenRouter / OpenAI (OpenAI-compatible API)
        import openai

        client = openai.OpenAI(
            api_key=cfg.llm.api_key,
            base_url=cfg.llm.api_base,
        )
        messages = [{"role": "system", "content": system_prompt}] + history

        # Optional reasoning/thinking effort. OpenRouter normalizes this
        # parameter across providers (Anthropic extended thinking, OpenAI
        # o-series, Gemini thinking, DeepSeek-R1 reasoning). Models that
        # don't support reasoning silently ignore it.
        extra_kwargs: dict = {}
        if cfg.llm.reasoning:
            extra_kwargs["extra_body"] = {
                "reasoning": {"effort": cfg.llm.reasoning}
            }

        response = client.chat.completions.create(
            model=cfg.llm.model,
            max_tokens=tokens,
            temperature=cfg.llm.temperature,
            messages=messages,
            **extra_kwargs,
        )
        if not response.choices:
            err = getattr(response, "error", None)
            raise RuntimeError(
                f"LLM returned no choices (model={cfg.llm.model}, "
                f"upstream_error={err!r}). OpenRouter may have wrapped a "
                f"provider error or content-filter result."
            )
        reply = response.choices[0].message.content
        if reply is None:
            finish = response.choices[0].finish_reason or "unknown"
            raise RuntimeError(
                f"LLM returned empty response (finish_reason={finish}, "
                f"model={cfg.llm.model}). The prompt may exceed the model's "
                f"output token limit or the request was filtered."
            )
        usage_dict = _usage.extract_openai_usage(response)
        generation_id = getattr(response, "id", None)

    duration_s = time.perf_counter() - started

    cost = _usage.estimate_cost(
        provider=cfg.llm.provider,
        model=cfg.llm.model,
        input_tokens=usage_dict["input_tokens"],
        output_tokens=usage_dict["output_tokens"],
        cache_read_tokens=usage_dict["cache_read_tokens"],
        cache_creation_tokens=usage_dict["cache_creation_tokens"],
    )
    _usage.record(_usage.UsageRecord(
        timestamp=_usage.now_iso(),
        tag=tag,
        provider=cfg.llm.provider,
        model=cfg.llm.model,
        input_tokens=usage_dict["input_tokens"],
        output_tokens=usage_dict["output_tokens"],
        cache_read_tokens=usage_dict["cache_read_tokens"],
        cache_creation_tokens=usage_dict["cache_creation_tokens"],
        cost_usd=cost,
        cost_source="estimated" if cost is not None else "unknown",
        duration_s=round(duration_s, 3),
        generation_id=generation_id,
    ))

    history.append({"role": "assistant", "content": reply})
    return reply

"""Extract C++ code blocks and DSE config blocks from LLM markdown responses."""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# Fenced code block: ```lang\ncode\n```
_CODE_BLOCK_RE = re.compile(
    r"```(\w*)\s*\n(.*?)```",
    re.DOTALL,
)

# Lines that indicate a diff block (not valid source code)
_DIFF_MARKERS = re.compile(r"^[+\-@]{2,}", re.MULTILINE)


@dataclass
class ExtractedCode:
    """A single extracted code block."""

    code: str
    language: str  # "cpp", "c++", "c", "" etc.


def extract_code_blocks(text: str) -> list[ExtractedCode]:
    """Extract all fenced code blocks from markdown text.

    Skips diff-format blocks (lines starting with +/-/@@).
    """
    results: list[ExtractedCode] = []
    for match in _CODE_BLOCK_RE.finditer(text):
        lang = match.group(1).lower()
        code = match.group(2)
        # Reject diff blocks
        if _DIFF_MARKERS.search(code):
            continue
        results.append(ExtractedCode(code=code.strip(), language=lang))
    return results


@dataclass
class ExtractedConfig:
    """A single DSE configuration extracted from LLM response."""

    name: str  # from ### heading
    strategy: str = ""  # "conservative", "moderate", "aggressive"
    rationale: str = ""  # from **Rationale**: line
    directives: list[str] = field(default_factory=list)  # from ```cfg block


# Heading pattern: ### opt1: Pipeline everything  or  ### 1. Pipeline everything
_CONFIG_HEADING_RE = re.compile(
    r"^###\s+(?:\w+[\.:]\s*)?(.+)",
    re.MULTILINE,
)

# Strategy line: **Strategy**: conservative
_STRATEGY_RE = re.compile(
    r"\*\*Strategy\*\*\s*:\s*(\w+)",
    re.IGNORECASE,
)

# Rationale line: **Rationale**: Start with baseline pipelining.
_RATIONALE_RE = re.compile(
    r"\*\*Rationale\*\*\s*:\s*(.+)",
    re.IGNORECASE,
)

# Cfg fenced block
_CFG_BLOCK_RE = re.compile(
    r"```cfg\s*\n(.*?)```",
    re.DOTALL,
)


def extract_cfg_blocks(text: str) -> list[ExtractedConfig]:
    """Parse LLM response into DSE config entries.

    Expected format per config:
        ### opt1: Pipeline everything
        **Strategy**: conservative
        **Rationale**: Start with baseline pipelining.

        ```cfg
        syn.directive.pipeline=kernel_top/MAIN II=1
        ```

    Lenient parsing — falls back to config_N names if headings are missing.
    """
    # Split on ### headings to get sections
    heading_matches = list(_CONFIG_HEADING_RE.finditer(text))
    cfg_matches = list(_CFG_BLOCK_RE.finditer(text))

    if not cfg_matches:
        return []

    configs: list[ExtractedConfig] = []

    if heading_matches and len(heading_matches) >= len(cfg_matches):
        # Match each cfg block to its preceding heading
        for i, cfg_match in enumerate(cfg_matches):
            cfg_start = cfg_match.start()

            # Find the closest preceding heading
            name = f"config_{i + 1}"
            section_text = ""
            for j, hm in enumerate(heading_matches):
                if hm.start() < cfg_start:
                    next_heading_start = (
                        heading_matches[j + 1].start()
                        if j + 1 < len(heading_matches)
                        else len(text)
                    )
                    if cfg_start < next_heading_start:
                        name = hm.group(1).strip()
                        section_text = text[hm.end():cfg_start]
                        break

            # Parse strategy and rationale from section text
            strategy = ""
            rationale = ""
            sm = _STRATEGY_RE.search(section_text)
            if sm:
                strategy = sm.group(1).strip().lower()
            rm = _RATIONALE_RE.search(section_text)
            if rm:
                rationale = rm.group(1).strip()

            # Parse directives from cfg block
            raw = cfg_match.group(1).strip()
            directives = [
                line.strip()
                for line in raw.splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]

            # Sanitize name for filename
            safe_name = re.sub(r"[^\w\-]", "_", name.lower()).strip("_")
            safe_name = re.sub(r"_+", "_", safe_name)

            configs.append(ExtractedConfig(
                name=safe_name,
                strategy=strategy,
                rationale=rationale,
                directives=directives,
            ))
    else:
        # No headings or mismatch — use positional names
        for i, cfg_match in enumerate(cfg_matches):
            raw = cfg_match.group(1).strip()
            directives = [
                line.strip()
                for line in raw.splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]

            # Try to extract strategy/rationale from text before this block
            before = text[:cfg_match.start()]
            strategy = ""
            rationale = ""
            sm = _STRATEGY_RE.search(before[-500:] if len(before) > 500 else before)
            if sm:
                strategy = sm.group(1).strip().lower()
            rm = _RATIONALE_RE.search(before[-500:] if len(before) > 500 else before)
            if rm:
                rationale = rm.group(1).strip()

            configs.append(ExtractedConfig(
                name=f"config_{i + 1}",
                strategy=strategy,
                rationale=rationale,
                directives=directives,
            ))

    return configs


def extract_first_code_block(text: str) -> str | None:
    """Extract the first C/C++ code block. Returns None if not found.

    Prefers blocks tagged as cpp/c++/c, falls back to untagged blocks.
    """
    blocks = extract_code_blocks(text)
    if not blocks:
        return None

    # Prefer C++ tagged blocks
    for block in blocks:
        if block.language in ("cpp", "c++", "c"):
            return block.code

    # Fall back to first untagged block
    for block in blocks:
        if block.language == "":
            return block.code

    # Last resort: first block regardless of language
    return blocks[0].code


def extract_first_markdown_block(text: str) -> str | None:
    """Extract first markdown/untagged code block, or return raw text.

    Search order:
      1. ```markdown ... ``` fenced block
      2. Untagged ``` ... ``` block
      3. Raw text (stripped) if non-empty

    Returns None if the input is empty/whitespace.
    """
    if not text or not text.strip():
        return None

    # 1. Try ```markdown fenced block
    for match in _CODE_BLOCK_RE.finditer(text):
        if match.group(1).lower() in ("markdown", "md"):
            content = match.group(2).strip()
            if content:
                return content

    # 2. Try untagged fenced block
    for match in _CODE_BLOCK_RE.finditer(text):
        if match.group(1) == "":
            content = match.group(2).strip()
            if content:
                return content

    # 3. Raw text (strip outer whitespace)
    stripped = text.strip()
    return stripped if stripped else None

#ifndef KERNEL_CFG_H_
#define KERNEL_CFG_H_

#ifndef N1ONLY
#define N1ONLY 1
#endif
#ifndef RT
#define RT 4
#endif
#ifndef NT
#define NT 32
#endif
#ifndef LACC
#define LACC 8
#endif
#ifndef RG
#define RG 64
#endif
#ifndef GV_MODE
#define GV_MODE 2
#endif
#ifndef GV_FIFO
#define GV_FIFO 128
#endif
#ifndef CP
#define CP 2
#endif
#ifndef ZINIT
#define ZINIT 1
#endif
#ifndef ACC_STYLE
#define ACC_STYLE 0
#endif
#ifndef USE_DATAFLOW
#define USE_DATAFLOW 1
#endif
#ifndef WIDEN
#define WIDEN 512
#endif
#ifndef BURST
#define BURST 128
#endif
#ifndef OUTSTANDING
#define OUTSTANDING 32
#endif
#ifndef BBURST
#define BBURST 8
#endif
#ifndef BOUT
#define BOUT 64
#endif

#endif

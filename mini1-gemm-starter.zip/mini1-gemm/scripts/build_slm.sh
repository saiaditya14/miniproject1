#!/usr/bin/env bash
# build_slm.sh — build the SLM with YOUR GEMM plugged in, and prove it still writes.
#
#   ./scripts/build_slm.sh                        # uses the reference GEMM
#   GEMM_SRC=path/to/your_gemm.c ./scripts/build_slm.sh
#
# Produces build/llama2.c/run_slm. With the reference GEMM the output is byte-for-byte
# identical to stock `run` — proving the plug-in seam is transparent. Swap in your own
# student_gemm and the story is the model's; only the speed changes.
set -euo pipefail
source "$(dirname "$0")/lib.sh"
need_model

GEMM_SRC="${GEMM_SRC:-$LAB/src/student_gemm_ref.c}"
make_run_slm
echo "[slm] building run_slm with $(basename "$GEMM_SRC") ..."
gcc -O3 -o "$LLAMA/run_slm" "$LLAMA/run_slm.c" "$LAB/src/slm_backend.c" "$GEMM_SRC" -I"$LAB/src" -lm

echo "[slm] verifying the plug-in is transparent (story vs stock run) ..."
A=$("$LLAMA/run"     "$MODEL" -t 0.0 -s 42 -n 128 -i "Once upon a time" 2>/dev/null) || \
A=$(cd "$LLAMA" && ./run     "$MODEL" -t 0.0 -s 42 -n 128 -i "Once upon a time")
B=$(cd "$LLAMA" && ./run_slm "$MODEL" -t 0.0 -s 42 -n 128 -i "Once upon a time")
if [ "$A" = "$B" ]; then echo "[slm] IDENTICAL — the model runs through your GEMM seam."
else echo "[slm] DIFFERENT — your GEMM changed the output (check correctness/tolerance)."; fi
echo
echo "run it:  (cd $LLAMA && ./run_slm $MODEL -t 0.8 -i \"Once upon a time\")"

#!/usr/bin/env bash
# synth_cases.sh — make synthetic float GEMM test cases for the target shapes.
#   ./scripts/synth_cases.sh                 # N = 1 and 32
#   NS="1 8 64" ./scripts/synth_cases.sh     # choose the batch widths
# No model needed — this is Part 1's self-contained test data. Pair with test_gemm.sh.
set -euo pipefail
source "$(dirname "$0")/lib.sh"

mkdir -p "$BUILD" "$LAB/cases"
gcc -O3 -o "$BUILD/synth_case" "$LAB/src/synth_case.c" -lm
NS="${NS:-1 32}"
# target shapes as "M K"  (out ← in): attn-proj, ffn-up, ffn-down, classifier
for MK in "288 288" "768 288" "288 768" "32000 288"; do
    set -- $MK; M=$1; K=$2
    for N in $NS; do
        "$BUILD/synth_case" "$M" "$K" "$N" "$LAB/cases/synth_${K}_to_${M}_N${N}.bin"
    done
done
echo "[synth] cases in $LAB/cases:"; ls -la "$LAB/cases"/synth_*.bin

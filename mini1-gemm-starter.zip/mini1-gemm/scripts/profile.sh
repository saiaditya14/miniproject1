#!/usr/bin/env bash
# profile.sh — measure where a token's time goes (matmul, by shape).
#   ./scripts/profile.sh
set -euo pipefail
source "$(dirname "$0")/lib.sh"
need_model

python3 "$LAB/scripts/mkprof.py" "$LLAMA/run.c" "$LLAMA/run_prof.c"
gcc -O3 -o "$LLAMA/run_prof" "$LLAMA/run_prof.c" -lm
echo "[profile] running 256 tokens (greedy) ..."
( cd "$LLAMA" && ./run_prof "$MODEL" -t 0.0 -s 42 -n 256 -i "Once upon a time" >/dev/null )   # cd: tokenizer.bin from CWD

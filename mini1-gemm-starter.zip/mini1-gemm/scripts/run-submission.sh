#!/usr/bin/env bash
# run-submission.sh — GRADER SIDE (run on node08, the U50 host). Unpack a student's
# submission, plug in their FPGA GEMM + xclbin, run the SLM on the U50, and capture
# the result to send back. Students never log in here — you run this for them.
#
#   U50_BDF=0000:02:00.1 ./scripts/run-submission.sh path/to/submission-<roll>.tar.gz
#
# U50_BDF defaults to 0000:02:00.1 (the U50; node08's index 0 is the VCK5000).
# Writes results-<roll>.txt (tok/s + the generated story) next to the tarball.
set -euo pipefail
source "$(dirname "$0")/lib.sh"
need_model
: "${U50_BDF:=0000:02:00.1}"; export U50_BDF

TARBALL="${1:?usage: run-submission.sh <submission-<roll>.tar.gz>}"
[ -f "$TARBALL" ] || { echo "error: no such tarball: $TARBALL" >&2; exit 1; }
TARBALL="$(cd "$(dirname "$TARBALL")" && pwd)/$(basename "$TARBALL")"   # absolutize

WORK="$(mktemp -d)"
tar -xzf "$TARBALL" -C "$WORK"
SUB="$(echo "$WORK"/submission-*)"
[ -d "$SUB" ] || { echo "error: bundle has no submission-* directory" >&2; rm -rf "$WORK"; exit 1; }
echo "### manifest ###"; cat "$SUB/manifest.txt"; echo "#################"; echo

ROLL="$(sed -n 's/^roll=//p' "$SUB/manifest.txt")"
XCLBIN="$SUB/$(sed -n 's/^xclbin=//p' "$SUB/manifest.txt")"
[ -f "$SUB/student_gemm_fpga.cpp" ] || { echo "error: student_gemm_fpga.cpp missing in bundle" >&2; rm -rf "$WORK"; exit 1; }
[ -f "$XCLBIN" ] || { echo "error: xclbin missing in bundle" >&2; rm -rf "$WORK"; exit 1; }

# Swap the student's host offload in for the template, run, then always restore it.
FPGA="$LAB/src/student_gemm_fpga.cpp"
cp "$FPGA" "$FPGA.grader-bak"
trap 'mv -f "$FPGA.grader-bak" "$FPGA" 2>/dev/null || true; rm -rf "$WORK"' EXIT
cp "$SUB/student_gemm_fpga.cpp" "$FPGA"

OUT="$(dirname "$TARBALL")/results-${ROLL:-unknown}.txt"
echo "### running on the U50 (BDF $U50_BDF) ..."
# run_hw.sh sources the toolchain, builds run_fpga (run_slm + slm_backend + the
# student's fpga.cpp) against XRT, and runs it on the card.
GEMM_XCLBIN="$XCLBIN" "$LAB/scripts/run_hw.sh" 2>&1 | tee "$OUT"
echo
echo "### wrote $OUT — send this back to the student."

#!/usr/bin/env bash
# hw-status.sh — check your hardware-run submissions / results from the terminal.
#
#   HW_TOKEN=<token> HW_PORTAL=<url> ./scripts/hw-status.sh            # list your submissions
#   HW_TOKEN=<token> HW_PORTAL=<url> ./scripts/hw-status.sh <subid>    # print one run's results
set -euo pipefail
: "${HW_TOKEN:?set HW_TOKEN to your personal token}"
: "${HW_PORTAL:?set HW_PORTAL to the portal URL}"

if [ "$#" -ge 1 ]; then
    curl -fsS -H "Authorization: Bearer $HW_TOKEN" "$HW_PORTAL/api/results/$1"
else
    curl -fsS -H "Authorization: Bearer $HW_TOKEN" "$HW_PORTAL/api/submissions"
    echo
fi

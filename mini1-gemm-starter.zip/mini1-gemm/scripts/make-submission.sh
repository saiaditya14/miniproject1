#!/usr/bin/env bash
# make-submission.sh — package your built hardware GEMM for the U50 run.
#
# You do NOT need an account on node08 (the U50 host). You build the .xclbin here
# on RCE (build_xclbin.sbatch), package it with this script, hand the bundle in,
# and the grader runs it on the U50 and sends the results back.
#
#   XCLBIN=build_hw/gemm_hw.xclbin ./scripts/make-submission.sh <your-roll-no> [kernel_top]
#
# Produces submission-<roll>.tar.gz containing exactly what node08 needs:
#   student_gemm_fpga.cpp   your XRT host offload (must match your kernel's args)
#   <name>.xclbin           your built hw bitstream
#   manifest.txt            roll, kernel top name, build time, sha256 checksums
set -euo pipefail
source "$(dirname "$0")/lib.sh"

ROLL="${1:?usage: XCLBIN=path/to/your_hw.xclbin make-submission.sh <roll-no> [kernel_top]}"
KTOP="${2:-gemm}"
: "${XCLBIN:?set XCLBIN=path/to/your_hw.xclbin (from build_xclbin.sbatch, e.g. build_hw/gemm_hw.xclbin)}"
[ -f "$XCLBIN" ] || { echo "error: XCLBIN not found: $XCLBIN" >&2; exit 1; }

FPGA_SRC="$LAB/src/student_gemm_fpga.cpp"
[ -f "$FPGA_SRC" ] || { echo "error: $FPGA_SRC missing (this is your host offload)" >&2; exit 1; }

STAGE="$(mktemp -d)/submission-$ROLL"
mkdir -p "$STAGE"
cp "$FPGA_SRC" "$STAGE/student_gemm_fpga.cpp"
cp "$XCLBIN"   "$STAGE/$(basename "$XCLBIN")"

{
    echo "roll=$ROLL"
    echo "kernel_top=$KTOP"
    echo "xclbin=$(basename "$XCLBIN")"
    echo "fpga_src=student_gemm_fpga.cpp"
    echo "built=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "sha256:"
    ( cd "$STAGE" && sha256sum student_gemm_fpga.cpp "$(basename "$XCLBIN")" | sed 's/^/  /' )
} > "$STAGE/manifest.txt"

OUT="$LAB/submission-$ROLL.tar.gz"
tar -czf "$OUT" -C "$(dirname "$STAGE")" "submission-$ROLL"
echo "[submit] wrote $OUT"
echo "[submit] contents:"; tar -tzf "$OUT" | sed 's/^/  /'
echo
echo "Hand $OUT in (Moodle upload, or copy to the shared submissions dir your"
echo "course gives you). It carries only your host code + bitstream — not build/"
echo "or the model, which the grader already has on node08."

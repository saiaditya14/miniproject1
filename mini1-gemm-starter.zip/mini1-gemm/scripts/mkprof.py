#!/usr/bin/env python3
"""mkprof.py IN.c OUT.c — patch llama2.c's run.c to time matmul by shape.

Wraps matmul() with a per-(n,d) timer and dumps a table at exit. Used by
scripts/profile.sh; you never call this directly.
"""
import sys

if len(sys.argv) != 3:
    sys.exit("usage: mkprof.py run.c run_prof.c")
src = open(sys.argv[1]).read()

SIG = "void matmul(float* xout, float* x, float* w, int n, int d) {"
if SIG not in src:
    sys.exit("matmul signature not found — llama2.c changed upstream?")

INJECT = r"""
/* ---- profile instrumentation (added by mkprof.py) ---- */
#include <time.h>
typedef struct { int n, d; long calls; double secs; } mm_bucket;
static mm_bucket MMB[32]; static int MMB_N = 0; static double MM_TOTAL = 0;
static double mm_now(void){ struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return t.tv_sec + t.tv_nsec*1e-9; }
static void mm_record(int n,int d,double dt){
    MM_TOTAL += dt;
    for(int i=0;i<MMB_N;i++) if(MMB[i].n==n&&MMB[i].d==d){ MMB[i].calls++; MMB[i].secs+=dt; return; }
    if(MMB_N<32){ MMB[MMB_N].n=n; MMB[MMB_N].d=d; MMB[MMB_N].calls=1; MMB[MMB_N].secs=dt; MMB_N++; }
}
static void mm_dump(void){
    fprintf(stderr,"\n=== matmul profile (by shape n->d) ===\n");
    fprintf(stderr,"total matmul time: %.4f s\n", MM_TOTAL);
    for(int a=0;a<MMB_N;a++){ int m=a; for(int b=a+1;b<MMB_N;b++) if(MMB[b].secs>MMB[m].secs) m=b;
        mm_bucket t=MMB[a]; MMB[a]=MMB[m]; MMB[m]=t; }
    for(int i=0;i<MMB_N;i++){ double fl = 2.0*MMB[i].n*MMB[i].d*MMB[i].calls;
        fprintf(stderr,"  %5d -> %5d  calls=%-6ld  %.4f s  (%5.1f%%)  %.2f GFLOP\n",
            MMB[i].n, MMB[i].d, MMB[i].calls, MMB[i].secs,
            MM_TOTAL>0?100.0*MMB[i].secs/MM_TOTAL:0.0, fl/1e9); }
}
void matmul_impl(float*,float*,float*,int,int);
void matmul(float* xout, float* x, float* w, int n, int d){
    double t0=mm_now(); matmul_impl(xout,x,w,n,d); mm_record(n,d,mm_now()-t0);
}
/* ---- end instrumentation ---- */
"""

src = src.replace(SIG, INJECT + "\nvoid matmul_impl(float* xout, float* x, float* w, int n, int d) {", 1)
src = src.replace("int main(int argc, char *argv[]) {",
                  "int main(int argc, char *argv[]) {\n    atexit(mm_dump);", 1)
open(sys.argv[2], "w").write(src)
print("wrote", sys.argv[2])

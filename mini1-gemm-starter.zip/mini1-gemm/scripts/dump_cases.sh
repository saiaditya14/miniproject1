#!/usr/bin/env bash
# dump_cases.sh — capture real model matmuls to cases/*.bin for offline GEMM testing.
#   ./scripts/dump_cases.sh
# Produces one case per distinct shape (classifier, FFN up/down, attn proj).
set -euo pipefail
source "$(dirname "$0")/lib.sh"
need_model

mkdir -p "$LAB/cases"
make_run_slm
gcc -O3 -o "$LLAMA/run_dump" "$LLAMA/run_slm.c" "$LAB/src/dump_backend.c" -I"$LAB/src" -lm
echo "[dump] generating a few tokens to capture every shape ..."
( cd "$LLAMA" && CASES_DIR="$LAB/cases" ./run_dump "$MODEL" -t 0.0 -s 42 -n 4 -i "Once upon a time" >/dev/null )
echo "[dump] cases in $LAB/cases:"
ls -la "$LAB/cases"
echo "[dump] note: cases/*.bin are large (the classifier weight is ~37MB) and are gitignored."

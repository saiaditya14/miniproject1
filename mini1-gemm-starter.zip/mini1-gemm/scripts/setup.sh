#!/usr/bin/env bash
# setup.sh — clone llama2.c, fetch the TinyStories checkpoint, build, print a story.
#
#   ./scripts/setup.sh
#
# Offline cluster (no outbound internet on the compute node)? Stage the checkpoint
# on shared /home once and point setup at it — it symlinks instead of downloading:
#   STORIES_DIR=/home/<course>/models ./scripts/setup.sh
# Bigger model?  MODEL=stories42M.bin ./scripts/setup.sh
set -euo pipefail
source "$(dirname "$0")/lib.sh"

mkdir -p "$BUILD"
if [ ! -d "$LLAMA" ]; then
    echo "[setup] cloning llama2.c ..."
    git clone --depth 1 https://github.com/karpathy/llama2.c.git "$LLAMA"
fi

echo "[setup] building run + runq ..."
gcc -O3 -o "$LLAMA/run"  "$LLAMA/run.c"  -lm
gcc -O3 -o "$LLAMA/runq" "$LLAMA/runq.c" -lm

get_model() {
    local m="$1"
    [ -f "$LLAMA/$m" ] && { echo "[setup] have $m"; return 0; }
    if [ -n "${STORIES_DIR:-}" ] && [ -f "$STORIES_DIR/$m" ]; then
        echo "[setup] linking $m from $STORIES_DIR"; ln -sf "$STORIES_DIR/$m" "$LLAMA/$m"; return 0
    fi
    echo "[setup] downloading $m (~60MB for 15M) ..."
    wget -q "https://huggingface.co/karpathy/tinyllamas/resolve/main/$m" -O "$LLAMA/$m"
}
get_model "$MODEL"

echo "[setup] sample story:"
( cd "$LLAMA" && ./run "$MODEL" -t 0.0 -s 42 -n 96 -i "Once upon a time" )   # cd: tokenizer.bin is resolved from CWD
echo
echo "[setup] done. Next: scripts/profile.sh  (see where the time goes)"

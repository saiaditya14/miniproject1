#!/usr/bin/env bash
# run_hw.sh — run the SLM with your FPGA GEMM on the U50 host.
#
#   U50_BDF=<pcie-addr> GEMM_XCLBIN=path/to/your.xclbin ./scripts/run_hw.sh
#
# Builds run_fpga (run_slm.c + slm_backend.c + student_gemm_fpga.cpp, linked to XRT)
# and runs it on the U50. Opens the card by its PCIe address (BDF) via U50_BDF; if the
# host has multiple accelerators, device index 0 may be a different card. Set U50_BDF
# to your card's address (see the course starter kit).
set -euo pipefail
source "$(dirname "$0")/lib.sh"
need_model
: "${GEMM_XCLBIN:?set GEMM_XCLBIN=path/to/your.xclbin}"
: "${U50_BDF:?set U50_BDF to your U50 PCIe address, the BDF (see the course starter kit)}"
export U50_BDF

# Vitis + XRT environment (self-contained; same paths as the HLS labs' env.sh).
source "$(dirname "$0")/env-hw.sh"
: "${XILINX_XRT:?XRT not set — did env-hw.sh source /opt/xilinx/xrt/setup.sh?}"

make_run_slm
echo "[hw] building run_fpga (XRT) ..."
g++ -std=c++17 -O3 -o "$LLAMA/run_fpga" \
    "$LLAMA/run_slm.c" "$LAB/src/slm_backend.c" "$LAB/src/student_gemm_fpga.cpp" \
    -I"$LAB/src" -I"$XILINX_XRT/include" -L"$XILINX_XRT/lib" -lxrt_coreutil -lpthread -lm

echo "[hw] running on U50 (BDF $U50_BDF) ..."
( cd "$LLAMA" && GEMM_XCLBIN="$GEMM_XCLBIN" ./run_fpga "$MODEL" -t 0.0 -s 42 -n 256 -i "Once upon a time" )

#!/usr/bin/env bash
# test_gemm_int8.sh — test YOUR int8 GEMM against a built-in golden, over the 4 shapes.
#   ./scripts/test_gemm_int8.sh                       # reference impl, N=1
#   N=32 ./scripts/test_gemm_int8.sh                  # batched
#   GEMM_INT8_SRC=path/to/your_int8.c ./scripts/test_gemm_int8.sh
set -euo pipefail
source "$(dirname "$0")/lib.sh"

GEMM_INT8_SRC="${GEMM_INT8_SRC:-$LAB/src/student_gemm_int8_ref.c}"
mkdir -p "$BUILD"
echo "[int8] building gemm_test_int8 with $(basename "$GEMM_INT8_SRC") ..."
gcc -O3 -o "$BUILD/gemm_test_int8" "$LAB/src/gemm_test_int8.c" "$GEMM_INT8_SRC" -I"$LAB/src" -lm
"$BUILD/gemm_test_int8" "${N:-1}" "${GS:-32}"

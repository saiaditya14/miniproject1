# lib.sh — shared paths and helpers for the TinyStories scripts. Sourced, not run.
#
#   LAB    = labs/tinystories            (this lab)
#   BUILD  = $LAB/build                  (all generated artifacts live here)
#   LLAMA  = $BUILD/llama2.c             (the cloned engine + weights)
#   MODEL  = checkpoint name             (override: MODEL=stories42M.bin)

LAB="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$LAB/build"
LLAMA="$BUILD/llama2.c"
MODEL="${MODEL:-stories15M.bin}"

# Patch run.c -> run_slm.c with the built-in matmul renamed out of the way, so an
# external matmul() (slm_backend.c / dump_backend.c) takes over. The internal
# matmul() call sites in forward() then bind to the external symbol at link time.
make_run_slm() {
    sed 's/^void matmul(float\* xout, float\* x, float\* w, int n, int d) {/__attribute__((unused)) static void matmul_STOCK(float* xout, float* x, float* w, int n, int d) {/' \
        "$LLAMA/run.c" > "$LLAMA/run_slm.c"
}

need_model() {
    [ -f "$LLAMA/$MODEL" ] && return 0
    echo "error: $LLAMA/$MODEL not found — run scripts/setup.sh first" >&2
    exit 1
}

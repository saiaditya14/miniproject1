#!/usr/bin/env bash
# test_gemm.sh — test YOUR GEMM (a CPU implementation) against real model matmuls.
#
#   ./scripts/test_gemm.sh                       # tests the reference impl
#   GEMM_SRC=path/to/your_gemm.c ./scripts/test_gemm.sh
#
# This is the offline inner loop: no model, no XRT — just your student_gemm() vs the
# model's own outputs. (For an HLS kernel, validate via cosim in your gemm lab using
# these same cases; this tester is for CPU-side algorithm work.)
set -euo pipefail
source "$(dirname "$0")/lib.sh"

GEMM_SRC="${GEMM_SRC:-$LAB/src/student_gemm_ref.c}"
if ! ls "$LAB"/cases/*.bin >/dev/null 2>&1; then
    echo "no cases yet — run scripts/dump_cases.sh first" >&2; exit 1
fi

echo "[test] building gemm_test with $(basename "$GEMM_SRC") ..."
gcc -O3 -o "$BUILD/gemm_test" "$LAB/src/gemm_test.c" "$GEMM_SRC" -I"$LAB/src" -lm
"$BUILD/gemm_test" "$LAB"/cases/*.bin

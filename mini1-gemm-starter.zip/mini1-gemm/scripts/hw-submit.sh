#!/usr/bin/env bash
# hw-submit.sh — build your submission bundle and upload it to the course HW portal.
# The instructor's node08 runs it on the U50 and the result appears on the portal.
# You never log in to node08 — your personal token is your access.
#
#   HW_TOKEN=<your-token> HW_PORTAL=https://<host>:<port> \
#   XCLBIN=build_hw/gemm_hw.xclbin ./scripts/hw-submit.sh <your-roll> [kernel_top]
#
# Prints your submission id and a portal link. Watch results there (auto-refreshes),
# or fetch them with scripts/hw-status.sh.
set -euo pipefail
HERE="$(dirname "$0")"
source "$HERE/lib.sh"

ROLL="${1:?usage: HW_TOKEN=.. HW_PORTAL=.. XCLBIN=.. hw-submit.sh <roll> [kernel_top]}"
KTOP="${2:-gemm}"
: "${HW_TOKEN:?set HW_TOKEN to your personal submission token (from the instructor)}"
: "${HW_PORTAL:?set HW_PORTAL to the portal URL, e.g. https://node08.iiit.ac.in:8080}"
: "${XCLBIN:?set XCLBIN=path/to/your_hw.xclbin (from build_xclbin.sbatch)}"

# Reuse make-submission.sh to build the exact bundle node08 knows how to run.
XCLBIN="$XCLBIN" "$HERE/make-submission.sh" "$ROLL" "$KTOP" >/dev/null
BUNDLE="$LAB/submission-$ROLL.tar.gz"
[ -f "$BUNDLE" ] || { echo "error: bundle not built: $BUNDLE" >&2; exit 1; }

echo "[hw-submit] uploading $(basename "$BUNDLE") ($(du -h "$BUNDLE" | cut -f1)) -> $HW_PORTAL ..."
resp="$(curl -fsS -X POST \
    -H "Authorization: Bearer $HW_TOKEN" \
    -H "Content-Type: application/gzip" \
    --data-binary @"$BUNDLE" \
    "$HW_PORTAL/api/submit?roll=$ROLL&kernel_top=$KTOP")" || {
        echo "error: upload failed — check HW_PORTAL / HW_TOKEN / network to node08" >&2; exit 1; }
echo "[hw-submit] $resp"
echo "[hw-submit] track it:  $HW_PORTAL/?token=$HW_TOKEN"

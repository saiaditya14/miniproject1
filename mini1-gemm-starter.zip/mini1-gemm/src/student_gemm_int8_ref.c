/* student_gemm_int8_ref.c — reference grouped-int8 GEMM (the default impl).
 *
 * Q8_0-style group quantization: the reduction dimension K is split into groups of
 * GS elements; each group carries int8 values plus one fp32 scale per operand. The
 * inner product is accumulated in int32 within a group (that is the integer speed
 * you are after), then scaled back to fp32 at the group boundary:
 *
 *   C[i,j] = Σ_g ( As[i,g] · Bs[g,j] · Σ_{k in group g} (int32) Aq[i,k] · Bq[k,j] )
 *
 * Layouts (all row-major, GS must divide K):
 *   Aq : M×K int8         As : M×(K/GS) fp32
 *   Bq : K×N int8         Bs : (K/GS)×N fp32
 *   C  : M×N fp32
 *
 * This is the behaviour your int8 kernel must match. Replace this file at link time
 * with your own student_gemm_int8; do not change the signature.
 */
#include "student_gemm_int8.h"

void student_gemm_int8(const int8_t *Aq, const float *As,
                       const int8_t *Bq, const float *Bs,
                       float *C, int M, int K, int N, int GS) {
    int nG = K / GS;                                   /* groups along K */
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            float acc = 0.0f;
            for (int g = 0; g < nG; g++) {
                int32_t dot = 0;                       /* int32 accumulate within group */
                int base = g * GS;
                for (int t = 0; t < GS; t++) {
                    int k = base + t;
                    dot += (int32_t)Aq[i * K + k] * (int32_t)Bq[k * N + j];
                }
                acc += As[i * nG + g] * Bs[g * N + j] * (float)dot;
            }
            C[i * N + j] = acc;
        }
    }
}

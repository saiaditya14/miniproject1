/* gemm_test.c — test YOUR GEMM against real matmuls from the TinyStories model.
 *
 * Usage:  ./gemm_test cases/*.bin
 *
 * Each case file is one matmul the model actually performed, captured by
 * scripts/dump_cases.sh. Layout (little-endian):
 *     int32  M, K, N
 *     float  A[M*K]        (row-major)   — a real weight matrix
 *     float  B[K*N]        (row-major)   — a real activation
 *     float  C[M*N]        (row-major)   — the model's own output (the golden)
 *
 * The tester links whatever student_gemm you compiled in (ref by default), runs it
 * on each case, and checks C against the golden with the same 1e-2 tolerance the
 * HLS labs use. It also reports GFLOP/s so you can watch your kernel get faster.
 *
 * This is your inner development loop: no model, no XRT, no weights to load — just
 * your kernel vs. ground truth. Get every case to PASS here before you touch the SLM.
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "student_gemm.h"

static double now(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

static int run_case(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", path); return 2; }
    int dims[3];
    if (fread(dims, sizeof(int), 3, f) != 3) { fclose(f); return 2; }
    int M = dims[0], K = dims[1], N = dims[2];
    long sA = (long)M * K, sB = (long)K * N, sC = (long)M * N;

    float *A = malloc(sA * sizeof(float));
    float *B = malloc(sB * sizeof(float));
    float *golden = malloc(sC * sizeof(float));
    float *C = calloc(sC, sizeof(float));
    if (fread(A, sizeof(float), sA, f) != (size_t)sA ||
        fread(B, sizeof(float), sB, f) != (size_t)sB ||
        fread(golden, sizeof(float), sC, f) != (size_t)sC) {
        fprintf(stderr, "short read in %s\n", path); fclose(f); return 2;
    }
    fclose(f);

    double t0 = now();
    student_gemm(A, B, C, M, K, N);
    double dt = now() - t0;

    int errors = 0;
    double max_abs = 0.0;
    for (long i = 0; i < sC; i++) {
        double e = fabs((double)C[i] - (double)golden[i]);
        if (e > max_abs) max_abs = e;
        if (e > 1e-2) errors++;
    }
    double gflops = (2.0 * M * K * N) / dt / 1e9;
    printf("  %-28s  M=%-6d K=%-5d N=%-3d  %s  max|err|=%.2e  %.3f ms  %6.2f GFLOP/s\n",
           path, M, K, N, errors ? "FAIL" : "PASS", max_abs, dt * 1e3, gflops);

    free(A); free(B); free(golden); free(C);
    return errors ? 1 : 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s cases/*.bin\n", argv[0]);
        return 2;
    }
    printf("=== testing student_gemm against %d GEMM case(s) ===\n", argc - 1);
    int fails = 0;
    for (int i = 1; i < argc; i++) fails += (run_case(argv[i]) != 0);
    printf("=== %s (%d/%d passed) ===\n", fails ? "FAIL" : "ALL PASS",
           (argc - 1) - fails, argc - 1);
    return fails ? 1 : 0;
}

/* student_gemm.h — THE contract.
 *
 * This is the one function you implement in this mini-project. The SAME function
 * is used two ways, with no changes:
 *
 *   1. Offline test  — `gemm_test` checks it against real matmuls dumped from the
 *                      TinyStories model (cases/*.bin), so you can develop your
 *                      kernel with zero model plumbing.
 *   2. The SLM        — `slm_backend.c` routes the model's matmul() straight to it,
 *                      so a correct kernel *is* a working accelerated language model.
 *
 * Semantics:  C[M*N] = A[M*K] · B[K*N]   (all row-major, float32, contiguous)
 *
 *   A : M×K   the left operand   (in the SLM this is the weight matrix W, d×n)
 *   B : K×N   the right operand  (in the SLM this is the activation(s), n×N)
 *   C : M×N   the result         (in the SLM this is the output, d×N)
 *
 * In single-token decode the SLM calls this with N = 1 (a GEMV). Batching and
 * prefill raise N — that is your throughput lever (see Part 2). Design your
 * kernel so the SAME entry point handles N = 1 and N > 1; the dims arrive at
 * runtime, so avoid baking them in as compile-time constants if you want one
 * bitstream for all four model shapes.
 *
 * A CPU reference implementation lives in student_gemm_ref.c so the whole pipeline
 * runs today. Replace it with your U50 version (an XRT host wrapper around your
 * kernel — see student_gemm_fpga.cpp) and nothing else changes.
 */
#ifndef STUDENT_GEMM_H_
#define STUDENT_GEMM_H_

#ifdef __cplusplus
extern "C" {
#endif

void student_gemm(const float *A, const float *B, float *C, int M, int K, int N);

#ifdef __cplusplus
}
#endif

#endif /* STUDENT_GEMM_H_ */

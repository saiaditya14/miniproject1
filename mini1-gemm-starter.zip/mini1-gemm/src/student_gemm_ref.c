/* student_gemm_ref.c — the reference CPU implementation of the contract.
 *
 * This exists so the whole codebase runs on day one: the offline tester passes and
 * the SLM generates stories, all before you have written a line of HLS. It is the
 * behaviour your kernel must match (within tolerance) and the baseline your kernel
 * must beat (once N is large enough — see Part 2).
 *
 * Replace this file at link time with your own implementation:
 *   - a better CPU version (blocking, OpenMP) to explore the algorithm, or
 *   - student_gemm_fpga.cpp, an XRT host wrapper around your U50 kernel.
 * Do NOT edit the signature — both the tester and the SLM depend on it.
 */
#include "student_gemm.h"

void student_gemm(const float *A, const float *B, float *C, int M, int K, int N) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            float acc = 0.0f;
            for (int k = 0; k < K; k++)
                acc += A[i * K + k] * B[k * N + j];
            C[i * N + j] = acc;
        }
    }
}

/* slm_backend.c — the one seam that plugs YOUR GEMM into the language model.
 *
 * scripts/build_slm.sh compiles a copy of llama2.c's run.c with its built-in
 * matmul() renamed out of the way, then links this file so every matmul the model
 * performs is routed to your student_gemm(). Nothing else in the model changes.
 *
 * The mapping (see student_gemm.h): the model computes
 *     xout[d] = W[d×n] · x[n]
 * which is exactly student_gemm with A = W (M=d, K=n), B = x (N=1), C = xout.
 */
#include "student_gemm.h"

void matmul(float *xout, float *x, float *w, int n, int d) {
    /* A = w (d×n) , B = x (n×1) , C = xout (d×1) */
    student_gemm(w, x, xout, /*M=*/d, /*K=*/n, /*N=*/1);
}

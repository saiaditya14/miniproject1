/* gemm_test_int8.c — self-contained correctness + speed test for YOUR int8 GEMM.
 *
 *   ./gemm_test_int8 [N] [GS]        (defaults: N=1, GS=32)
 *
 * Generates random grouped-int8 inputs for the four target shapes, computes a golden
 * with a built-in reference, runs the linked student_gemm_int8, checks they match,
 * and reports GOP/s. No model, no files — just your int8 kernel vs ground truth.
 * (GS must divide K; 32 divides both 288 and 768.)
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "student_gemm_int8.h"

static double now(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec * 1e-9;
}

/* built-in golden (independent of the student's impl) */
static void golden(const int8_t *Aq, const float *As, const int8_t *Bq, const float *Bs,
                   float *C, int M, int K, int N, int GS) {
    int nG = K / GS;
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            float acc = 0.0f;
            for (int g = 0; g < nG; g++) {
                int32_t dot = 0;
                for (int t = 0; t < GS; t++) { int k = g * GS + t;
                    dot += (int32_t)Aq[i * K + k] * (int32_t)Bq[k * N + j]; }
                acc += As[i * nG + g] * Bs[g * N + j] * (float)dot;
            }
            C[i * N + j] = acc;
        }
}

static int8_t rq(void) { return (int8_t)((rand() % 255) - 127); }
static float  rs(void) { return (float)((rand() / (double)RAND_MAX) * 0.05 + 1e-4); }

static int run_shape(const char *name, int M, int K, int N, int GS) {
    int nG = K / GS;
    long sA = (long)M * K, sB = (long)K * N;
    int8_t *Aq = malloc(sA), *Bq = malloc(sB);
    float  *As = malloc((long)M * nG * sizeof(float));
    float  *Bs = malloc((long)nG * N * sizeof(float));
    float  *Cg = malloc((long)M * N * sizeof(float));
    float  *Cs = malloc((long)M * N * sizeof(float));
    for (long i = 0; i < sA; i++) Aq[i] = rq();
    for (long i = 0; i < sB; i++) Bq[i] = rq();
    for (long i = 0; i < (long)M * nG; i++) As[i] = rs();
    for (long i = 0; i < (long)nG * N; i++) Bs[i] = rs();

    golden(Aq, As, Bq, Bs, Cg, M, K, N, GS);
    double t0 = now();
    student_gemm_int8(Aq, As, Bq, Bs, Cs, M, K, N, GS);
    double dt = now() - t0;

    double maxrel = 0.0; int bad = 0;
    for (long i = 0; i < (long)M * N; i++) {
        double e = fabs(Cs[i] - Cg[i]) / (fabs(Cg[i]) + 1e-6);
        if (e > maxrel) maxrel = e;
        if (e > 1e-4) bad++;
    }
    double gops = (2.0 * M * K * N) / dt / 1e9;
    printf("  %-14s M=%-6d K=%-5d N=%-3d GS=%d  %s  maxrel=%.1e  %.3f ms  %6.2f GOP/s\n",
           name, M, K, N, GS, bad ? "FAIL" : "PASS", maxrel, dt * 1e3, gops);
    free(Aq); free(Bq); free(As); free(Bs); free(Cg); free(Cs);
    return bad ? 1 : 0;
}

int main(int argc, char **argv) {
    int N  = argc > 1 ? atoi(argv[1]) : 1;
    int GS = argc > 2 ? atoi(argv[2]) : 32;
    srand(2025);
    printf("=== int8 GEMM test (N=%d, GS=%d) ===\n", N, GS);
    int f = 0;
    f += run_shape("attn-proj",  288,   288, N, GS);
    f += run_shape("ffn-up",     768,   288, N, GS);
    f += run_shape("ffn-down",   288,   768, N, GS);
    f += run_shape("classifier", 32000, 288, N, GS);
    printf("=== %s ===\n", f ? "FAIL" : "ALL PASS");
    return f ? 1 : 0;
}

/* synth_case.c — generate a synthetic GEMM test case (float) for a given shape.
 *
 *   ./synth_case M K N out.bin [seed]
 *
 * Writes the same case format gemm_test.c reads, so Part 1 needs no model at all:
 *     int32  M, K, N
 *     float  A[M*K]   random in [-1,1]        (row-major)
 *     float  B[K*N]   random in [-1,1]        (row-major)
 *     float  C[M*N]   = A·B computed in double (the golden)
 *
 * Use it to build cases for the exact shapes your kernel must handle, then run
 * gemm_test against them (scripts/synth_cases.sh does both).
 */
#include <stdio.h>
#include <stdlib.h>

static float frand(void) { return (float)((rand() / (double)RAND_MAX) * 2.0 - 1.0); }

int main(int argc, char **argv) {
    if (argc < 5) { fprintf(stderr, "usage: %s M K N out.bin [seed]\n", argv[0]); return 2; }
    int M = atoi(argv[1]), K = atoi(argv[2]), N = atoi(argv[3]);
    const char *out = argv[4];
    srand(argc > 5 ? atoi(argv[5]) : 1234);

    long sA = (long)M * K, sB = (long)K * N, sC = (long)M * N;
    float *A = malloc(sA * sizeof(float));
    float *B = malloc(sB * sizeof(float));
    float *C = malloc(sC * sizeof(float));
    for (long i = 0; i < sA; i++) A[i] = frand();
    for (long i = 0; i < sB; i++) B[i] = frand();

    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            double acc = 0.0;
            for (int k = 0; k < K; k++) acc += (double)A[i * K + k] * (double)B[k * N + j];
            C[i * N + j] = (float)acc;
        }

    FILE *f = fopen(out, "wb");
    if (!f) { fprintf(stderr, "cannot write %s\n", out); return 1; }
    int dims[3] = {M, K, N};
    fwrite(dims, sizeof(int), 3, f);
    fwrite(A, sizeof(float), sA, f);
    fwrite(B, sizeof(float), sB, f);
    fwrite(C, sizeof(float), sC, f);
    fclose(f);
    fprintf(stderr, "wrote %s  (M=%d K=%d N=%d)\n", out, M, K, N);
    return 0;
}

/* student_gemm_fpga.cpp — TEMPLATE: implement student_gemm() as an offload to YOUR
 * U50 kernel. This is the hardware seam. It is intentionally a skeleton — the kernel
 * is yours (from the classroom GEMM arc), and the interesting engineering (weight
 * residency, batching) is the point of Part 2. Fill the TODOs.
 *
 * Build with XRT (see scripts/run_hw.sh). The SAME student_gemm() contract as the
 * CPU reference — so `GEMM_SRC=src/student_gemm_fpga.cpp scripts/build_slm.sh` swaps
 * the CPU loop for real silicon with no other change.
 *
 * The two rules that decide whether tok/s goes up (Part 2):
 *   (1) Load each weight matrix into HBM ONCE (cache by pointer), not per call.
 *   (2) Only the activation (K×N in) and result (M×N out) cross PCIe per call.
 * A per-matmul offload with N=1 will LOSE to the CPU — that is the lesson. Raise N
 * (batch / prefill) so the resident weights are reused across many tokens.
 */
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <unordered_map>

#include "experimental/xrt_bo.h"
#include "experimental/xrt_device.h"
#include "experimental/xrt_kernel.h"

#include "student_gemm.h"

static xrt::device g_dev;
static xrt::kernel g_krnl;
static bool        g_ready = false;

// Cache: weight pointer (host) -> its resident device buffer, so W is uploaded once.
static std::unordered_map<const float *, xrt::bo> g_weights;

static void ensure_device() {
    if (g_ready) return;
    const char *xclbin = getenv("GEMM_XCLBIN");     // path to your built .xclbin
    const char *bdf    = getenv("U50_BDF");          // your card's PCIe address (BDF), NOT index 0
    if (!bdf) { fprintf(stderr, "set U50_BDF to your card's PCIe address (see the course starter kit)\n"); exit(1); }
    g_dev  = xrt::device(std::string(bdf));
    auto uuid = g_dev.load_xclbin(xclbin);
    g_krnl = xrt::kernel(g_dev, uuid, "gemm");        // TODO: your kernel's top name
    g_ready = true;
}

// Upload A (a weight matrix) to HBM the first time we see this pointer; reuse after.
static xrt::bo &resident_weight(const float *A, int M, int K) {
    auto it = g_weights.find(A);
    if (it != g_weights.end()) return it->second;
    xrt::bo bo(g_dev, sizeof(float) * (size_t)M * K, g_krnl.group_id(0));
    std::memcpy(bo.map<float *>(), A, sizeof(float) * (size_t)M * K);
    bo.sync(XCL_BO_SYNC_BO_TO_DEVICE);
    return g_weights.emplace(A, std::move(bo)).first->second;
}

extern "C" void student_gemm(const float *A, const float *B, float *C,
                             int M, int K, int N) {
    ensure_device();
    xrt::bo &bo_A = resident_weight(A, M, K);          // rule (1): weights stay in HBM

    xrt::bo bo_B(g_dev, sizeof(float) * (size_t)K * N, g_krnl.group_id(1));
    xrt::bo bo_C(g_dev, sizeof(float) * (size_t)M * N, g_krnl.group_id(2));
    std::memcpy(bo_B.map<float *>(), B, sizeof(float) * (size_t)K * N);
    bo_B.sync(XCL_BO_SYNC_BO_TO_DEVICE);

    // TODO: match your kernel's argument list (runtime M,K,N if you parameterized it).
    auto run = g_krnl(bo_A, bo_B, bo_C, M, K, N);
    run.wait();

    bo_C.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
    std::memcpy(C, bo_C.map<float *>(), sizeof(float) * (size_t)M * N);
}

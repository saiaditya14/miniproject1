/* dump_backend.c — capture real model matmuls to cases/*.bin for offline testing.
 *
 * Same plug-in mechanism as slm_backend.c, but this matmul() ALSO writes the first
 * occurrence of each distinct (n,d) shape to a case file the tester can replay:
 *     int32  M, K, N            (= d, n, 1)
 *     float  A[M*K]  = w        (the real weight matrix)
 *     float  B[K*N]  = x        (the real activation)
 *     float  C[M*N]  = xout     (the model's own output — the golden)
 *
 * Output dir is $CASES_DIR (default "cases"). One file per shape, e.g.
 *     cases/gemm_288_to_32000.bin   (the classifier)
 *     cases/gemm_288_to_768.bin     (FFN w1/w3)
 *     cases/gemm_768_to_288.bin     (FFN w2)
 *     cases/gemm_288_to_288.bin     (attn wq/wk/wv/wo)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SHAPES 32
static int seen_n[MAX_SHAPES], seen_d[MAX_SHAPES];
static int nseen = 0;

static const char *cases_dir(void) {
    const char *d = getenv("CASES_DIR");
    return d ? d : "cases";
}

static void dump_case(float *xout, float *x, float *w, int n, int d) {
    for (int i = 0; i < nseen; i++)
        if (seen_n[i] == n && seen_d[i] == d) return;   /* already captured */
    if (nseen < MAX_SHAPES) { seen_n[nseen] = n; seen_d[nseen] = d; nseen++; }

    char path[512];
    snprintf(path, sizeof(path), "%s/gemm_%d_to_%d.bin", cases_dir(), n, d);
    FILE *f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "dump: cannot write %s\n", path); return; }
    int dims[3] = {d, n, 1};                            /* M=d, K=n, N=1 */
    fwrite(dims, sizeof(int), 3, f);
    fwrite(w,    sizeof(float), (size_t)d * n, f);      /* A = W (d×n) */
    fwrite(x,    sizeof(float), (size_t)n,     f);      /* B = x (n×1) */
    fwrite(xout, sizeof(float), (size_t)d,     f);      /* C = xout    */
    fclose(f);
    fprintf(stderr, "dump: wrote %s  (M=%d K=%d N=1)\n", path, d, n);
}

void matmul(float *xout, float *x, float *w, int n, int d) {
    /* compute (reference) ... */
    for (int i = 0; i < d; i++) {
        float val = 0.0f;
        for (int j = 0; j < n; j++) val += w[i * n + j] * x[j];
        xout[i] = val;
    }
    /* ... then capture the first instance of this shape */
    dump_case(xout, x, w, n, d);
}

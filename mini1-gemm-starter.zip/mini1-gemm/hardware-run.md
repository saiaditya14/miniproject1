# Mini-Project 1 — Running on the U50 (course hardware handout)

> **This handout is for enrolled students only (distributed via Moodle).** It has
> the concrete steps and your personal token for our class hardware. It is **not**
> on the public course site.

You do **not** get an account on the U50 host. You compile your bitstream on the
RCE cluster (where you already have an account), submit it with a personal token,
and the result comes back to you on the portal. Building needs no FPGA; only the
final run does, and the course runs that for you.

---

## 1. Build your bitstream on RCE

Put your GEMM kernel from the classroom GEMM arc (top function `gemm`) at
`src/kernel.cpp`, then compile it to a `hw` `.xclbin` on the cluster (~1 h place &
route, no FPGA needed):

```bash
sbatch --export=ALL,TGT=hw scripts/build_xclbin.sbatch    # → build_hw/gemm_hw.xclbin
squeue -u $USER                                           # watch it
```

`student_gemm_fpga.cpp` is the host seam you fill in — offload `student_gemm` to your
kernel, keep the weights resident on the device, and cross the bus only with the
activation and result.

## 2. Submit it to the hardware portal

Your instructor gives you your **personal token** (keep it private — it is your
identity). The portal runs on the U50 host and you submit **from an RCE login shell**:

```bash
HW_TOKEN=<your-token> HW_PORTAL=http://node08:18080 \
XCLBIN=build_hw/gemm_hw.xclbin ./scripts/hw-submit.sh <your-rce-username>
```

This bundles your `student_gemm_fpga.cpp` + bitstream and uploads it. You get back a
submission id. (Use the exact portal URL your instructor gives — the token is the
same one they handed you privately; your `<your-rce-username>` is your RCE login.)

## 3. Get your results

The portal runs submissions on the U50 one at a time. When yours finishes it shows
your **generated story + achieved tok/s**:

- **Portal:** open `http://node08:18080/?token=<your-token>` — it auto-refreshes and
  lists your submissions with status and throughput.
- **Terminal:** `HW_TOKEN=<token> HW_PORTAL=http://node08:18080 ./scripts/hw-status.sh`
  (list) or `... ./scripts/hw-status.sh <subid>` (one run's full output).

That tok/s is your real hardware number for the Part 2 write-up.

---

### Troubleshooting

| Symptom | Fix |
|---|---|
| `upload failed` | Check `HW_PORTAL` / `HW_TOKEN` and that you can reach the portal host from RCE |
| status stays `queued` | The U50 is busy with another run — submissions are serialized; wait |
| status `failed` | Open the results — it has the build/run error (often a kernel-arg or top-name mismatch in `student_gemm_fpga.cpp`) |
| `set XCLBIN=…` | Point `XCLBIN` at your built bitstream, e.g. `build_hw/gemm_hw.xclbin` |
